package ata.graphs;

import java.util.Collection;
import java.util.Set;

import ata.task.tasks.Task;

public interface TasksGraphAndSlots {

    public int initAll(Collection<Task> tasks);

    public void addAll(Collection<Task> toInsert);

    public void add(Task task);

    public void remove(Task toRemove);

  
    public void removeAll(Collection<Task> toRemove);
    
    /**
     * removes everything
     */
    public void clear();

    public int nbTasks();

    public Set<Edge> getSortedEdges();

    public Edge[] copyToArrayAndSortEdges();

    public LightEdge[] copyToArrayAndSortEdgesLightVersion();

    public Node getNode(int slot);

    public int getSlot(Node node);

    public Task getTask(int slot);

}
