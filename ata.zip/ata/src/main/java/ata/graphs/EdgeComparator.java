package ata.graphs;

import java.util.Comparator;

public class EdgeComparator implements Comparator<Edge> {

    private static EdgeComparator instance = null;

    public static EdgeComparator getInstance() {
        if (instance == null) {
            instance = new EdgeComparator();
        }
        return instance;
    }

    @Override
    public int compare(Edge o1, Edge o2) {
        int res = Double.compare(o1.getWeight(), o2.getWeight());
        if (res == 0) {
            // arbitrary, on the ids
            int id1Left = o1.getVertexA().getId();
            int id2Left = o2.getVertexA().getId();
            res = Integer.compare(id1Left, id2Left);
            if (res == 0) {
                int id1Right = o1.getVertexB().getId();
                int id2Right = o2.getVertexB().getId();
                return Integer.compare(id1Right, id2Right);
            }
            return res;
        }
        return res;
    }

}
