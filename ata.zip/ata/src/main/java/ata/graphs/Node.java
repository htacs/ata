package ata.graphs;

public interface Node {

    public int getId();

}
