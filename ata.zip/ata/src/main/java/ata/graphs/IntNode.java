package ata.graphs;

/**
 * a node with an int as ID
 *
 */
public final class IntNode implements Node {

    private final int value;

    public IntNode(int value) {
        this.value = value;
    }

    @Override
    public int getId() {
        return value;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + value;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        // if node, use the id
        if (obj instanceof Node) {
            Node other = (Node) obj;
            if (value != other.getId()) {
                return false;
            }
            return true;
        }
        // else classi comparison
        if (getClass() != obj.getClass())
            return false;
        IntNode other = (IntNode) obj;
        if (value != other.value)
            return false;
        return true;
    }

}
