package ata.graphs;

/**
 * the "heavy" version of an edge
 *
 */
public class BasicEdge implements Edge {

    private final Node vertexA;
    private final Node vertexB;
    private final double weight;

    public BasicEdge(Node vertexA, Node vertexB, double weight) {
        this.vertexA = vertexA;
        this.vertexB = vertexB;
        this.weight = weight;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((vertexA == null) ? 0 : vertexA.hashCode());
        result = prime * result + ((vertexB == null) ? 0 : vertexB.hashCode());
        long temp;
        temp = Double.doubleToLongBits(weight);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        BasicEdge other = (BasicEdge) obj;
        if (vertexA == null) {
            if (other.getVertexA() != null)
                return false;
        } else if (!vertexA.equals(other.getVertexA()))
            return false;
        if (vertexB == null) {
            if (other.getVertexB() != null)
                return false;
        } else if (!vertexB.equals(other.getVertexB()))
            return false;
        if (Double.doubleToLongBits(weight) != Double
                .doubleToLongBits(other.weight))
            return false;
        return true;
    }

    @Override
    public Node getVertexA() {
        return vertexA;
    }

    @Override
    public Node getVertexB() {
        return vertexB;
    }

    @Override
    public double getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return vertexA.getId() + "-" + vertexB.getId() + ":" + weight;
    }
}
