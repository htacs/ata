package ata.graphs;

import java.util.Comparator;

public class LightEdgeComparator implements Comparator<LightEdge> {

    private static LightEdgeComparator instance = null;

    public static LightEdgeComparator getInstance() {
        if (instance == null) {
            instance = new LightEdgeComparator();
        }
        return instance;
    }

    @Override
    public int compare(LightEdge o1, LightEdge o2) {
        int res = Double.compare(o1.getWeight(), o2.getWeight());
        if (res == 0) {
            // arbitrary, on the ids
            int id1Left = o1.getVertexA();
            int id2Left = o2.getVertexA();
            res = Integer.compare(id1Left, id2Left);
            if (res == 0) {
                int id1Right = o1.getVertexB();
                int id2Right = o2.getVertexB();
                return Integer.compare(id1Right, id2Right);
            }
            return res;
        }
        return res;
    }

}
