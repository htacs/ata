package ata.graphs;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.function.IntConsumer;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.Sets;

import ata.misc.MultithreadTool;
import ata.motivation.CalcSkillVariety;
import ata.task.tasks.Task;

/**
 * this version uses tasks as nodes and stores a sorted set of edges. NOT
 * thread-safe.
 *
 */
public final class TasksGraphAndSlotsEdgesSorted
        extends AbstractTasksGraphAndSlots {
    private final static Logger LOGGER = LoggerFactory
            .getLogger(TasksGraphAndSlotsEdgesSorted.class);
    /**
     * edges, sorted by descending order of weight
     */
    private final Set<Edge> edges;

    /**
     * an index task -> edges<br/>
     * does not need to be public, is used only for efficient edge removal
     */
    private final Map<Node, Set<Edge>> vertexToEdge;

    /**
     * node to slot
     */
    private final BiMap<Node, Integer> nodeToSlots;

    /**
     * largest slot
     */
    int lastIndex;

    /**
     * 
     * @param csv
     *            the tool to compute distances (i.e. weights)
     */
    public TasksGraphAndSlotsEdgesSorted() {
        nodeToSlots = HashBiMap.create();
        edges = new ConcurrentSkipListSet<>(
                EdgeComparator.getInstance().reversed());
        vertexToEdge = new ConcurrentHashMap<Node, Set<Edge>>();
    }

    // **********GRAPH and SLOTS **********

    /**
     * creates everything
     * 
     * @param tasks
     * @return the number of edges created in the graph
     */
    public int initAll(Collection<Task> tasks) {
        LOGGER.info("-------------------------------------");
        LOGGER.info("creating graph and tasks from scratch");
        nodeToSlots.clear();
        edges.clear();
        vertexToEdge.clear();
        int nbEdges = createGraph(tasks);
        createTasksToSlots(tasks);
        LOGGER.info("-------------------------------------");
        return nbEdges;
    }

    /**
     * insert a task in both graph and slots
     * 
     * @param toInsert
     */
    public void add(Task toInsert) {
        insertTaskToGraph(toInsert);
        insertTasksToSlotsIndex(toInsert);
        updateTasksToSlotsIndex();
    }

    /**
     * insert a collection of task in both graph and slots
     * 
     * @param toInsert
     */
    public void addAll(Collection<Task> toInsert) {
        for (Task t : toInsert) {
            insertTaskToGraph(t);
            insertTasksToSlotsIndex(t);
        }
        // update slots
        updateTasksToSlotsIndex();
    }

    /**
     * removes a task from both graph and slots
     * 
     * @param toRemove
     */
    public void remove(Task toRemove) {
        removeTaskFromGraph(toRemove);
        removeTaskFromSlots(toRemove);
        updateTasksToSlotsIndex();
    }

    /**
     * removes a collection of task from both graph and slots
     * 
     * @param toRemove
     */
    public void removeAll(Collection<Task> toRemove) {
        // we don't call remove: it is more efficient to do a "batch" update
        for (Task t : toRemove) {
            removeTaskFromGraph(t);
            removeTaskFromSlots(t);
        }
        updateTasksToSlotsIndex();
    }

    @Override
    public void clear() {
        edges.clear();
        vertexToEdge.clear();
        nodeToSlots.clear();
        lastIndex = 0;

    }

    // ************* SLOTS **************

    /**
     * builds the index task<->slot from scratch<br/>
     * we just use the order given by the collection
     * 
     * @param tasks
     * 
     * @param csv
     * 
     * @return
     */
    private void createTasksToSlots(Collection<Task> tasks) {
        LOGGER.info("building index task<->slot from scratch");

        int index = 0;
        for (Task t : tasks) {
            nodeToSlots.put(t, index);
            index++;
        }
        lastIndex = index - 1;

        LOGGER.info("finished building index task<->slot from scratch");
        LOGGER.info("slots: {}", nodeToSlots.size());

    }

    /**
     * add a task at the end
     * 
     * @param t
     */
    private void insertTasksToSlotsIndex(Task t) {
        nodeToSlots.put(t, lastIndex + 1);
        lastIndex++;
    }

    /**
     * removes a task from index, does NOT update slots<br/>
     * leaves an "hole" in the structure (no update)
     * 
     * @param t
     * @return
     */
    private boolean removeTaskFromSlots(Task t) {
        boolean removedFromIndex = nodeToSlots.remove(t) > 0;
        if (!removedFromIndex) {
            // this may not be a problem but it is not really expected
            LOGGER.warn("task {} not removed from index", t.getId());
        }
        return removedFromIndex;
    }

    /**
     * updates the index slot<->task, using the iteration order of the map
     */
    private void updateTasksToSlotsIndex() {
        int index = 0;

        for (Map.Entry<Node, Integer> entry : nodeToSlots.entrySet()) {
            entry.setValue(index);
            index++;
        }
        lastIndex = index - 1;
    }

    /****************** END SLOTS *************/

    // ****************** BEGIN GRAPH *******************

    /**
     * builds graph from scratch<br/>
     * 
     * @param tasks
     *            the task collection
     * @param csv
     *            tool to compute pairwise distances
     * @return
     */
    private int createGraph(Collection<Task> tasks) {
        LOGGER.info("building graph from scratch");
        Instant start = Instant.now();

        // we put all tasks in a list to ease iteration/ordering
        List<Task> tasksList = new ArrayList<>(tasks);
        // prepare the map/sets before concurrent access
        for (int i = 0; i < tasks.size(); i++) {
            vertexToEdge.put(tasksList.get(i), Sets.newConcurrentHashSet());
        }

        // get partitions
        int nbTasks = tasks.size();
        int cpus = Runtime.getRuntime().availableProcessors();
        Map<String, int[]> partitions = MultithreadTool
                .getIndexForMultithread(cpus, nbTasks);

        // run in parallel
        IntStream is = IntStream.range(0, cpus).parallel();

        // run everything in parallel
        is.forEach(new IntConsumer() {
            @Override
            public void accept(int core) {
                int nbEdges = computeEdges(tasksList,
                        partitions.get("min")[core],
                        partitions.get("max")[core], edges, vertexToEdge);
                LOGGER.info("cpu {} has finished ({} edges computed)", core,
                        nbEdges);
            }
        });

        LOGGER.info("graph built with {} edges and {} vertices", edges.size(),
                vertexToEdge.size());

        long time = Duration.between(start, Instant.now()).toMillis();
        LOGGER.info("{} ms", time);
        return edges.size();

    }

    /**
     * computes only the edges whose vertices are within the given bounds
     * 
     * @param tasksList
     * @param minIndexFirstTask
     * @param maxIndexFirstTask
     * @param sortedEdges
     * @param vertexToEdge
     * @return
     */
    private int computeEdges(List<Task> tasksList, int minIndexFirstTask,
            int maxIndexFirstTask, Set<Edge> sortedEdges,
            Map<Node, Set<Edge>> vertexToEdge) {

        int out = 0;
        for (int i = minIndexFirstTask; i <= maxIndexFirstTask; i++) {
            Task left = tasksList.get(i);
            for (int j = i + 1; j < tasksList.size(); j++) {
                Task right = tasksList.get(j);
                Edge current = new BasicEdge(left, right, CalcSkillVariety
                        .getInstance().getSkillVariety(left, right));
                sortedEdges.add(current);
                vertexToEdge.get(left).add(current);
                vertexToEdge.get(right).add(current);
                out++;
            }
        }
        return out;
    }

    /**
     * adds a task to graph
     * 
     * @param t
     * @return
     */
    private boolean insertTaskToGraph(Task t) {
        if (vertexToEdge.containsKey(t)) {
            // this may not be a problem but it is not really expected
            LOGGER.warn("task {} already in graph while trying to insert",
                    t.toString());
            return false;
        }
        Set<Edge> edgesToAdd = Sets.newConcurrentHashSet();
        for (Node other : vertexToEdge.keySet()) {
            Task otherAsTask = (Task) other;
            Edge edgeToAdd = new BasicEdge(t, otherAsTask, CalcSkillVariety
                    .getInstance().getSkillVariety(t, otherAsTask));
            // in the set that will be map to this task
            edgesToAdd.add(edgeToAdd);
            // in the main set of edges
            edges.add(edgeToAdd);
            // in the set that is mapped to the neighbor already in the graph
            vertexToEdge.get(other).add(edgeToAdd);
        }
        vertexToEdge.put(t, edgesToAdd);
        return true;
    }

    /**
     * removes a task from graph
     * 
     * @param t
     * @return
     */
    private boolean removeTaskFromGraph(Task t) {
        // LOGGER.trace("removing task {}", t.getId());
        if (vertexToEdge.containsKey(t)) {
            for (Edge toRemove : vertexToEdge.get(t)) {
                edges.remove(toRemove);
                vertexToEdge.get(toRemove.getVertexA()).remove(toRemove);
                vertexToEdge.get(toRemove.getVertexB()).remove(toRemove);
            }
            vertexToEdge.remove(t);
            return true;
        }

        return false;
    }

    /*************** END GRAPH *****************/

    /************** OTHERS *****************/

    /**
     * this implementation COPIES exising edges whereas there are already sorted
     * in another structure. It is NOT done in parallel.
     * 
     * @Override
     */
    public Edge[] copyToArrayAndSortEdges() {
        // edges are already sorted, we access them in the correct order
        Edge[] out = new Edge[edges.size()];
        int i = 0;
        for (Edge e : edges) {
            out[i] = e;
            i++;
        }
        return out;

    }

    /**
     * this implementation COPIES exising edges whereas there are already sorted
     * in another structure. It is NOT done in parallel.
     * 
     * @Override
     */
    public LightEdge[] copyToArrayAndSortEdgesLightVersion() {
        // edges are already sorted, we access them in the correct order
        LightEdge[] out = new LightEdge[edges.size()];
        int i = 0;
        for (Edge e : edges) {
            out[i] = new LightEdge(e.getVertexA().getId(),
                    e.getVertexB().getId(), e.getWeight());
            i++;
        }
        return out;
    }

    /*************** GETTERS *****************/

    @Override
    public Set<Edge> getSortedEdges() {
        return edges;
    }

    @Override
    public int nbTasks() {
        return vertexToEdge.size();
    }

    @Override
    public Node getNode(int slot) {
        return nodeToSlots.inverse().get(slot);
    }

    @Override
    public int getSlot(Node node) {
        return nodeToSlots.get(node);
    }

    /**
     * returns a task using a slot.
     * 
     * @Override
     */
    public Task getTask(int slot) {
        return (Task) getNode(slot);
    }

}
