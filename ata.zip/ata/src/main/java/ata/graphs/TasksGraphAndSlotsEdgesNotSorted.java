package ata.graphs;

import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;

import ata.misc.MultithreadTool;
import ata.motivation.CalcSkillVariety;
import ata.task.tasks.Task;

/**
 * this class handles the task<->task graph and the slot<->task map. not thread
 * safe
 *
 */
public final class TasksGraphAndSlotsEdgesNotSorted extends AbstractTasksGraphAndSlots {

	private final static Logger LOGGER = LoggerFactory.getLogger(TasksGraphAndSlotsEdgesNotSorted.class);
	/**
	 * unique structure for the graph
	 */
	private final Map<Node, Map<Node, Edge>> graph;

	/**
	 * node to slot
	 */
	private final BiMap<Node, Integer> nodeToSlots;

	/**
	 * node id to task
	 */
	private final BiMap<Integer, Task> nodeIdToTask;

	/**
	 * largest slot
	 */
	private int lastIndex;

	/**
	 * init all data structures
	 */
	public TasksGraphAndSlotsEdgesNotSorted() {
		nodeToSlots = HashBiMap.create();
		nodeIdToTask = HashBiMap.create();
		graph = Maps.newHashMap();
		lastIndex = 0;
	}

	// **********GRAPH and SLOTS **********

	/**
	 * creates everything
	 * 
	 * @param tasks
	 * @return the number of edges created in the graph
	 */
	public int initAll(Collection<Task> tasks) {
		LOGGER.info("-------------------------------------");
		LOGGER.info("creating graph and tasks from scratch");
		graph.clear();
		nodeToSlots.clear();
		nodeIdToTask.clear();
		/* first we create indices and retrieve the nodes */
		createNodesToSlots(tasks);
		/* we use these indices directly for the graph */
		createGraph();
		LOGGER.info("-------------------------------------");
		return 0;
	}

	/**
	 * insert a task in both graph and slots
	 * 
	 * @param toInsert
	 */
	public void add(Task toInsert) {
		Node ins = insertTasksToSlotsIndex(toInsert);
		insertNodeToGraph(ins);
		updateTasksToSlotsIndex();
	}

	/**
	 * insert a collection of task in both graph and slots
	 * 
	 * @param toInsert
	 */
	public void addAll(Collection<Task> toInsert) {
		for (Task t : toInsert) {
			Node ins = insertTasksToSlotsIndex(t);
			insertNodeToGraph(ins);
		}
		// update slots
		updateTasksToSlotsIndex();
	}

	/**
	 * removes a task from both graph and slots
	 * 
	 * @param toRemove
	 */
	public void remove(Task toRemove) {
		removeTaskFromGraph(toRemove);
		removeTaskFromSlots(toRemove);
		updateTasksToSlotsIndex();
	}

	/**
	 * removes a collection of task in both graph and slots
	 * 
	 * @param toRemove
	 */
	public void removeAll(Collection<Task> toRemove) {
		for (Task t : toRemove) {
			removeTaskFromGraph(t);
			removeTaskFromSlots(t);
		}
		updateTasksToSlotsIndex();
	}

	@Override
	public void clear() {
		graph.clear();
		nodeToSlots.clear();
		nodeIdToTask.clear();
		lastIndex = 0;
	}

	// ************* SLOTS **************

	/**
	 * builds the index task<->slot from scratch<br/>
	 * we just use the order given by the collection
	 * 
	 * @param tasks
	 * 
	 * @param csv
	 * 
	 * @return
	 */
	private Set<Node> createNodesToSlots(Collection<Task> tasks) {
		LOGGER.info("building indices task<->slot and nodeId<->task from scratch");
		int index = 0;
		for (Task t : tasks) {
			nodeToSlots.put(new IntNode(t.getId()), index);
			nodeIdToTask.put(t.getId(), t);
			index++;
		}
		lastIndex = index - 1;

		LOGGER.info("finished building indices task<->slot and nodeId<->task from scratch");
		LOGGER.info("slots: {}", nodeToSlots.size());
		return nodeToSlots.keySet();
	}

	/**
	 * add a task at the end
	 * 
	 * @param t
	 */
	private Node insertTasksToSlotsIndex(Task t) {
		Node ins = new IntNode(t.getId());
		nodeToSlots.put(ins, lastIndex + 1);
		nodeIdToTask.put(t.getId(), t);
		lastIndex++;
		return ins;
	}

	/**
	 * removes a task from index, does NOT update slots<br/>
	 * leaves an "hole" in the structure (no update)
	 * 
	 * @param t
	 * @return
	 */
	private boolean removeTaskFromSlots(Task t) {
		boolean res = true;
		Integer prevInt = nodeToSlots.remove(t);
		if (prevInt == null) {
			// this may not be a problem but it is not really expected
			LOGGER.warn("task {} not removed from node to slots!", t.getId());
			res = false;
		}
		Task prevTask = nodeIdToTask.remove(t.getId());
		if (prevTask == null) {
			// this may not be a problem but it is not really expected
			LOGGER.warn("task {} not removed from node id to task!", t.getId());
			res = false;
		}
		return res;
	}

	/**
	 * updates the index slot<->task, using the iteration order of the map.<br/>
	 * It makes it "CONTIGUOUS".
	 * 
	 */
	private void updateTasksToSlotsIndex() {
		int index = 0;
		for (Map.Entry<Node, Integer> entry : nodeToSlots.entrySet()) {
			entry.setValue(index);
			index++;
		}
		lastIndex = index - 1;
	}

	/****************** END SLOTS *************/

	// ****************** BEGIN GRAPH *******************

	/**
	 * builds graph AND nodeIdToTask from scratch<br/>
	 * 
	 * @param tasks
	 *            the task collection
	 * @param csv
	 *            tool to compute pairwise distances
	 * @return
	 */
	private Set<Node> createGraph() {
		LOGGER.info("building graph from scratch");
		Instant start = Instant.now();

		// we put all tasks in a list to ease iteration/ordering
		List<Node> nodes = ImmutableList.copyOf(nodeToSlots.keySet());
		/* we'll need to access to these structure conurrently */
		BiMap<Integer, Task> immutableNodeIdToTask = ImmutableBiMap.copyOf(nodeIdToTask);

		// prepare the maps before concurrent access
		for (int i = 0; i < nodes.size(); i++) {
			graph.put(nodes.get(i), Maps.newConcurrentMap());
		}

		// get partitions
		int nbNodes = nodes.size();
		int cpus = Runtime.getRuntime().availableProcessors();
		Map<String, int[]> partitions = MultithreadTool.getIndexForMultithread(cpus, nbNodes);

		// run in parallel
		IntStream is = IntStream.range(0, cpus).parallel();

		// run everything in parallel
		is.forEach(new IntConsumer() {
			@Override
			public void accept(int core) {
				int nbEdges = computeEdges(nodes, partitions.get("min")[core], partitions.get("max")[core], graph,
						immutableNodeIdToTask);
				LOGGER.info("cpu {} has finished ({} edges computed)", core, nbEdges);
			}
		});

		int nbEdges = 0;
		for (Node n : graph.keySet()) {
			nbEdges += graph.get(n).size();
		}
		LOGGER.info("graph built with {} edges and {} vertices", nbEdges, graph.size());

		long time = Duration.between(start, Instant.now()).toMillis();
		LOGGER.info("{} ms", time);
		return graph.keySet();

	}

	/**
	 * computes only the edges whose vertices are within the given bounds
	 * 
	 * @param tasksList
	 * @param minIndexFirstTask
	 * @param maxIndexFirstTask
	 * @param sortedEdges
	 * @param vertexToEdge
	 * @return
	 */
	private int computeEdges(List<Node> nodes, int minIndexFirstTask, int maxIndexFirstTask,
			Map<Node, Map<Node, Edge>> graphLocal, BiMap<Integer, Task> immutableNodeIdToTask) {

		int out = 0;
		for (int i = minIndexFirstTask; i <= maxIndexFirstTask; i++) {
			Node leftNode = nodes.get(i);
			Task leftTask = immutableNodeIdToTask.get(leftNode.getId());
			for (int j = i + 1; j < nodes.size(); j++) {
				Node rightNode = nodes.get(j);
				Task rightTask = immutableNodeIdToTask.get(rightNode.getId());
				Edge current = new BasicEdge(leftNode, rightNode,
						CalcSkillVariety.getInstance().getSkillVariety(leftTask, rightTask));
				graphLocal.get(leftNode).put(rightNode, current);
				graphLocal.get(rightNode).put(leftNode, current);
				out++;
			}
		}
		return out;
	}

	/**
	 * adds a task to graph
	 * 
	 * @param t
	 * @return
	 */
	private boolean insertNodeToGraph(Node n) {
		if (graph.containsKey(n)) {
			LOGGER.warn("node {} already in graph while trying to insert", n.toString());
			return false;
		}
		Map<Node, Edge> edgesToAdd = Maps.newConcurrentMap();
		Task currentTask = nodeIdToTask.get(n.getId());
		for (Node other : graph.keySet()) {
			Task otherTask = nodeIdToTask.get(other.getId());
			Edge edgeToAdd = new BasicEdge(n, other,
					CalcSkillVariety.getInstance().getSkillVariety(currentTask, otherTask));
			// in the set that will be map to this task
			edgesToAdd.put(other, edgeToAdd);
			// in the main set of edges
			graph.get(other).put(n, edgeToAdd);

		}
		graph.put(n, edgesToAdd);
		return true;
	}

	/**
	 * removes a task from graph
	 * 
	 * @param t
	 * @return
	 */
	private boolean removeTaskFromGraph(Task t) {
		if (graph.containsKey(t)) {
			for (Map.Entry<Node, Edge> toRemove : graph.get(t).entrySet()) {
				graph.get(toRemove.getKey()).remove(t);
			}
			graph.remove(t);
			return true;
		}
		// this may not be a problem but it is not really expected
		LOGGER.warn("task {} not removed from graph!", t.getId());
		return false;
	}

	/*************** END GRAPH *****************/

	/**********
	 * OTHERS ************* /** returns the edges in this graph as an array, sorted
	 * by descending order of weight.
	 * 
	 * @Override
	 */
	public Edge[] copyToArrayAndSortEdges() {
		LOGGER.debug("creating array from set of edges...");
		long start = System.nanoTime();
		/*
		 * we create a CONTIGUOUS index of nodes.
		 *
		 * this is not very expensive as it only depends on the number of vertices
		 */
		List<Node> nodes = ImmutableList.copyOf(graph.keySet());
		/* we copy IN PARALLEL the edges to our array */
		final Edge[] out = new Edge[nodes.size() * (nodes.size() - 1) / 2];
		// get partitions
		int cpus = Runtime.getRuntime().availableProcessors();
		Map<String, int[]> partitions = MultithreadTool.getIndexForMultithread(cpus, nodes.size());

		// run in parallel
		IntStream is = IntStream.range(0, cpus).parallel();
		// run everything in parallel
		is.forEach(new IntConsumer() {
			@Override
			public void accept(int core) {
				int nbEdges = setEdgeArray(nodes, partitions.get("min")[core], partitions.get("max")[core], graph, out);
				LOGGER.info("cpu {} has finished ({} edges computed)", core, nbEdges);
			}
		});

		long time = System.nanoTime() - start;

		LOGGER.debug(String.format("returning array of size %,d", out.length));
		LOGGER.debug(String.format("time: %,d ms", (long) (time / 1E6)));

		LOGGER.debug("sorting the array...");
		long startSort = System.nanoTime();

		Arrays.sort(out, EdgeComparator.getInstance().reversed());

		long timeSort = System.nanoTime() - startSort;
		LOGGER.debug(String.format("finished sorting, time: %,d ms", (long) (timeSort / 1E6)));
		return out;
	}

	/**
	 * computes only the edges whose vertices are within the given bounds
	 * 
	 * @param tasksList
	 * @param minIndexFirstTask
	 * @param maxIndexFirstTask
	 * @param sortedEdges
	 * @param vertexToEdge
	 * @return
	 */
	private int setEdgeArray(List<Node> nodes, int minIndexFirstTask, int maxIndexFirstTask,
			Map<Node, Map<Node, Edge>> graphLocal, Edge[] out) {

		int count = 0;
		for (int i = minIndexFirstTask; i <= maxIndexFirstTask; i++) {
			for (int j = i + 1; j < nodes.size(); j++) {
				int position = getEdgePositionInMatrix(i, j, nodes.size());
				out[position] = graph.get(nodes.get(i)).get(nodes.get(j));
				count++;
			}
		}
		return count;
	}

	/**********
	 * OTHERS ************* /** returns the edges in this graph as an array, sorted
	 * by descending order of weight.
	 * 
	 * @Override
	 */
	public LightEdge[] copyToArrayAndSortEdgesLightVersion() {
		LOGGER.debug("creating array from set of edges...");
		long start = System.nanoTime();
		/*
		 * we create a CONTIGUOUS index of nodes.
		 *
		 * this is not very expensive as it only depends on the number of vertices
		 */
		List<Node> nodes = ImmutableList.copyOf(graph.keySet());
		/* we copy IN PARALLEL the edges to our array */
		final LightEdge[] out = new LightEdge[nodes.size() * (nodes.size() - 1) / 2];
		// get partitions
		int cpus = Runtime.getRuntime().availableProcessors();
		Map<String, int[]> partitions = MultithreadTool.getIndexForMultithread(cpus, nodes.size());

		// run in parallel
		IntStream is = IntStream.range(0, cpus).parallel();
		// run everything in parallel
		is.forEach(new IntConsumer() {
			@Override
			public void accept(int core) {
				int nbEdges = setEdgeArrayLightVersion(nodes, partitions.get("min")[core], partitions.get("max")[core],
						graph, out);
				LOGGER.info("cpu {} has finished ({} edges computed)", core, nbEdges);
			}
		});

		long time = System.nanoTime() - start;

		LOGGER.debug(String.format("returning array of size %,d", out.length));
		LOGGER.debug(String.format("time: %,d ms", (long) (time / 1E6)));

		LOGGER.debug("sorting the array...");
		long startSort = System.nanoTime();

		Arrays.sort(out, LightEdgeComparator.getInstance().reversed());

		long timeSort = System.nanoTime() - startSort;
		LOGGER.debug(String.format("finished sorting, time: %,d ms", (long) (timeSort / 1E6)));
		return out;
	}

	/**
	 * computes only the edges whose vertices are within the given bounds
	 * 
	 * @param tasksList
	 * @param minIndexFirstTask
	 * @param maxIndexFirstTask
	 * @param sortedEdges
	 * @param vertexToEdge
	 * @return
	 */
	private int setEdgeArrayLightVersion(List<Node> nodes, int minIndexFirstTask, int maxIndexFirstTask,
			Map<Node, Map<Node, Edge>> graphLocal, LightEdge[] out) {

		int count = 0;
		for (int i = minIndexFirstTask; i <= maxIndexFirstTask; i++) {
			for (int j = i + 1; j < nodes.size(); j++) {
				int position = getEdgePositionInMatrix(i, j, nodes.size());
				Edge current = graph.get(nodes.get(i)).get(nodes.get(j));
				out[position] = new LightEdge(current.getVertexA().getId(), current.getVertexB().getId(),
						current.getWeight());
				count++;
			}
		}
		return count;
	}

	private int getEdgePositionInMatrix(int row, int col, int size) {
		return getLastNumberInPreviousRow(row - 1, size) + col - row;
	}

	/**
	 * sum_{k=0}^{i}{n-(k+1)} -1
	 */
	private int getLastNumberInPreviousRow(int row, int size) {
		return (row + 1) * size - row - (row * (row + 1) / 2) - 2;
	}

	/*************** GETTERS ***************/

	@Override
	public Set<Edge> getSortedEdges() {
		throw new UnsupportedOperationException("not implemented");
	}

	@Override
	public int nbTasks() {
		return graph.size();
	}

	@Override
	public int getSlot(Node n) {
		return nodeToSlots.get(n);
	}

	@Override
	public Node getNode(int slot) {
		return nodeToSlots.inverse().get(slot);
	}

	/**
	 * returns a task using a slot.
	 * 
	 * @Override
	 */
	public Task getTask(int slot) {
		Node n = nodeToSlots.inverse().get(slot);
		return nodeIdToTask.get(n.getId());
	}

}
