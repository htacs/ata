package ata.graphs;

public interface Edge {

    public Node getVertexA();

    public Node getVertexB();

    public double getWeight();
}
