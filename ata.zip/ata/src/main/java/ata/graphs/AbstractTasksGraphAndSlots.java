package ata.graphs;

abstract class AbstractTasksGraphAndSlots implements TasksGraphAndSlots {

    protected AbstractTasksGraphAndSlots() {
        super();

    }

}
