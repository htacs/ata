package ata.simulation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.assignments.Assignment;
import ata.assignments.ExpiredAssignmentException;
import ata.misc.RandomGeneratorCustom;
import ata.worker.Worker;

/**
 * used for simulation
 *
 */
class WorkerCallable implements Callable<Integer> {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(WorkerCallable.class);

    private final Worker worker;

    private int nbTasksCompleted;

    private final AssignmentServicesSimulator simulator;

    WorkerCallable(Worker worker, AssignmentServicesSimulator simulator) {
        this.worker = worker;
        this.simulator = simulator;
    }

    @Override
    public Integer call() throws Exception {
        try {
            LOGGER.info("running workerRunnable for worker {}", worker.getId());
            LOGGER.info("sleeping before starting consuming tasks");
            try {
                Thread.sleep(
                        MainAssignmentServicesSimulator.SLEEP_TIME_MS_BETWEEN_WORKERS_MS);
            } catch (InterruptedException e) {
                LOGGER.error("don't need to handle this error", e);
            }
            while (simulator.getTasksCompletedCounter().get() < simulator
                    .getNbTasksToComplete()) {
                LOGGER.info("***");
                LOGGER.info("getting tasks for worker {}", worker.getId());
                // get tasks
                int currentIterationIndex = simulator
                        .getLatestIterationIndices().get(worker);
                /* fetch the latest index */
                Integer latestIndex = simulator.getWaMonitor()
                        .getIterationIndex(worker);
                if (latestIndex != null) {
                    if (latestIndex > currentIterationIndex) {
                        // something new is available
                        LOGGER.info("there are new tasks for worker {}",
                                worker.getId());
                        int index = reassign(worker, latestIndex);
                        if (index == -10) {
                            LOGGER.warn(
                                    "no tasks available for worker {}, exiting runnable",
                                    worker.getId());
                            return nbTasksCompleted;
                        }
                        completeTask(index);
                        LOGGER.info("***");
                        continue;
                    } else {
                        // nothing new, we go on with previous assignments
                        LOGGER.info(
                                "NO new tasks for worker {}, using planned tasks",
                                worker.getId());
                        Map<Integer, Assignment> currentAssignments = simulator
                                .getAllCurrentAssigments().get(worker);
                        long nbAnswered = currentAssignments.values().stream()
                                .filter(a -> a.isCompleted()).count();
                        if (nbAnswered < currentAssignments.size()) {
                            /*
                             * nothing to do, we let the worker complete tasks,
                             * we'll try to get new assignments later
                             */
                            completeTask(latestIndex);
                            LOGGER.info("***");
                            continue;
                        }
                    }
                }
                // else this is the first iteration, we have to wait

                // worst case: no assignments for a new worker, we need
                // to
                // wait
                LOGGER.info("worker {} has no tasks, waiting...",
                        worker.getId());
                int indexAfterWaiting = waitForNewAssignments(-1, worker);
                // if (indexAfterWaiting == -1) {
                // // failure
                // throw new IllegalStateException(
                // "couldn't fetch assignments for worker " + worker);
                // }
                int index = reassign(worker, indexAfterWaiting);

                if (index == -10) {
                    LOGGER.warn(
                            "no tasks available for worker {}, exiting runnable",
                            worker.getId());
                    return nbTasksCompleted;
                }
                completeTask(index);
                LOGGER.info("***");
            }
            LOGGER.info("worker {} has completed {} tasks, exiting runnable",
                    worker.getId(), nbTasksCompleted);
            return nbTasksCompleted;
        } catch (Exception e) {
            LOGGER.warn("error during worker simulation", e);
        }
        return nbTasksCompleted;

    }

    /**
     * pick a task and complete it.
     * 
     * @param the
     *            index of the iteration
     */
    private void completeTask(int index) {
        // first sleep a bit (simulates a worker completing a task)
        int waitTime = RandomGeneratorCustom.getInstance().getReseededRandom()
                .nextInt(
                        MainAssignmentServicesSimulator.COMPLETE_TASKS_MAX_TIME_MS
                                - MainAssignmentServicesSimulator.COMPLETE_TASKS_MIN_TIME_MS)
                + MainAssignmentServicesSimulator.COMPLETE_TASKS_MIN_TIME_MS;

        LOGGER.info("worker {} sleeping {} ms while completing task",
                worker.getId(), waitTime);
        try {
            Thread.sleep(waitTime);
        } catch (InterruptedException e) {
            LOGGER.error("we should do something here!", e);
        }
        // then pick a task
        Map<Integer, Assignment> currentAssignments = simulator
                .getAllCurrentAssigments().get(worker);
        List<Assignment> assignmentsList = new ArrayList<>();
        currentAssignments.values().stream().filter(a -> !a.isCompleted())
                .forEach(a -> assignmentsList.add(a));
        Collections.shuffle(assignmentsList,
                RandomGeneratorCustom.getInstance().getReseededRandom());
        Assignment picked = assignmentsList
                .get(RandomGeneratorCustom.getInstance().getReseededRandom()
                        .nextInt(assignmentsList.size()));

        // build dummy answer
        Map<String, String[]> answerMap = new HashMap<>();
        String[] answers = new String[1];
        answers[0] = "genericAnswer";
        answerMap.put("question1", answers);
        picked.setTaskAnswer(picked.getTask().genTaskAnswer(picked,
                DateTime.now().minusSeconds(60), DateTime.now(), answerMap));

        // notify waMonitor
        LOGGER.info("worker {} completed task {} from iteration {}",
                worker.getId(), picked.getTask().getId(), index);

        simulator.getWaMonitor().addCompletedAssignment(picked);

        // for simulation
        simulator.getTasksCompletedCounter().incrementAndGet();
        nbTasksCompleted++;
    }

    /**
     * reassign new tasks
     * 
     * @param worker
     * @param latestIndex
     * @return latestIndex the index of the iteration that provided these new
     *         tasks
     */
    private int reassign(Worker worker, int latestIndex) {
        LOGGER.info("reassigning tasks for worker {}", worker.getId());
        /*
         * first we clear the previous assignments
         */
        LOGGER.info("desactivating previous assignments");

        Map<Integer, Assignment> previousCollection = simulator
                .getAllCurrentAssigments().get(worker);
        for (Assignment a : previousCollection.values()) {
            try {
                a.expire();
            } catch (ExpiredAssignmentException e) {
                LOGGER.error("assignment already expired", a);
            }
            // this.assignmentDao.updateExpirationDate(a);
        }
        /*
         * We fetch the new assignments that are available. we copy them in a
         * list, sorted by random order.
         */

        List<Assignment> assignments = new ArrayList<>(
                simulator.getWaMonitor().getPlannedAssignments(worker));

        // System.out.println("planned tasks obtained");
        // for (Assignment a : assignments) {
        // System.out.println(a.getTask().getId());
        // }

        // // bind the amt assignment
        // AmtAssignment amtAssignment = SessionAttributes
        // .getAmtAssignment(session);
        // for (Assignment a : assignments) {
        // a.setAmtAssignment(amtAssignment);
        // }

        // for the purpose of this simulation we need to generate a db id for
        // each assignment
        for (Assignment assignment : assignments) {
            assignment.setDbId(
                    AssignmentServicesSimulator.ASSIGNMENT_DB_ID_GENERATOR
                            .getAndIncrement());
        }

        // put them in session
        Collections.shuffle(assignments,
                RandomGeneratorCustom.getInstance().getReseededRandom());
        Map<Integer, Assignment> currentAssignments = new LinkedHashMap<>();
        assignments.stream()
                .forEach(a -> currentAssignments.put(a.getDbId(), a));
        simulator.getAllCurrentAssigments().put(worker, currentAssignments);
        simulator.getLatestIterationIndices().put(worker, latestIndex);

        // // clear the current assignment
        // SessionAttributes.removeCurrentAssignment(session);
        //
        // // we put these assignments into the db
        // RegisterAssignment registerAss = new RegisterAssignment(
        // assignmentDao);
        // registerAss.registerAssignments(assignments);
        LOGGER.info("assignments OK for worker {}", worker.getId());
        LOGGER.info("returning {} assignments at iteration {}",
                assignments.size(), latestIndex);

        // /**
        // * finally update the waMonitor and taskManagr
        // */
        // /*
        // * update monitor and get remaining tasks these tasks were not
        // completed
        // * and since their assignment a new iteration happened
        // */
        // Collection<Task> remainingTasks = null;
        // synchronized (simulator.getTaskManager()) {
        // synchronized (simulator.getWaMonitor()) {
        // remainingTasks = simulator.getWaMonitor()
        // .putNiouPlannedAssignmentsRemovePreviousGetDifferenceWorkerLevel(
        // previousCollection, currentAssignments,
        // latestIndex, worker);
        // System.out.println("tasks that need to be reincorporated");
        // for (Task t : remainingTasks) {
        // System.out.println(t.getId());
        // }
        //
        // // update the task manager
        // simulator.getTaskManager().putAll(remainingTasks);
        // }
        // }

        // no assignment:used only for simulation
        if (assignments.size() == 0) {
            return -10;
        }

        return latestIndex;
    }

    /**
     * wait for new assignments if no assignments available
     * 
     * @param currentIndex
     * @param worker
     * @return
     */
    private int waitForNewAssignments(int currentIndex, Worker worker) {
        int latestIndex = -1;
        int nbRetries = 0;
        /*
         * no need to synchronize on waMonitor, we are using a synchronized
         * implementation of waMonitor
         */
        while (latestIndex <= currentIndex
                && nbRetries < MainAssignmentServicesSimulator.MAX_RETRIES_WAIT_FOR_ASSIGNMENTS_MS) {
            try {
                LOGGER.warn(
                        "worker {} is waiting for an assignment ({} retries)",
                        worker.getId(), nbRetries);
                Thread.sleep(
                        MainAssignmentServicesSimulator.WAITING_TIME_ASSIGNMENTS_MS);
            } catch (InterruptedException e) {
                /*
                 * there is no reason for this thread to be stopped
                 */
                LOGGER.error(
                        "worker {} interrupted thread while waiting assignments",
                        worker);
                LOGGER.error("interruption while waiting assignments", e);
                // TODO: handle correctly this error
            }
            nbRetries++;
            Integer iterationIndex = simulator.getWaMonitor()
                    .getIterationIndex(worker);
            if (iterationIndex == null) {
                // worker is not in the map (happens at init phase)
                latestIndex = -1;
            } else {
                // worker is in the map (she has already been
                // assigned
                // tasks)
                latestIndex = iterationIndex;
            }
        }
        if (nbRetries >= MainAssignmentServicesSimulator.MAX_RETRIES_WAIT_FOR_ASSIGNMENTS_MS) {
            LOGGER.error("couldn't fetch assignments for worker {}", worker);
            throw new IllegalStateException(
                    "couldn't fetch assignments for worker " + worker);
        }
        return latestIndex;
    }

}
