package ata.simulation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.math3.random.RandomDataGenerator;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSetMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import ata.assigner.AssignerConfiguration;
import ata.assigner.AssignerFactory;
import ata.assigner.BasicAssignerConfiguration;
import ata.assignments.AssignerToken;
import ata.assignments.Assignment;
import ata.assignments.AssignmentIterationConfiguration;
import ata.assignments.AssignmentIterationInput;
import ata.assignments.AssignmentMethod;
import ata.assignments.AssignmentPolicy;
import ata.assignments.BasicAssignmentIteration;
import ata.assignments.IAssignmentIteration;
import ata.assignments.ServicesBuilder;
import ata.assignments.TaskManager;
import ata.misc.RandomGeneratorCustom;
import ata.motivation.AlphaBetaComputation;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

class IterationsSimulator {

    private static Logger LOGGER = LoggerFactory
            .getLogger(IterationsSimulator.class);

    /**
     * nb of iterations to perform
     */
    private int nbIterations;

    private final int nbTasksCompletedDuringEachIteration;

    private final AssignerFactory.method methodToTest;

    private final Double forcedAlpha;

    private final Double forcedBeta;

    IterationsSimulator(int nbIterations, AssignerFactory.method methodToTest,
            Double forcedAlpha, Double forcedBeta,
            int nbTasksCompletedDuringEachIteration) {
        super();
        this.nbIterations = nbIterations;
        this.nbTasksCompletedDuringEachIteration = nbTasksCompletedDuringEachIteration;
        this.methodToTest = methodToTest;
        this.forcedAlpha = forcedAlpha;
        this.forcedBeta = forcedBeta;
    }

    /**
     * runs the simulation
     */
    public void runSimulation(ImmutableSetMultimap<Job, Task> immutableJobs,
            Set<Worker> workers) {
        LOGGER.info(
                "running iteration simulator for {} jobs, {} tasks, {} workers",
                immutableJobs.keySet().size(), immutableJobs.size(),
                workers.size());
        // build workers and assigners
        Set<Worker> unknownWorkers = new HashSet<>(workers);
        AssignerToken assignerToken = new AssignerToken("iterations token",
                new AssignmentMethod(methodToTest, forcedAlpha, forcedBeta),
                true);
        Map<Worker, AssignerToken> tokens = new HashMap<>();
        for (Worker worker : unknownWorkers) {
            tokens.put(worker, assignerToken);
        }

        AssignerConfiguration assignerConf = new BasicAssignerConfiguration(
                true);
        AssignmentPolicy assignPolicy = ServicesBuilder
                .newBasicAssignmentPolicy(true);
        AssignmentIterationConfiguration assignerIterConf = ServicesBuilder
                .newBasicAssignmentIterationConfiguration();
        assignerIterConf.setAssignerConfiguration(assignerConf);
        assignerIterConf.setAssignmentPolicy(assignPolicy);

        Multimap<Worker, Assignment> assignments = MultimapBuilder.hashKeys()
                .hashSetValues().build();

        // build input
        TaskManager taskManager = ServicesBuilder.newSynchronizedTaskManager();
        taskManager.initAll(immutableJobs);

        // // a copy of jobs
        // Multimap<Job, Task> mutableJobs = TasksJobsTools
        // .getMultimapCopy(immutableJobs);

        RandomDataGenerator rand = new RandomDataGenerator();
        rand.reSeed(1);

        iterationLoop: for (int i = 0; i < nbIterations; i++) {
            LOGGER.info(
                    "----------------------------------------------------------------------------------------------");
            LOGGER.info("iteration:\t " + i);
            LOGGER.info("jobs in input: {}", taskManager.nbJobs());
            LOGGER.info("tasks in input: {}", taskManager.nbTasks());
            LOGGER.info("task in graph: {}", taskManager.nbTasksInGraph());
            int nbAssignmentsReturned = assignments.size();
            long nbAssignmentsWithAnswerReturned = assignments.values().stream()
                    .filter(a -> a.isCompleted()).count();
            LOGGER.info("tasks completed in iteration {}: {}", i - 1,
                    nbAssignmentsWithAnswerReturned);
            LOGGER.info("tasks assigned in iteration {}: {}", i - 1,
                    nbAssignmentsReturned);
            LOGGER.info("---");

            int nbTasksRequired = assignerConf.getMaxNbTasksPerWorker()
                    * (assignments.keySet().size() + unknownWorkers.size());

            if (nbTasksRequired <= taskManager.nbTasks()) {
                IAssignmentIteration currentIteration = new BasicAssignmentIteration(
                        nbTasksCompletedDuringEachIteration, assignerIterConf,
                        i);

                // build input
                AssignmentIterationInput input = ServicesBuilder
                        .newBasicAssignmentIterationInput();
                input.setPlannedEligibleAssignments(assignments);
                input.setTokens(tokens);
                input.setUnknownWorkers(unknownWorkers);
                input.setTaskManager(taskManager);

                assignments = currentIteration.assign(input);

                simulateTaskCompletion(assignments,
                        nbTasksCompletedDuringEachIteration);

                // switch workers
                unknownWorkers.clear();

                // collect tasks that were not completed
                Set<Task> notCompletedTasks = new HashSet<>();
                for (Assignment a : assignments.values()) {
                    if (!a.isCompleted()) {
                        notCompletedTasks.add(a.getTask());
                    }
                }

                taskManager.putAll(notCompletedTasks);

                // remove completed task from available tasks
                // taskManager.removeAll(completedTasks);

                // logger.info("Assignment Iteration AFTER simulation :" +
                // currentIteration);

                LOGGER.info("---");
                LOGGER.info("finished iteration:\t {} ", i);
                LOGGER.info("jobs in input:\t{}", taskManager.nbJobs());
                LOGGER.info("tasks in input:\t{}", taskManager.nbTasks());
                LOGGER.info("task in graph:\t{}", taskManager.nbTasksInGraph());
                LOGGER.info("tasks reincorporated:\t{}",
                        notCompletedTasks.size());
                LOGGER.info("tasks assigned:\t{}", assignments.size());
                LOGGER.info(
                        "----------------------------------------------------------------------------------------------");
            } else {
                // not enough tasks
                LOGGER.info(
                        "not enough tasks for workers ({}/{}), stopping iterations at iteration {}",
                        taskManager.nbTasks(), nbTasksRequired, i);
                break iterationLoop;
            }
        }

    }

    /**
     * simulates task completion. Modifies the previous assignments!
     * 
     * @param assignments
     * @param percentTasksCompleted
     * @return
     */
    private Multimap<Worker, Assignment> simulateTaskCompletion(
            Multimap<Worker, Assignment> assignments, int nbTasksToPick) {
        RandomGeneratorCustom.getInstance().reseedRandom();
        Multimap<Worker, Assignment> out = MultimapBuilder.hashKeys()
                .hashSetValues().build();
        for (Worker w : assignments.keySet()) {
            // we are going to fill this set
            Set<Assignment> completedAssignments = new LinkedHashSet<>();
            // we are going to pick assignments in this list
            Set<Assignment> remainingAssignments = new HashSet<>(
                    assignments.get(w));
            int actualNbTasksToPick = Math.min(nbTasksToPick,
                    remainingAssignments.size());
            for (int i = 0; i < actualNbTasksToPick; i++) {
                Assignment preferredAssignment = null;
                if (i == 0) {
                    // random one
                    List<Assignment> remainingAsList = new ArrayList<>(
                            remainingAssignments);
                    preferredAssignment = remainingAsList
                            .get(RandomGeneratorCustom.getInstance()
                                    .getReseededRandom()
                                    .nextInt(remainingAsList.size()));
                } else {
                    // pick best task/assignment
                    preferredAssignment = AlphaBetaComputation
                            .getPreferredAssignment(w, completedAssignments,
                                    remainingAssignments);
                }
                // add it to the completion list
                completedAssignments.add(preferredAssignment);
                // remove from remaining tasks
                remainingAssignments.remove(preferredAssignment);
            }

            // add answer on completed assignments
            int minutesShift = 1;
            for (Assignment a : completedAssignments) {
                Map<String, String[]> answerMap = new HashMap<>();
                String[] answers = new String[1];
                answers[0] = "genericAnswer";
                answerMap.put("question1", answers);
                a.setTaskAnswer(a.getTask().genTaskAnswer(a, DateTime.now(),
                        DateTime.now().plusMinutes(minutesShift), answerMap));

                minutesShift++;
            }
            out.putAll(w, completedAssignments);
            out.putAll(w, remainingAssignments);
        }

        int nbAssignmentsReturned = out.size();
        long nbAssignmentsWithAnswerReturned = out.values().stream()
                .filter(a -> a.isCompleted()).count();
        LOGGER.info("simulation ended: {} tasks completed / {} returned",
                nbAssignmentsWithAnswerReturned, nbAssignmentsReturned);

        return out;
    }

}
