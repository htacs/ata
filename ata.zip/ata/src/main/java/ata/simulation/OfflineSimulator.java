package ata.simulation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Multimap;
import com.google.common.collect.SetMultimap;
import com.google.common.collect.Table;

import ata.assigner.Assigner;
import ata.assigner.AssignerConfiguration;
import ata.assigner.AssignerExtraArgs;
import ata.assigner.AssignerFactory;
import ata.assigner.BasicAssignerConfiguration;
import ata.assigner.IAssignerExtraArgs;
import ata.assignments.AssignerToken;
import ata.assignments.Assignment;
import ata.assignments.AssignmentMethod;
import ata.assignments.MiscAssignmentTools;
import ata.configuration.ConfigurationLoader;
import ata.database.AMTDataLoader;
import ata.database.ConnectionManager;
import ata.graphs.TasksGraphAndSlots;
import ata.graphs.TasksGraphAndSlotsEdgesNotSorted;
import ata.misc.CompOps;
import ata.misc.RandomGeneratorCustom;
import ata.motivation.CalcMotivation;
import ata.motivation.CalcPayment;
import ata.motivation.CalcRelevance;
import ata.motivation.CalcSkillVariety;
import ata.task.TasksJobsTools;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;
import ata.worker.WorkerGenerationParams;
import ata.worker.WorkerGenerator;

public final class OfflineSimulator {

    private static Logger LOGGER = LoggerFactory
            .getLogger(OfflineSimulator.class);

    public final static int METHOD_COLUM = 10;
    public final static int WORKERS_COLUMN = 20;
    public final static int TASKS_COLUMN = 30;

    private final static boolean CSV_HEADERS = false;

    /* loaded once by loadData() */
    private static int nbAmtRows;
    private static ImmutableSet<Job> immutableJobs;
    private static Table<String, Integer, WorkerGenerationParams> allWorkerParams;

    /**
     * runs simulation on a config file
     * 
     * @param configFile
     * @throws Exception
     */
    void run(String configFile, String inputFile, String workerParamFile,
            String outputFile) throws Exception {
        LOGGER.info("starting simulation/testing");
        loadData(configFile, workerParamFile);

        // now we start runs
        BufferedReader brIn = new BufferedReader(
                new FileReader(new File(inputFile)));
        BufferedWriter brOut = new BufferedWriter(
                new FileWriter(new File(outputFile), true));

        String line = null;
        String shortId = null, longId = null, assignmentMethodName = null;

        // TasksGraphAndSlots tasksGraphAndSlots = new
        // TasksGraphAndSlotsEdgesSorted(
        // CalcSkillVariety.getInstance());
        TasksGraphAndSlots tasksGraphAndSlots = new TasksGraphAndSlotsEdgesNotSorted();

        /* params that are going to be read */
        int nbDifferentJobsToUse, minNbTasksPerWorker, maxNbTasksPerWorker,
                nbTasksPerJob;
        String experimentGroup, experimentSubGroup;
        String workerParamsID;

        Assigner assigner = null;

        boolean useReseededRandom = ConfigurationLoader.getConfiguration()
                .getBoolean(ConfigurationLoader.KEY_USE_RESEEDED_DATA_GEN);

        int numline = 0;
        while ((line = brIn.readLine()) != null) {
            try {
                /* reset stats */
                StatsManager.reset();

                /* parse parameters to use */
                String[] split = line.split(";");
                /* id and algo parameters */
                shortId = split[0];
                longId = split[1];
                assignmentMethodName = split[METHOD_COLUM];
                experimentGroup = split[METHOD_COLUM + 1];
                experimentSubGroup = split[METHOD_COLUM + 2];
                AssignerFactory.method methodToUse = null;
                try {
                    methodToUse = AssignerFactory.method
                            .valueOf(assignmentMethodName);
                } catch (Exception e) {
                    LOGGER.error("couldn't parse assignment method "
                            + assignmentMethodName + ", skipping line " + line);
                    continue;
                }
                AssignerToken token = new AssignerToken(longId,
                        new AssignmentMethod(methodToUse, null, null), true);

                LOGGER.info("******************************");
                LOGGER.info("**************");
                LOGGER.info("starting simulation for id " + shortId);
                LOGGER.info("*****");

                // tasks parameters
                // nbTasksToUse = Integer.valueOf(split[TASKS_COLUMN]);
                nbDifferentJobsToUse = Integer.valueOf(split[TASKS_COLUMN]);
                nbTasksPerJob = Integer.valueOf(split[TASKS_COLUMN + 1]);

                if (nbDifferentJobsToUse > immutableJobs.size()) {
                    LOGGER.warn("{} jobs available while {} required",
                            immutableJobs.size(), nbDifferentJobsToUse);
                }

                // workers parameters
                workerParamsID = split[WORKERS_COLUMN];
                minNbTasksPerWorker = Integer
                        .valueOf(split[WORKERS_COLUMN + 2]);
                maxNbTasksPerWorker = Integer
                        .valueOf(split[WORKERS_COLUMN + 3]);

                // --------------------------------------------------------
                // ----------- job sampling and task generation -----------

                // task generation with the desired number of tasks per job
                // sample jobs
                LOGGER.info("sampling jobs...");
                Set<Job> randomJobs = TasksJobsTools.getRandomSubsetOfJobs(
                        immutableJobs, nbDifferentJobsToUse, useReseededRandom);
                LOGGER.info("sampled {} jobs", randomJobs.size());

                LOGGER.info("generating tasks...");
                SetMultimap<Job, Task> mutableGeneratedJobs = AMTDataLoader
                        .generateNbTasks(randomJobs, nbTasksPerJob, true);
                LOGGER.info("generated {} tasks for {} jobs",
                        mutableGeneratedJobs.size(),
                        mutableGeneratedJobs.keySet().size());

                LOGGER.debug("-----");
                LOGGER.debug("jobs are generated: OK");
                LOGGER.debug("hashcode for jobs: {}",
                        TasksJobsTools.genJobsHashCodeOrderIndependent(
                                mutableGeneratedJobs.keySet()));
                LOGGER.debug("tasks are generated: OK");
                LOGGER.debug("hashcode for tasks: {}",
                        TasksJobsTools.genTasksHashCodeOrderIndependent(
                                mutableGeneratedJobs.values()));
                LOGGER.debug("----");
                // get keywords from this data
                Set<String> availableKeywords = TasksJobsTools
                        .getAllKeywordsFromJobs(mutableGeneratedJobs.keySet());

                // --------------- Generate workers ------------------- //
                Set<Worker> workersGenerated = WorkerGenerator.generateWorkers(
                        allWorkerParams.row(workerParamsID).values(),
                        availableKeywords, useReseededRandom);
                // Set<Worker> workersGenerated =
                // WorkerGenerator.generateWorkers(
                // nbWorkers, availableKeywords, nbKeywordsPerWorker);

                // assigner and graph
                AssignerConfiguration assignerConf = new BasicAssignerConfiguration(
                        true);
                assignerConf.setMaxNbTasksPerWorker(maxNbTasksPerWorker);
                assignerConf.setMinNbTasksPerWorker(minNbTasksPerWorker);

                assigner = AssignerFactory.getAssigner(token.getMethod(),
                        assignerConf);
                if (assigner.requireGraph()) {
                    // we use a random order, there is no reason for the tasks
                    // to be sorted
                    List<Task> tasksList = new ArrayList<>(
                            mutableGeneratedJobs.values());
                    // use the same order at each iteration
                    RandomGeneratorCustom.getInstance().reseedRandom();
                    Collections.shuffle(tasksList, RandomGeneratorCustom
                            .getInstance().getReseededRandom());
                    tasksGraphAndSlots.initAll(tasksList);
                }
                IAssignerExtraArgs assignerExtraArgs = new AssignerExtraArgs();
                assignerExtraArgs.setTasksGraphAndSlots(tasksGraphAndSlots);
                assignerExtraArgs.setAssignmentIndex(0);

                // what is the actual nb tasks per worker ?
                int actualNbTasksPerWorker = AssignerFactory
                        .getActualMaxNbTasksPerWorker(minNbTasksPerWorker,
                                maxNbTasksPerWorker, workersGenerated,
                                mutableGeneratedJobs);

                LOGGER.info("----------------");
                LOGGER.info("current parameters before running assignments:");
                LOGGER.info("shortId\t {}", shortId);
                LOGGER.info("method\t {}", assignmentMethodName);
                LOGGER.info("nbWorkers\t {}", workersGenerated.size());
                LOGGER.info("Xmax\t {}", maxNbTasksPerWorker);
                LOGGER.info("workerParamsID\t {}", workerParamsID);
                LOGGER.info("minNbTasksPerWorker\t {}", minNbTasksPerWorker);
                LOGGER.info("maxNbTasksPerWorker\t {}", maxNbTasksPerWorker);
                LOGGER.info("actualNbTasksPerWorker\t {}",
                        actualNbTasksPerWorker);
                LOGGER.info("nbTasks\t {}", mutableGeneratedJobs.size());
                LOGGER.info("nbDifferentJobs\t {}",
                        mutableGeneratedJobs.keySet().size());
                LOGGER.info("nbTasksPerJob\t {}", nbTasksPerJob);
                LOGGER.info("----------------");

                // -------
                // ASSIGN

                /*
                 * we suggest a gc to avoid pollution of running time measures
                 */
                System.gc();

                long start = System.nanoTime();
                // run algorithm
                Multimap<Worker, Assignment> assignments = assigner
                        .getAssignments(workersGenerated, mutableGeneratedJobs,
                                assignerExtraArgs);

                long assignmentTime = System.nanoTime() - start;
                // -------

                // stats
                int nbWorkersWithTasks = assignments.keySet().size();
                String error = "";
                DateTime currentTime = new DateTime();

                double averageAlpha = getAverageAlpha(workersGenerated);
                double averageBeta = getAverageBeta(workersGenerated);
                StatsManager.getInstance().put(StatsKeys.AVG_ALPHA,
                        averageAlpha);
                StatsManager.getInstance().put(StatsKeys.AVG_BETA, averageBeta);

                StatsManager.getInstance().put(StatsKeys.DATETIME, currentTime);
                StatsManager.getInstance().put(StatsKeys.LONGID, longId);
                StatsManager.getInstance().put(StatsKeys.ERROR, error);
                StatsManager.getInstance().put(StatsKeys.METHOD_NAME,
                        assignmentMethodName);
                StatsManager.getInstance().put(StatsKeys.EXPERIMENT_GROUP,
                        experimentGroup);
                StatsManager.getInstance().put(StatsKeys.EXPERIMENT_SUBGROUP,
                        experimentSubGroup);
                StatsManager.getInstance().put(StatsKeys.NB_TASKS,
                        mutableGeneratedJobs.size());
                StatsManager.getInstance().put(StatsKeys.NB_WORKERS,
                        workersGenerated.size());
                StatsManager.getInstance().put(
                        StatsKeys.MIN_NB_TASKS_PER_WORKER, minNbTasksPerWorker);
                StatsManager.getInstance().put(
                        StatsKeys.MAX_NB_TASKS_PER_WORKER, maxNbTasksPerWorker);
                StatsManager.getInstance().put(
                        StatsKeys.ACTUAL_MAX_NB_TASKS_PER_WORKER,
                        actualNbTasksPerWorker);
                StatsManager.getInstance().put(StatsKeys.WORKERS_PARAMS_ID,
                        workerParamsID);
                StatsManager.getInstance().put(
                        StatsKeys.WORKERS_PARAMS_ID_TO_STRING,
                        allWorkerParams.values());
                StatsManager.getInstance().put(StatsKeys.NB_DIFFERENT_JOBS,
                        mutableGeneratedJobs.keySet().size());
                StatsManager.getInstance().put(StatsKeys.NB_WORKERS_WITH_TASKS,
                        nbWorkersWithTasks);

                StatsManager.getInstance().put(StatsKeys.TIME_Assignment,
                        assignmentTime);

                // evaluate objective function
                double totalMotivation = CalcMotivation.getInstance()
                        .computeMotivation(assignments);
                StatsManager.getInstance().put(StatsKeys.VALUE_Motivation_Value,
                        totalMotivation);

                // the maximum motivation value that we could get (very loose)
                double upperBoundMotivation = CalcMotivation.getInstance()
                        .computeMaximumTheoreticalMotivation(
                                maxNbTasksPerWorker, workersGenerated);
                StatsManager.getInstance().put(
                        StatsKeys.VALUE_UPPER_BOUND_Motivation_Value,
                        upperBoundMotivation);

                // the maximum motivation value with the actual nb tasks per
                // worker
                double upperBoundMotivationActual = CalcMotivation.getInstance()
                        .computeMaximumTheoreticalMotivation(
                                actualNbTasksPerWorker, workersGenerated);
                StatsManager.getInstance().put(
                        StatsKeys.VALUE_UPPER_BOUND_Motivation_Value_ACTUAL_NB_TASKS,
                        upperBoundMotivationActual);

                // nb of tasks that were assigned, just to check correctness
                int nbTasksAssigned = assignments.size();
                StatsManager.getInstance().put(
                        StatsKeys.VALUE_NB_TASKS_ASSIGNED, nbTasksAssigned);

                LOGGER.debug("-----");
                LOGGER.debug(
                        String.format("hashcode for obtained assignments: %d",
                                MiscAssignmentTools.getCollectionsHash(
                                        assignments.values())));
                LOGGER.debug("----");

                // write stats
                brOut.write(StatsManager.getInstance().getCsv(CSV_HEADERS));
                brOut.flush();
                LOGGER.info(StatsManager.getInstance().toString());
                LOGGER.info("*****");
                LOGGER.info("finished simulation for id " + shortId);
                LOGGER.info("**************");
                LOGGER.info("******************************");
                numline++;
            } catch (Exception e) {
                DateTime currentTime = new DateTime();
                LOGGER.error(
                        String.format("error on line %d, skipping it", numline),
                        e);
                brOut.write(currentTime + ";" + longId + ";" + e.getMessage()
                        + System.lineSeparator());
                brOut.flush();
                continue;
            }

        }

        brIn.close();
        brOut.close();

    }

    private static void loadData(String configFile, String allWorkerParamsFile)
            throws URISyntaxException, IOException {
        ConfigurationLoader.loadOrGetConfigurationLoader(new URI(configFile));

        CompOps.setEpsilon(ConfigurationLoader.getConfiguration()
                .getDouble(ConfigurationLoader.KEY_EPSILON_DOUBLE));

        nbAmtRows = ConfigurationLoader.getConfiguration()
                .getInt(ConfigurationLoader.KEY_NB_AMT_ROWS);

        // load ALL data (see config.xml for %rows that are fetched)
        // ----------------------------------------------
        LOGGER.info("---");
        LOGGER.info("loading data");
        immutableJobs = ImmutableSet.copyOf(loadАМТJobs(nbAmtRows));
        int nbJobsFetched = immutableJobs.size();
        LOGGER.info("{} jobs loaded", nbJobsFetched);
        LOGGER.debug("jobs hashcode: {}",
                TasksJobsTools.genJobsHashCodeOrderIndependent(immutableJobs));
        LOGGER.info("---");

        // prepare tools that require pre processing
        CalcSkillVariety csv = CalcSkillVariety.getInstance(immutableJobs);
        CalcPayment cp = CalcPayment.getInstance(immutableJobs);
        CalcRelevance cr = CalcRelevance.getInstance();
        CalcMotivation.getInstance(csv, cp, cr);

        allWorkerParams = WorkerGenerationParams
                .readWorkerGenerationParams(allWorkerParamsFile);
    }

    /**
     * fetches tasks and jobs from the database <br/>
     * HARDCODED: only AMT data
     */
    public static Set<Job> loadАМТJobs(int nbAmtRows) {
        ConnectionManager cm = new ConnectionManager(
                ConfigurationLoader.KEY_DB_AMTDATA);

        Set<Job> allAMTJobs = AMTDataLoader.getAllJobs(cm.getConnection(),
                nbAmtRows);

        cm.stopConnection();       

        return allAMTJobs;
    }

    private static double getAverageAlpha(Set<Worker> workers) {
        double sum = 0.0;
        for (Worker w : workers) {
            sum += w.getAlpha();
        }
        return (double) sum / workers.size();
    }

    private static double getAverageBeta(Set<Worker> workers) {
        double sum = 0.0;
        for (Worker w : workers) {
            sum += w.getBeta();
        }
        return (double) sum / workers.size();
    }

}
