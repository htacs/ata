package ata.simulation;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MainSimulator {

    private final static String CONFIG_ARG_NAME = "config";
    public final static String KEY_INPUTFILE_PATH = "expes_inputFile_Path";
    public final static String KEY_WORKERPARAMS_PATH = "expes_workerParamsFile_Path";
    public final static String KEY_OUTPUTFILE_PATH = "expes_outputFile_Path";

    /**
     * if true, will count the nb of zeros in input of LSAP
     */
    public final static boolean MEASURE_NB_ZEROS_IN_LSAP = true;

    private static Logger LOGGER = LoggerFactory.getLogger(MainSimulator.class);

    public static void main(String[] args) throws Exception {
        Options options = new Options();
        options.addOption(new Option(CONFIG_ARG_NAME, true,
                "path to the xml config file"));
        options.addOption(new Option(KEY_INPUTFILE_PATH, true,
                "path to the input file (.csv)"));
        options.addOption(new Option(KEY_WORKERPARAMS_PATH, true,
                "path to the worker params file (.csv)"));
        options.addOption(new Option(KEY_OUTPUTFILE_PATH, true,
                "path to the output file (will be written as .csv)"));
        DefaultParser parser = new DefaultParser();
        CommandLine line = parser.parse(options, args);
        String configFile = line.getOptionValue(CONFIG_ARG_NAME);
        String inputFile = line.getOptionValue(KEY_INPUTFILE_PATH);
        String workerParamsFile = line.getOptionValue(KEY_WORKERPARAMS_PATH);
        String outputFile = line.getOptionValue(KEY_OUTPUTFILE_PATH);
        // run simulation
        LOGGER.info("starting simulation");
        OfflineSimulator simulator = new OfflineSimulator();
        simulator.run(configFile, inputFile, workerParamsFile, outputFile);
        LOGGER.info("simulation done");
    }

}
