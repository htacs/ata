package ata.simulation;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * associated to an instance of an assignment method<br/>
 * used to store all parameters and results of experiments
 *
 */
public class StatsManager {

    // TODO: include CPU Time

    private final static Logger LOGGER = LoggerFactory
            .getLogger(StatsManager.class);

    private static StatsManager instance = null;

    private Map<StatsKeys, Object> statsMap;

    private final NumberFormat numberFormatter;

    private StatsManager() {
        statsMap = new HashMap<>();
        numberFormatter = new DecimalFormat("###.##");
        numberFormatter.setRoundingMode(RoundingMode.HALF_UP);
    }

    public static StatsManager getInstance() {
        if (instance == null) {
            instance = new StatsManager();
        }
        return instance;
    }

    public static void reset() {
        instance = null;
    }

    public Object put(StatsKeys key, Object value) {
        return statsMap.put(key, value);
    }

    /**
     * output csv
     * 
     * @return
     */
    public String getCsv(boolean headers) {
        StringBuilder out = new StringBuilder();
        if (headers) {
            out.append(getCsvHeaders() + System.lineSeparator());
        }
        // NumberFormat formatter = new DecimalFormat("###.##");
        // formatter.setRoundingMode(RoundingMode.HALF_UP);

        for (StatsKeys key : StatsKeys.values()) {
            out.append(formatValue(statsMap.get(key)) + ";");
        }
        out.append(System.lineSeparator());
        LOGGER.info("csv for stats: " + out.toString());
        return out.toString();
    }

    private String getCsvHeaders() {
        StringBuilder out = new StringBuilder();
        for (StatsKeys key : StatsKeys.values()) {
            out.append(key + ";");
        }
        return out.toString();
    }

    @Override
    public String toString() {
        StringBuilder out = new StringBuilder();
        out.append(String.format("\n ---stats--- \n"));
        for (StatsKeys key : StatsKeys.values()) {
            out.append(String.format("%-50s %s \n", key,
                    formatValue(statsMap.get(key))));
        }
        out.append(String.format("\n ---end stats--- \n"));
        return out.toString();
    }

    private String formatValue(Object object) {
        if (object == null) {
            return "";
        }
        if (object instanceof Integer || object instanceof Float
                || object instanceof Double) {
            return numberFormatter.format(object);
        }
        return object.toString();
    }
}
