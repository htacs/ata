package ata.simulation;

import java.net.URI;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSetMultimap;
import com.google.common.collect.SetMultimap;

import ata.assigner.AssignerFactory;
import ata.configuration.ConfigurationLoader;
import ata.database.AMTDataLoader;
import ata.motivation.CalcMotivation;
import ata.motivation.CalcPayment;
import ata.motivation.CalcRelevance;
import ata.motivation.CalcSkillVariety;
import ata.task.TasksJobsTools;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;
import ata.worker.WorkerGenerator;

/**
 * to execute tests
 *
 */
public class MainIterationsSimulator {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(MainIterationsSimulator.class);

    private final static int NB_ITERATIONS = 5;

    private final static int NB_TASKS_PER_JOB = 10;
    private final static int NB_DIFFERENT_JOBS_TO_USE = 50;

    private final static int NB_WORKERS = 4;
    private final static int NB_KEYWORDS_PER_WORKER = 6;

    private final static int NB_TASKS_COMPLETED_DURING_ITERATION = 8;

    private final static String CONFIG_ARG_NAME = "config";

    private final static AssignerFactory.method METHOD_TO_TEST = AssignerFactory.method.MaxQAPArkinGreedyMatching;

    private final static Double ONE = Double.valueOf(1.0);
    private final static Double ZERO = Double.valueOf(0.0);

    private final static Double FORCED_ALPHA = ZERO;

    private final static Double FORCED_BETA = ONE;

    public static void main(String[] args) throws Exception {
        Options options = new Options();
        options.addOption(new Option(CONFIG_ARG_NAME, true,
                "path to the xml config file"));
        DefaultParser parser = new DefaultParser();
        CommandLine line = parser.parse(options, args);
        String configFile = line.getOptionValue(CONFIG_ARG_NAME);
        // get params
        ConfigurationLoader.loadOrGetConfigurationLoader(new URI(configFile));

        // fetch and generate data
        LOGGER.info("---");
        LOGGER.info("loading data");
        ImmutableSet<Job> immutableJobs = ImmutableSet.copyOf(OfflineSimulator
                .loadАМТJobs(ConfigurationLoader.getConfiguration()
                        .getInt(ConfigurationLoader.KEY_NB_AMT_ROWS)));

        int nbJobsFetched = immutableJobs.size();
        LOGGER.info("{} jobs loaded", nbJobsFetched);
        LOGGER.debug("jobs hashcode: {}",
                TasksJobsTools.genJobsHashCodeOrderIndependent(immutableJobs));
        LOGGER.info("---");

        // prepare tools that require pre processing
        CalcSkillVariety csv = CalcSkillVariety.getInstance(immutableJobs);
        CalcPayment cp = CalcPayment.getInstance(immutableJobs);
        CalcRelevance cr = CalcRelevance.getInstance();
        CalcMotivation.getInstance(csv, cp, cr);

        boolean useReseededRandom = ConfigurationLoader.getConfiguration()
                .getBoolean(ConfigurationLoader.KEY_USE_RESEEDED_DATA_GEN);
        // task generation with the desired number of tasks per job
        // sample jobs
        LOGGER.info("sampling jobs...");
        LOGGER.info("using reseeded random:{}", useReseededRandom);
        Set<Job> randomJobs = TasksJobsTools.getRandomSubsetOfJobs(
                immutableJobs, NB_DIFFERENT_JOBS_TO_USE, useReseededRandom);
        LOGGER.info("sampled {} jobs", randomJobs.size());

        LOGGER.info("generating tasks...");
        SetMultimap<Job, Task> mutableGeneratedJobs = AMTDataLoader
                .generateNbTasks(randomJobs, NB_TASKS_PER_JOB, true);
        LOGGER.info("generated {} tasks for {} jobs",
                mutableGeneratedJobs.size(),
                mutableGeneratedJobs.keySet().size());
        ImmutableSetMultimap<Job, Task> immutableGeneratedJobs = ImmutableSetMultimap
                .copyOf(mutableGeneratedJobs);

        LOGGER.debug("-----");
        LOGGER.debug("jobs are generated: OK");
        LOGGER.debug("hashcode for jobs: {}",
                TasksJobsTools.genJobsHashCodeOrderIndependent(
                        mutableGeneratedJobs.keySet()));
        LOGGER.debug("tasks are generated: OK");
        LOGGER.debug("hashcode for tasks: {}",
                TasksJobsTools.genTasksHashCodeOrderIndependent(
                        mutableGeneratedJobs.values()));
        LOGGER.debug("----");

        // get keywords from this data
        Set<String> availableKeywords = TasksJobsTools
                .getAllKeywordsFromJobs(mutableGeneratedJobs.keySet());

        // create workers
        Set<Worker> workersGenerated = WorkerGenerator.generateWorkers(
                NB_WORKERS, availableKeywords, NB_KEYWORDS_PER_WORKER);

        // run simulation
        LOGGER.info("instantiating simulator...");
        IterationsSimulator simulator = new IterationsSimulator(NB_ITERATIONS,
                METHOD_TO_TEST, FORCED_ALPHA, FORCED_BETA,
                NB_TASKS_COMPLETED_DURING_ITERATION);

        LOGGER.info("starting simulation");
        simulator.runSimulation(immutableGeneratedJobs, workersGenerated);
        LOGGER.info("simulation done");

    }

}
