package ata.simulation;

import java.util.HashMap;
import java.util.Map;

public class TimerManager {

	private static Map<String, Timer> measures;

	private static TimerManager instance = null;

	private TimerManager() {

	}

	public static TimerManager getInstance() {
		if (instance != null) {
			return instance;
		}
		init();
		return new TimerManager();
	}

	public static void init() {
		measures = new HashMap<>();
	}

	public static void reset() {
		measures.clear();
	}

	public static void start(StatsKeys key) {
		Timer timer = new Timer();
		timer.start();
		measures.put(key.toString(), timer);
	}

	public static long endAndGetDuration(StatsKeys key) {
		return measures.get(key.toString()).end().duration();
	}

}
