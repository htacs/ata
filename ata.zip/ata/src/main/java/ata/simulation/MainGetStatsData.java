package ata.simulation;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.configuration.ConfigurationLoader;
import ata.database.ConnectionManager;
import ata.task.TasksJobsTools;
import ata.task.jobs.Job;

public class MainGetStatsData {
    private final static Logger LOGGER = LoggerFactory
            .getLogger(MainGetStatsData.class);
    private final static String CONFIG_ARG_NAME = "config";
    private final static int NB_AMT_ROWS = 100;

    public static void main(String[] args)
            throws ParseException, URISyntaxException, IOException {
        Options options = new Options();
        options.addOption(new Option(CONFIG_ARG_NAME, true,
                "path to the xml config file"));

        DefaultParser parser = new DefaultParser();
        CommandLine line = parser.parse(options, args);
        String configFile = line.getOptionValue(CONFIG_ARG_NAME);

        ConfigurationLoader.loadOrGetConfigurationLoader(new URI(configFile));

        Set<Job> allAMTJobs = loadData(configFile);

        printStats(allAMTJobs);

    }

    private static Set<Job> loadData(String configFile)
            throws URISyntaxException, IOException {
        ConnectionManager cm = new ConnectionManager(
                ConfigurationLoader.KEY_DB_AMTDATA);

        // load ALL data (see config.xml for %rows that are fetched)
        // ----------------------------------------------
        LOGGER.info("---");
        LOGGER.info("loading data");
        Set<Job> jobs = OfflineSimulator.loadАМТJobs(NB_AMT_ROWS);

        LOGGER.info("{} jobs loaded", jobs.size());
        LOGGER.debug("jobs hashcode: {}",
                TasksJobsTools.genJobsHashCodeOrderIndependent(jobs));
        LOGGER.info("---");
        cm.stopConnection();
        return jobs;
    }

    private static void printStats(Set<Job> jobs) {
        int sumNbKw = 0, minNbKw = Integer.MAX_VALUE,
                maxNbKw = Integer.MIN_VALUE;

        for (Job j : jobs) {
            int nbKw = j.getKeywords().size();
            sumNbKw += nbKw;
            minNbKw = Math.min(minNbKw, nbKw);
            maxNbKw = Math.max(maxNbKw, nbKw);
        }
        System.out.printf("avg nb Kw: %.2f \n", (double) sumNbKw / jobs.size());
        System.out.printf("min nb Kw: %d \n", minNbKw);
        System.out.printf("max nb Kw: %d \n", maxNbKw);

    }
}
