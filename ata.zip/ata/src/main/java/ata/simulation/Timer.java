package ata.simulation;

public class Timer {

	private long start;

	private long end;

	public Timer start() {
		start = System.nanoTime();
		return this;
	}

	public Timer end() {
		end = System.nanoTime();
		return this;
	}

	public long duration() {
		return end - start;
	}

}
