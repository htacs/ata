package ata.simulation;

public enum StatsKeys {

    DATETIME,

    LONGID,

    ERROR,

    METHOD_NAME,

    EXPERIMENT_GROUP,

    EXPERIMENT_SUBGROUP,

    NB_TASKS, NB_WORKERS,

    MIN_NB_TASKS_PER_WORKER,

    MAX_NB_TASKS_PER_WORKER,

    ACTUAL_MAX_NB_TASKS_PER_WORKER,

    WORKERS_PARAMS_ID,

    WORKERS_PARAMS_ID_TO_STRING,

    NB_DIFFERENT_JOBS,

    NB_WORKERS_WITH_TASKS,

    AVG_ALPHA,

    AVG_BETA,

    /*
     * time measures: in MILISECONDS
     */

    /**
     * put the edges in an array and sort it
     */
    TIME_Assignment_Detail_MaxQAPArkin_Matching_GetAndSortEdges,
    /**
     * time for matching
     */
    TIME_Assignment_Detail_MaxQAPArkin_Matching_GreedyMatching,
    /**
     * time to setup the lsap
     */
    TIME_Assignment_Detail_MaxQAPArkin_LSAP_Setup_BAndDegrees,
    /**
     * time to setup the lsap
     */
    TIME_Assignment_Detail_MaxQAPArkin_LSAP_Setup_Build,
    /**
     * time to setup the lsap
     */
    TIME_Assignment_Detail_MaxQAPArkin_LSAP_Setup_Sort,

    /**
     * time to solve lsap (hungarian, greedy...)
     */
    TIME_Assignment_Detail_MaxQAPArkin_LSAP_Solve,
    /**
     * time to compute permutation (last lines)
     */
    TIME_Assignment_Detail_MaxQAPArkin_Switch,

    /**
     * total time of the algorithm, without the setup phase, may include the
     * time to count values (see the MaxQAP algo)
     */
    TIME_Assignment_Exec,

    /**
     * time to setup the overall problem (e.g. update the mapping in
     * maxqaparkin). Does not include the preparation of edges.
     */
    TIME_Assignment_Setup,

    /**
     * total time to assign (~= {@link #TIME_Assignment_Exec} +
     * {@link #TIME_Assignment_Setup})
     */
    TIME_Assignment,

    /*
     * others
     */
    VALUE_Motivation_Value,

    /**
     * upper bound on the motivation value. Depends only on the number of
     * workers and maxNbTasksPerWorker
     */
    VALUE_UPPER_BOUND_Motivation_Value,

    /**
     * upper bound on the motivation value. Depends only on the number of
     * workers and maxNbTasksPerWorker
     */
    VALUE_UPPER_BOUND_Motivation_Value_ACTUAL_NB_TASKS,

    /**
     * nb of tasks assigned
     */
    VALUE_NB_TASKS_ASSIGNED,

    /**
     * nb of zeros in the cost matrix
     */
    LSAP_NB_VALUES_AT_ZERO,

    /**
     * nb of different values in the cost matrix
     */
    LSAP_NB_DIFFERENT_VALUES,

    /**
     * time to count these values
     */
    TIME_COUNT_VALUES,
    
    /**
     * counts nb of calls to the augment path method
     */
    HUNGARIAN_NB_CALLS_TO_AUGMENT_PATH,
    
    /**
     * nb of vertices covered by the initial solution
     */
    HUNGARIAN_NB_VERTICES_COVERED_AT_INIT
    

}
