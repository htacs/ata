package ata.simulation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSetMultimap;

import ata.assignments.AssignerToken;
import ata.assignments.Assignment;
import ata.assignments.AssignmentService;
import ata.assignments.ServicesBuilder;
import ata.assignments.TaskManager;
import ata.assignments.WorkersAndAssignmentMonitor;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/**
 * simulates the asynchronous task assignment
 */
class AssignmentServicesSimulator {
    private static Logger LOGGER = LoggerFactory
            .getLogger(AssignmentServicesSimulator.class);

    public static AtomicInteger ASSIGNMENT_DB_ID_GENERATOR = new AtomicInteger(
            0);

    private final static int TIMEOUT_WORKERS_RUNNABLE_MINUTES = 10;

    private final TimeUnit TIMEOUT_WORKERS_TIMEUNIT = TimeUnit.MINUTES;

    /**
     * a worker should be reassigned only if she has completed more than x tasks
     */
    private final int minNbCompletedAssignmentsForIteration;

    /**
     * we wait to have x completed tasks before doing an iteration
     */
    private final int nbAssignmentsAddedBetweenNotification;

    /**
     * nb of tasks to complete
     */
    private final int nbTasksToComplete;

    /**
     * tasks completed
     */
    private AtomicInteger tasksCompletedCounter;

    /**
     * 
     */
    private TaskManager taskManager;

    public TaskManager getTaskManager() {
        return taskManager;
    }

    /**
     * 
     */
    private WorkersAndAssignmentMonitor waMonitor;

    /**
     * 
     */
    private AssignmentService assignService;

    /**
     * map worker -> runnable. Each runnable get planned assignments and
     * complete an assignment
     */
    private Map<Worker, WorkerCallable> workersRunnables;

    /**
     * 
     */
    private Map<Worker, Integer> latestIterationIndices;

    /**
     * 
     */
    private Map<Worker, Map<Integer, Assignment>> allCurrentAssigments;

    public AssignmentServicesSimulator(
            int nbAssignmentsAddedBetweenNotification,
            int minNbCompletedAssignmentsForIteration, int nbTasksToComplete) {
        super();
        this.nbAssignmentsAddedBetweenNotification = nbAssignmentsAddedBetweenNotification;
        this.minNbCompletedAssignmentsForIteration = minNbCompletedAssignmentsForIteration;
        this.nbTasksToComplete = nbTasksToComplete;
        this.tasksCompletedCounter = new AtomicInteger(0);
        this.latestIterationIndices = new ConcurrentHashMap<>();
        this.allCurrentAssigments = new ConcurrentHashMap<>();
        this.workersRunnables = new ConcurrentHashMap<>();
    }

    /**
     * runs the simulation
     */
    public void runSimulation(ImmutableSetMultimap<Job, Task> immutableJobs,
            Set<Worker> workers, Map<Worker, AssignerToken> tokens) {
        LOGGER.info("simulation started");
        initServices(immutableJobs);
        initWorkersRunnables(workers);
        // initialization: add all workers as unknown workers
        for (Worker worker : workers) {
            waMonitor.putToken(worker, tokens.get(worker));
            waMonitor.addUnknownWorker(worker);
            LOGGER.info("added worker {} as unknown worker", worker.getId());
        }
        // build an executor service
        LOGGER.info("running workers callables");
        ExecutorService execServ = Executors.newFixedThreadPool(workers.size());
        List<Future<Integer>> allFutureCallable = new ArrayList<>(
                workers.size());
        for (WorkerCallable wr : workersRunnables.values()) {
            allFutureCallable.add(execServ.submit(wr));
            // we could use invokeAll, but we couldn't simulate different
            // arrival times using sleep() inside each callable.
        }
        // try {
        // allFutureCallable.add(execServ.submit(workersRunnables))
        // allFutureCallable = execServ.invokeAll(workersRunnables.values());
        // } catch (InterruptedException e1) {
        // LOGGER.error("interruption of workers callable");
        // }
        execServ.shutdown();

        try {
            execServ.awaitTermination(TIMEOUT_WORKERS_RUNNABLE_MINUTES,
                    TIMEOUT_WORKERS_TIMEUNIT);
        } catch (InterruptedException e1) {
            LOGGER.error("interruption of workers callable executor service");
        }

        int nbTasksCompleted = 0;

        for (Future<Integer> futureWorkerCallable : allFutureCallable) {
            try {
                nbTasksCompleted += futureWorkerCallable.get();
            } catch (InterruptedException | ExecutionException e) {
                LOGGER.error("interuption of futureWorkerCallable", e);
            }
        }

        // stop assignment service
        assignService.stop();

        // try {
        // assignService.getNbIterationFromFuture();
        // } catch (InterruptedException | ExecutionException e) {
        // LOGGER.error("there were an error during assignment", e);
        // }
        LOGGER.info("----");
        LOGGER.info("{} tasks completed", nbTasksCompleted);
        LOGGER.info("simulation finished");
    }

    private void initServices(ImmutableSetMultimap<Job, Task> immutableJobs) {
        LOGGER.info("initializing services...");
        // init tasks and graph here
        this.taskManager = ServicesBuilder.newSynchronizedTaskManager();
        this.taskManager.initAll(immutableJobs);
        this.waMonitor = ServicesBuilder
                .newSynchronizedWorkersAndAssignmentMonitor(
                        nbAssignmentsAddedBetweenNotification,
                        minNbCompletedAssignmentsForIteration);
        this.assignService = ServicesBuilder.newAssignmentService(taskManager,
                waMonitor);

        this.waMonitor.setAssignmentService(this.assignService);
        this.assignService.start();

        LOGGER.info("initializing services done.");
    }

    private void initWorkersRunnables(Set<Worker> workers) {
        LOGGER.info("initializing worker threads...");
        for (Worker w : workers) {
            this.latestIterationIndices.put(w, -1);
            this.allCurrentAssigments.put(w, new HashMap<>());
        }
        for (Worker worker : workers) {
            workersRunnables.put(worker, new WorkerCallable(worker, this));
        }
        LOGGER.info("initializing worker threads done.");
    }

    public static int getMaxRetriesWaitForAssignments() {
        return MainAssignmentServicesSimulator.MAX_RETRIES_WAIT_FOR_ASSIGNMENTS_MS;
    }

    public static int getWaitingTimeAssignmentsMs() {
        return MainAssignmentServicesSimulator.WAITING_TIME_ASSIGNMENTS_MS;
    }

    public int getMinNbCompletedAssignmentsForIteration() {
        return minNbCompletedAssignmentsForIteration;
    }

    public int getNbAssignmentsAddedBetweenNotification() {
        return nbAssignmentsAddedBetweenNotification;
    }

    public int getNbTasksToComplete() {
        return nbTasksToComplete;
    }

    public AtomicInteger getTasksCompletedCounter() {
        return tasksCompletedCounter;
    }

    public WorkersAndAssignmentMonitor getWaMonitor() {
        return waMonitor;
    }

    public AssignmentService getAssignService() {
        return assignService;
    }

    public Map<Worker, Integer> getLatestIterationIndices() {
        return latestIterationIndices;
    }

    public Map<Worker, Map<Integer, Assignment>> getAllCurrentAssigments() {
        return allCurrentAssigments;
    }

}
