package ata.simulation;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSetMultimap;
import com.google.common.collect.SetMultimap;

import ata.assigner.AssignerFactory;
import ata.assignments.AssignerToken;
import ata.assignments.AssignmentMethod;
import ata.configuration.ConfigurationLoader;
import ata.database.AMTDataLoader;
import ata.motivation.CalcMotivation;
import ata.motivation.CalcPayment;
import ata.motivation.CalcRelevance;
import ata.motivation.CalcSkillVariety;
import ata.task.TasksJobsTools;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;
import ata.worker.WorkerGenerator;

/**
 * tool to execute tests on assignment services
 *
 */
public class MainAssignmentServicesSimulator {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(MainAssignmentServicesSimulator.class);

    private final static int NB_TASKS_TO_COMPLETE = 500;

    private final static int NB_TASKS_PER_JOB = 20;
    private final static int NB_DIFFERENT_JOBS_TO_USE = 100;

    private final static int NB_ASSIGNMENTS_ADDED_BETWEEN_NOTIFICATION = 5;
    private final static int MIN_NB_COMPLETED_ASSIGNMENTS_FOR_ITERATION = 8;

    private final static int NB_WORKERS = 10;
    private final static int NB_KEYWORDS_PER_WORKER = 5;

    public final static int MAX_RETRIES_WAIT_FOR_ASSIGNMENTS_MS = 10;

    /**
     * how much time a worker waits for new assignments during each "retry loop"
     */
    public final static int WAITING_TIME_ASSIGNMENTS_MS = 500;

    /**
     * we instantiate worker runnable each x unit of time
     */
    public final static int SLEEP_TIME_MS_BETWEEN_WORKERS_MS = 1000;

    /**
     * a worker will spent at least this amount of time to complete the task
     */
    public final static int COMPLETE_TASKS_MIN_TIME_MS = 1000;
    /**
     * a worker will spent at most this amount of time to complete the task
     */
    public final static int COMPLETE_TASKS_MAX_TIME_MS = 2000;

    /**
     * make the assignment last longer
     */
    public final static int WAIT_TIME_IN_ASSIGNMENT_FORCED_MS = 0;

    private final static String CONFIG_ARG_NAME = "config";

    private final static AssignerFactory.method METHOD_TO_TEST = AssignerFactory.method.MaxQAPArkinGreedyMatching;

    public static void main(String[] args) throws Exception {
        Options options = new Options();
        options.addOption(new Option(CONFIG_ARG_NAME, true,
                "path to the xml config file"));
        DefaultParser parser = new DefaultParser();
        CommandLine line = parser.parse(options, args);
        String configFile = line.getOptionValue(CONFIG_ARG_NAME);
        // get params
        ConfigurationLoader.loadOrGetConfigurationLoader(new URI(configFile));

        // fetch and generate data
        LOGGER.info("---");
        LOGGER.info("loading data");
        ImmutableSet<Job> immutableJobs = ImmutableSet.copyOf(OfflineSimulator
                .loadАМТJobs(ConfigurationLoader.getConfiguration()
                        .getInt(ConfigurationLoader.KEY_NB_AMT_ROWS)));

        int nbJobsFetched = immutableJobs.size();
        LOGGER.info("{} jobs loaded", nbJobsFetched);
        LOGGER.debug("jobs hashcode: {}",
                TasksJobsTools.genJobsHashCodeOrderIndependent(immutableJobs));
        LOGGER.info("---");

        // prepare tools that require pre processing
        CalcSkillVariety csv = CalcSkillVariety.getInstance(immutableJobs);
        CalcPayment cp = CalcPayment.getInstance(immutableJobs);
        CalcRelevance cr = CalcRelevance.getInstance();
        CalcMotivation.getInstance(csv, cp, cr);

        boolean useReseededRandom = ConfigurationLoader.getConfiguration()
                .getBoolean(ConfigurationLoader.KEY_USE_RESEEDED_DATA_GEN);
        // task generation with the desired number of tasks per job
        // sample jobs
        LOGGER.info("sampling jobs...");
        Set<Job> randomJobs = TasksJobsTools.getRandomSubsetOfJobs(
                immutableJobs, NB_DIFFERENT_JOBS_TO_USE, useReseededRandom);
        LOGGER.info("sampled {} jobs", randomJobs.size());

        LOGGER.info("generating tasks...");
        SetMultimap<Job, Task> mutableGeneratedJobs = AMTDataLoader
                .generateNbTasks(randomJobs, NB_TASKS_PER_JOB, true);
        LOGGER.info("generated {} tasks for {} jobs",
                mutableGeneratedJobs.size(),
                mutableGeneratedJobs.keySet().size());
        ImmutableSetMultimap<Job, Task> immutableGeneratedJobs = ImmutableSetMultimap
                .copyOf(mutableGeneratedJobs);

        LOGGER.debug("-----");
        LOGGER.debug("jobs are generated: OK");
        LOGGER.debug("hashcode for jobs: {}",
                TasksJobsTools.genJobsHashCodeOrderIndependent(
                        mutableGeneratedJobs.keySet()));
        LOGGER.debug("tasks are generated: OK");
        LOGGER.debug("hashcode for tasks: {}",
                TasksJobsTools.genTasksHashCodeOrderIndependent(
                        mutableGeneratedJobs.values()));
        LOGGER.debug("----");

        // get keywords from this data
        Set<String> availableKeywords = TasksJobsTools
                .getAllKeywordsFromJobs(mutableGeneratedJobs.keySet());

        // create workers
        Set<Worker> workersGenerated = WorkerGenerator.generateWorkers(
                NB_WORKERS, availableKeywords, NB_KEYWORDS_PER_WORKER);

        // tokens
        Map<Worker, AssignerToken> tokens = new HashMap<>();
        for (Worker w : workersGenerated) {
            AssignerToken token = new AssignerToken("test",
                    new AssignmentMethod(METHOD_TO_TEST, null, null), true);
            tokens.put(w, token);
        }

        // run simulation
        LOGGER.info("instantiating simulator...");
        AssignmentServicesSimulator simulator = new AssignmentServicesSimulator(
                NB_ASSIGNMENTS_ADDED_BETWEEN_NOTIFICATION,
                MIN_NB_COMPLETED_ASSIGNMENTS_FOR_ITERATION,
                NB_TASKS_TO_COMPLETE);

        LOGGER.info("starting simulation");
        simulator.runSimulation(immutableGeneratedJobs, workersGenerated,
                tokens);
        LOGGER.info("simulation done");

    }

}
