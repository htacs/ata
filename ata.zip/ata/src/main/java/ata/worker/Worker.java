package ata.worker;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.misc.CompOps;

public class Worker {

    private final static Logger logger = LoggerFactory.getLogger(Worker.class);

    /**
     * unique id, immutable.
     */
    private final String id;

    /**
     * list of preferred keywords. mutable but should be modified only once.
     */
    private Set<String> keywords;

    /**
     * her alpha. not serialized. mutable.
     */
    private double alpha;

    /**
     * same thing, not serialized. mutable.
     */
    private double beta;

    public void setKeywords(Set<String> keywords) {
        this.keywords = new HashSet<>(keywords);
    }

    public void setKeywords(String[] keywords) {
        this.keywords = new HashSet<>();
        for (String s : keywords) {
            this.keywords.add(s);
        }
    }

    /********** constructors ****************/

    public Worker(String id) {
        this.id = id;
        this.keywords = new HashSet<>();
    }

    public Worker(String id, Set<String> keywords, double alpha, double beta) {
        super();
        this.id = id;
        this.keywords = new HashSet<>(keywords);
        this.alpha = alpha;
        this.beta = beta;
    }

    /**
     * deep copy. assumes that keywords are copied in
     * {@link #Worker(String, Set, double, double)}
     * 
     * @param worker
     * @return a copy of the specified <b>worker</b>
     */
    public static Worker of(Worker worker) {
        return new Worker(worker.id, worker.keywords, worker.alpha,
                worker.beta);
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder("wID: " + id + " - alpha: "
                + (double) Math.round(alpha * 1000) / 1000 + " - beta: "
                + (double) Math.round(beta * 1000) / 1000 + " keywords:{");
        for (String s : keywords) {
            sb.append(s + ",");
        }
        return sb.append("}").toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Worker other = (Worker) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

    /********* Setters ********/

    public void setAlpha(double alpha) {
        boolean gegZero = CompOps.geq(alpha, 0);
        boolean leqOne = CompOps.leq(alpha, 1);
        if (!(gegZero && leqOne)) {
            logger.warn(
                    "alpha not in [0,1] : " + this.toString() + " : " + alpha);
        }
        this.alpha = alpha;
    }

    public void setBeta(double beta) {
        boolean gegZero = CompOps.geq(beta, 0);
        boolean leqOne = CompOps.leq(beta, 1);
        if (!(gegZero && leqOne)) {
            logger.warn(
                    "beta not in [0,1] : " + this.toString() + " : " + beta);
        }
        this.beta = beta;
    }

    /********* Getters ***********/

    // public DateTime getFirstSeen() {
    // return firstSeen;
    // }
    //
    // public DateTime getLastSeen() {
    // return lastSeen;
    // }

    public String getId() {
        return id;
    }

    public Set<String> getKeywords() {
        return keywords;
    }

    public double getAlpha() {
        return alpha;
    }

    public double getBeta() {
        return beta;
    }

}
