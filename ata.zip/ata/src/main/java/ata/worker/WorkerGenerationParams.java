package ata.worker;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public final class WorkerGenerationParams {

    private final String id;

    private final int nbWorkers;

    private final int nbKeywordsPerWorker;

    private final double minAlpha;

    private final double maxAlpha;

    private final double minBeta;

    private final double maxBeta;

    private final double percentKeywords;

    public WorkerGenerationParams(String id, int nbWorkers,
            int nbKeywordsPerWorker, double minAlpha, double maxAlpha,
            double minBeta, double maxBeta, double percentKeywords) {
        super();
        this.id = id;
        this.nbWorkers = nbWorkers;
        this.nbKeywordsPerWorker = nbKeywordsPerWorker;
        validateZeroOneValues(minAlpha, maxAlpha, minBeta, maxBeta,
                percentKeywords);
        this.minAlpha = minAlpha;
        this.maxAlpha = maxAlpha;
        this.minBeta = minBeta;
        this.maxBeta = maxBeta;
        this.percentKeywords = percentKeywords;
    }

    /**
     * read all worker params from csv file
     * 
     * @param filePath
     * @return
     * @throws IOException
     */
    public static Table<String, Integer, WorkerGenerationParams> readWorkerGenerationParams(
            String filePath) throws IOException {

        Table<String, Integer, WorkerGenerationParams> out = HashBasedTable
                .create();
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = br.readLine()) != null) {
            String[] split = line.split(";");
            String mainId = split[5];
            String subId = split[6];
            int group = Integer.valueOf(split[7]);
            int nbWorkers = Integer.valueOf(split[8]);
            int nbKeywordsPerWorker = Integer.valueOf(split[9]);
            double minAlpha = Double.valueOf(split[10].replace(",", "."));
            double maxAlpha = Double.valueOf(split[11].replace(",", "."));
            double minBeta = Double.valueOf(split[12].replace(",", "."));
            double maxBeta = Double.valueOf(split[13].replace(",", "."));
            double percentKeywords = Double
                    .valueOf(split[14].replace(",", "."));
            WorkerGenerationParams current = new WorkerGenerationParams(mainId,
                    nbWorkers, nbKeywordsPerWorker, minAlpha, maxAlpha, minBeta,
                    maxBeta, percentKeywords);
            out.put(subId, group, current);
        }
        br.close();
        return out;
    }

    private void validateZeroOneValues(double... values) {
        for (double value : values) {
            if (value < 0.0 || value > 1.0) {
                throw new IllegalArgumentException("value not in range [0,1]");
            }
        }
    }

    public String getId() {
        return id;
    }

    public int getNbWorkers() {
        return nbWorkers;
    }

    public int getNbKeywordsPerWorker() {
        return nbKeywordsPerWorker;
    }

    public double getMinAlpha() {
        return minAlpha;
    }

    public double getMaxAlpha() {
        return maxAlpha;
    }

    public double getMinBeta() {
        return minBeta;
    }

    public double getMaxBeta() {
        return maxBeta;
    }

    public double getPercentKeywords() {
        return percentKeywords;
    }

    @Override
    public String toString() {
        return "WorkerGenerationParams [id=" + id + ", nbWorkers=" + nbWorkers
                + ", nbKeywordsPerWorker=" + nbKeywordsPerWorker + ", minAlpha="
                + minAlpha + ", maxAlpha=" + maxAlpha + ", minBeta=" + minBeta
                + ", maxBeta=" + maxBeta + ", percentKeywords="
                + percentKeywords + "]";
    }
    

}
