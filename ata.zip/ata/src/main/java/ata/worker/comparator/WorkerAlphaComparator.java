package ata.worker.comparator;

import java.util.Comparator;

import ata.worker.Worker;

/**
 * compares worker using their alpha
 *
 */
public class WorkerAlphaComparator implements Comparator<Worker> {

	private static WorkerAlphaComparator instance = null;

	private WorkerAlphaComparator() {

	}

	public static WorkerAlphaComparator getInstance() {
		if (instance != null) {
			return instance;
		}
		return new WorkerAlphaComparator();
	}

	@Override
	public int compare(Worker o1, Worker o2) {
		int comp = Double.compare(o1.getAlpha(), o2.getAlpha());
		if (comp == 0) {
			return o1.getId().compareTo(o2.getId());
		}
		return comp;
	}

}
