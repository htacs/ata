package ata.worker.comparator;

import java.util.Comparator;

import ata.worker.Worker;

/**
 * compares worker using their alpha
 * 
 */
public class WorkerBetaComparator implements Comparator<Worker> {

	private static WorkerBetaComparator instance = null;

	private WorkerBetaComparator() {

	}

	public static WorkerBetaComparator getInstance() {
		if (instance != null) {
			return instance;
		}
		return new WorkerBetaComparator();
	}

	@Override
	public int compare(Worker o1, Worker o2) {
		int comp = Double.compare(o1.getBeta(), o2.getBeta());
		if (comp == 0) {
			return o1.getId().compareTo(o2.getId());
		}
		return comp;
	}

}
