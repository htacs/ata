package ata.worker.comparator;

import java.util.Comparator;

import ata.worker.Worker;

/**
 * compares worker using their alpha
 *
 *
 */
public class WorkerIdComparator implements Comparator<Worker> {

    private static WorkerIdComparator instance = null;

    private WorkerIdComparator() {

    }

    public static WorkerIdComparator getInstance() {
        if (instance != null) {
            return instance;
        }
        return new WorkerIdComparator();
    }

    @Override
    public int compare(Worker o1, Worker o2) {
        return o1.getId().compareTo(o2.getId());
    }

}
