package ata.worker;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.math3.random.RandomDataGenerator;
import org.apache.commons.math3.random.Well19937a;

import ata.misc.CompOps;
import ata.misc.RandomGeneratorCustom;
import ata.task.TasksJobsTools;
import gnu.trove.set.hash.THashSet;

public final class WorkerGenerator {

    // private final static Logger LOGGER = LoggerFactory
    // .getLogger(WorkerGenerator.class);

    private final static int SEED = 1234567;

    /**
     * generate workers using the given params
     * 
     * @param nbWorkers
     * @param availableKeywords
     * @param nbKeywordsPerWorker
     * @return
     */
    public static Set<Worker> generateWorkers(int nbWorkers,
            Set<String> availableKeywords, int nbKeywordsPerWorker) {
        // reseed random
        RandomGeneratorCustom.getInstance().reseedRandom();
        Set<Worker> out = new HashSet<>();
        List<String> availableKeywordsList = new ArrayList<>(availableKeywords);

        for (int i = 0; i < nbWorkers; i++) {
            // pick alpha

            double alpha = RandomGeneratorCustom.getInstance()
                    .getReseededRandom().nextDouble();
            // pick beta
            double beta = RandomGeneratorCustom.getInstance()
                    .getReseededRandom().nextDouble();
            // pick keywords
            Set<String> keywords = new THashSet<>();

            for (int j = 0; j < nbKeywordsPerWorker; j++) {
                keywords.add(availableKeywordsList.get(
                        RandomGeneratorCustom.getInstance().getReseededRandom()
                                .nextInt(availableKeywords.size() - 1)));
            }
            out.add(new Worker(String.valueOf(i), keywords, alpha, beta));
        }

        return out;

    }

    /**
     * generate groups of worker given the params (json) and keywords in input
     * 
     * @param jsonFile
     * @param availableKeywords
     * @return
     */
    public static Set<Worker> generateWorkers(
            Collection<WorkerGenerationParams> params,
            Set<String> availableKeywords, boolean useReseededRandom) {
        Set<Worker> out = new HashSet<>();
        for (WorkerGenerationParams param : params) {
            out.addAll(generateWorkers(param, availableKeywords,
                    useReseededRandom));
        }
        return out;

    }

    private static Set<Worker> generateWorkers(WorkerGenerationParams params,
            Set<String> availableKeywords, boolean useReseededRandom) {
        RandomDataGenerator rdg = null;
        if (useReseededRandom) {
            rdg = new RandomDataGenerator(new Well19937a(SEED));
        } else {
            rdg = new RandomDataGenerator();
        }
        List<String> availableKeywordsList = new ArrayList<>(
                TasksJobsTools.getSubsetOfKeywords(availableKeywords,
                        params.getPercentKeywords()));

        Set<Worker> out = new HashSet<>();
        for (int i = 0; i < params.getNbWorkers(); i++) {
            // pick alpha
            double alpha;
            if (CompOps.eq(params.getMinAlpha(), params.getMaxAlpha())) {
                alpha = params.getMaxAlpha();
            } else {
                alpha = rdg.nextUniform(params.getMinAlpha(),
                        params.getMaxAlpha(), true);
            }
            // pick beta
            double beta;
            if (CompOps.eq(params.getMinBeta(), params.getMaxBeta())) {
                beta = params.getMaxBeta();
            } else {
                beta = rdg.nextUniform(params.getMinBeta(), params.getMaxBeta(),
                        true);
            }

            // pick keywords
            Set<String> keywords = new THashSet<>();

            for (int j = 0; j < params.getNbKeywordsPerWorker(); j++) {
                keywords.add(availableKeywordsList
                        .get(rdg.nextInt(0, availableKeywordsList.size() - 1)));
            }
            out.add(new Worker(String.valueOf(i), keywords, alpha, beta));
        }
        return out;
    }

}
