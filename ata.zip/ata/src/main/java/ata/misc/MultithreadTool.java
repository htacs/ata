package ata.misc;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MultithreadTool {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(MultithreadTool.class);

    /**
     * returns a partition of a triangular matrix into partition of similar
     * area<br/>
     * if size given = size of matrix, considers that items on the diagonal ARE
     * processed.
     * 
     * 
     * @param size
     * @return a map with two key-value entries:<br/>
     *         <ul>
     *         <li>key="min" -> an array s.t. min[i]= the lower bound of the ith
     *         partition<br/>
     *         </li>
     *         <li>key="max" -> an array s.t. max[i]= the upper bound of the ith
     *         partition</li>
     *         </ul>
     */
    public static Map<String, int[]> getIndexForMultithread(int cpus,
            int size) {
        LOGGER.debug("preparing partitions for multithread processing...");
        // int cpus = Runtime.getRuntime().availableProcessors();
        int nbDistances = size * (size + 1) / 2;
        final int blockSize = nbDistances / cpus
                + ((nbDistances % cpus == 0) ? 0 : 1);
        LOGGER.debug("cpus : {}", cpus);
        LOGGER.debug("size : {}", size);
        LOGGER.debug("nbDistances {}", nbDistances);
        LOGGER.debug("block size {}", blockSize);
        // first we partition the input space
        Double currentMin = Double.valueOf(0), currentMax = Double.valueOf(-1);
        final int[] min = new int[cpus];
        final int[] max = new int[cpus];
        for (int i = 0; i < cpus; i++) {
            currentMin = currentMax + 1;
            double a = -1;
            double b = 2 * (size) - 1;
            double c = 2 * (size) * (1 - currentMin)
                    + currentMin * (currentMin - 1) - 2 * blockSize;
            double determinant = b * b - 4 * a * c;
            if (determinant < 0) {
                currentMax = Double.valueOf(size - 1);
            } else {
                currentMax = Math.ceil((-b + Math.sqrt(determinant)) / (2 * a));
            }
            int area = new Double((currentMax - currentMin + 1) * size
                    - currentMax * (currentMax + 1) / 2
                    + (currentMin) * (currentMin - 1) / 2).intValue();
            min[i] = currentMin.intValue();
            max[i] = currentMax.intValue();
            LOGGER.info("cpu {} : {} - {} ({})", i, min[i], max[i], area);
        }
        Map<String, int[]> out = new HashMap<>();
        out.put("min", min);
        out.put("max", max);
        LOGGER.debug("preparing partitions: done");
        return out;
    }

    public static String toString(Map<String, int[]> partitions) {
        int size = partitions.get("min").length;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(String.format("cpu %d : [%d-%d]\n", i,
                    partitions.get("min")[i], partitions.get("max")[i]));
        }
        return sb.toString();

    }

}
