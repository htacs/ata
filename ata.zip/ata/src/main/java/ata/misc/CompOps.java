package ata.misc;

/**
 * double comparisons using epsilon
 */
public class CompOps {

    private CompOps() {

    }

    /**
     * default value
     */
    private static double EPSILON_DOUBLE = 1E-6;

    public static void setEpsilon(double epsilon) {
        CompOps.EPSILON_DOUBLE = epsilon;
    }

    /**
     * verifies equality
     * 
     * @param a
     * @param b
     * @param EPSILON
     * @return
     */
    public static boolean eq(double a, double b, double epsilon) {
        return a == b ? true : Math.abs(a - b) < epsilon;
    }

    /**
     * greaterThan
     * 
     * @param a
     * @param b
     * @param EPSILON
     * @return
     */
    public static boolean g(double a, double b, double epsilon) {
        return a - b > epsilon;
    }

    /**
     * greaterThan or Equal
     * 
     * @param a
     * @param b
     * @param EPSILON
     * @return
     */
    public static boolean geq(double a, double b, double epsilon) {
        return g(a, b, epsilon) || eq(a, b, epsilon);
    }

    /**
     * lessThan
     * 
     * @param a
     * @param b
     * @param EPSILON
     * @return
     */
    public static boolean l(double a, double b, double epsilon) {
        return b - a > epsilon;
    }

    /**
     * lessThan or Equal
     * 
     * @param a
     * @param b
     * @param EPSILON
     * @return
     */
    public static boolean leq(double a, double b, double epsilon) {
        return l(a, b, epsilon) || eq(a, b, epsilon);
    }

    /**
     * verifies equality
     * 
     * @param a
     * @param b
     * @return
     */
    public static boolean eq(double a, double b) {
        return eq(a, b, EPSILON_DOUBLE);
    }

    /**
     * greaterThan
     * 
     * @param a
     * @param b
     * @return
     */
    public static boolean g(double a, double b) {
        return g(a, b, EPSILON_DOUBLE);
    }

    /**
     * greaterThan or Equal
     * 
     * @param a
     * @param b
     * @return
     */
    public static boolean geq(double a, double b) {
        return geq(a, b, EPSILON_DOUBLE);
    }

    /**
     * lessThan
     * 
     * @param a
     * @param b
     * @return
     */
    public static boolean l(double a, double b) {
        return l(a, b, EPSILON_DOUBLE);
    }

    /**
     * lessThan or Equal
     * 
     * @param a
     * @param b
     * @return
     */
    public static boolean leq(double a, double b) {
        return leq(a, b, EPSILON_DOUBLE);
    }

}
