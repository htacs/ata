package ata.misc;

import java.util.Random;

public class RandomGeneratorCustom {

    private static RandomGeneratorCustom instance = null;

    private final static int SEED = 1234567;

    private static Random RANDOM;

    private static Random RANDOM_RESEEDED;

    private RandomGeneratorCustom() {

    }

    public static RandomGeneratorCustom getInstance() {
        if (instance != null) {
            return instance;
        }
        RANDOM = new Random();
        RANDOM_RESEEDED = new Random(SEED);
        instance = new RandomGeneratorCustom();
        return instance;
    }

    public Random getRandom() {
        return RANDOM;
    }

    public void reseedRandom() {
        RANDOM_RESEEDED.setSeed(SEED);
    }

    public Random getReseededRandom() {
        return RANDOM_RESEEDED;
    }

}
