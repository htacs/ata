package ata.configuration;

import java.net.URI;
import java.util.List;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * loads configuration from xml file
 */
public class ConfigurationLoader {
    private static Logger LOGGER = LoggerFactory
            .getLogger(ConfigurationLoader.class);

    /**
     * singleton
     */
    private static ConfigurationLoader instance = null;

    /**
     * parameters from config.xml
     */
    private static XMLConfiguration configuration = null;

    /**
     * list of job configs
     */
    private static TIntObjectMap<JobConfig> jobConfigs = null;

    /**
     * keys used to access configuration
     */

    /*
     * things that need to be read in the config file
     */
    public final static String KEY_NB_CF_ROWS = "nb_cf_rows_from_db";
    public final static String KEY_NB_AMT_ROWS = "nb_amt_rows_from_db";
    public final static String KEY_NB_TASKS_WEBAPP = "nb_tasks_webapp";

    public final static String KEY_MATCHING_THRESHOLD = "matchingThreshold";
    public final static String KEY_EPSILON_DOUBLE = "epsilonDouble";
    public final static String KEY_MIN_NB_TASKS = "minNbTasksPerWorker";
    public final static String KEY_MAX_NB_TASKS = "maxNbTasksPerWorker";
    public final static String KEY_NB_RANDOM_ADDITIONAL_TASKS = "nbRandomAdditionalTasks";

    public final static String KEY_ASSIGNMENT_VALIDITY = "assignment_durationValidity";
    public final static String KEY_EVALUATION_RUN = "evaluationRun";

    public final static String KEY_USE_RESEEDED_DATA_GEN = "useReseededRandomDataGeneration";

    // for web application
    public final static String KEY_MIN_KEYWORDS_WORKER = "minKeywordsPerWorker";
    // public final static String
    // KEY_PERCENT_OF_XMAX_TASKS_COMPLETED_BEFORE_ITERATION =
    // "stability_percentTasksCompletedBeforeIteration";
    public final static String KEY_RUN_ID = "runId";

    public final static String KEY_HIT_PAYMENT = "hitPayment";

    public final static String KEY_MIN_NB_TASKS_BEFORE_ITERATION = "minNbCompletedAssignmentsForIteration";
    public final static String KEY_NB_COMPLETED_BETWEEN_NOTIFICATION = "nbAssignmentsCompletedBetweenTwoIterations";

    // not used anymore, but may be used in the web application
    // public final static String KEY_INPUTFILE_PATH = "expes_inputFile_Path";
    // public final static String KEY_OUTPUTFILE_PATH = "expes_outputFile_Path";

    /*
     * other keys (for DB config)
     * 
     */
    public final static String KEY_DB_CFDATA = "taskwebapp_database";
    public final static String KEY_DB_AMTDATA = "amt_database";
    public final static String KEY_ADDRESS = "address";
    public final static String KEY_USERNAME = "username";
    public final static String KEY_PASSWORD = "password";
    public final static String KEY_DRIVER = "driver";

    private ConfigurationLoader() {

    }

    /**
     * loads configuration or return existing one if already loaded
     * 
     * @param configFilePath
     * @return
     */
    public static ConfigurationLoader loadOrGetConfigurationLoader(
            URI configFilePath) {
        if (instance != null) {
            return instance;
        }
        try {
            ConfigurationLoader.instance = new ConfigurationLoader();
            ConfigurationLoader.configuration = new XMLConfiguration(
                    configFilePath.getPath());
            ConfigurationLoader.jobConfigs = ConfigurationLoader
                    .loadJobsConfig();
        } catch (ConfigurationException e) {
            LOGGER.error("could not load configuration file from path "
                    + configFilePath.getPath(), e);
        }

        return instance;
    }

    public static ConfigurationLoader getInstance() {
        if (instance != null) {
            return instance;
        }
        throw new IllegalStateException("configuration not loaded");
    }

    public static Configuration getConfiguration() {
        if (instance != null) {
            return configuration;
        }
        throw new IllegalStateException("configuration not loaded");
    }

    public static TIntObjectMap<JobConfig> getJobConf() {
        if (instance != null) {
            return jobConfigs;
        }
        throw new IllegalStateException("configuration not loaded");
    }

    /**
     * loads the configuration for jobs
     * 
     * @return a map job id -> job configuration
     */
    private static TIntObjectMap<JobConfig> loadJobsConfig() {
        TIntObjectMap<JobConfig> out = new TIntObjectHashMap<JobConfig>();
        List<HierarchicalConfiguration> jobAssociations = configuration
                .configurationsAt("jobAssociations.jobAssociation");
        for (HierarchicalConfiguration ja : jobAssociations) {
            int id = ja.getInt("id");
            String jobClassName = ja.getString("jobClass");
            String taskClassName = ja.getString("taskClass");
            String viewName = ja.getString("view");
            JobConfig jobConf = new JobConfig(id, jobClassName, taskClassName,
                    viewName);
            out.put(id, jobConf);
        }
        return out;
    }

    @Override
    public String toString() {
        // KEY_PERCENT_OF_XMAX_TASKS_COMPLETED_BEFORE_ITERATION,
        String[] keys = new String[] { KEY_MATCHING_THRESHOLD,
                KEY_EPSILON_DOUBLE, KEY_MIN_NB_TASKS, KEY_MAX_NB_TASKS,
                KEY_ASSIGNMENT_VALIDITY, KEY_EVALUATION_RUN,
                KEY_MIN_KEYWORDS_WORKER,
                KEY_MIN_NB_TASKS_BEFORE_ITERATION,
                KEY_NB_COMPLETED_BETWEEN_NOTIFICATION, KEY_RUN_ID,
                KEY_HIT_PAYMENT, KEY_DB_CFDATA, KEY_DB_AMTDATA, KEY_ADDRESS,
                KEY_USERNAME, KEY_PASSWORD, KEY_DRIVER, KEY_NB_CF_ROWS,
                KEY_NB_AMT_ROWS, KEY_NB_TASKS_WEBAPP,
                KEY_NB_RANDOM_ADDITIONAL_TASKS };
        StringBuilder sb = new StringBuilder("---\nconfiguration:\n");
        for (String key : keys) {
            sb.append(String.format("%s : %-50s\n", key,
                    configuration.getString(key)));
        }
        sb.append("---\n");
        return sb.toString();

    }

}
