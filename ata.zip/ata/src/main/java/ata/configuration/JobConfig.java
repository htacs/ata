package ata.configuration;

import java.util.Iterator;
import java.util.Set;

import org.reflections.Reflections;

import ata.task.jobs.Job;
import ata.task.tasks.Task;

/**
 * says to which jobClass and taskClass a jobId corresponds. also defines which
 * view a job should use (web application)
 */
public class JobConfig {

    /**
     * unique id. this is not necessarily the id of the job!
     */
    private int id;
    /**
     * the job class
     */
    private Class<? extends Job> jobClass;
    /**
     * task class
     */
    private Class<? extends Task> taskClass;
    /**
     * short name of the view (no extension)
     */
    private String viewName;

    /**
     * the association 100-GenericJob-GenericTask is hardcoded!
     * 
     * @param generic
     *            if true returns generic job
     */
    public JobConfig(boolean generic) {
        if (generic) {
            this.id = 100;
            this.jobClass = ata.task.jobs.GenericJob.class;
            this.taskClass = ata.task.tasks.GenericTask.class;
            this.viewName = "genericView";
        }
    }

    /**
     * instanciates this jobConfig</br>
     * warning: costly since it uses reflection</br>
     * 
     * @param id
     * @param jobClassName
     * @param taskClassName
     */
    public JobConfig(int id, String jobClassName, String taskClassName,
            String viewName) {
        super();
        this.id = id;
        Reflections reflections = new Reflections("ata");
        // find job class
        Set<Class<? extends Job>> jobClasses = reflections
                .getSubTypesOf(Job.class);
        boolean found = false;
        Iterator<Class<? extends Job>> iterJob = jobClasses.iterator();
        while (!found && iterJob.hasNext()) {
            Class<? extends Job> current = iterJob.next();
            if (current.getSimpleName().equals(jobClassName)) {
                this.jobClass = current;
                found = true;
            }
        }
        // find task class
        Set<Class<? extends Task>> taskClasses = reflections
                .getSubTypesOf(Task.class);
        found = false;
        Iterator<Class<? extends Task>> iterTask = taskClasses.iterator();
        while (!found && iterTask.hasNext()) {
            Class<? extends Task> current = iterTask.next();
            if (current.getSimpleName().equals(taskClassName)) {
                this.taskClass = current;
                found = true;
            }
        }
        this.viewName = viewName;
    }

    public int getId() {
        return id;
    }

    public Class<? extends Job> getJobClass() {
        return jobClass;
    }

    public Class<? extends Task> getTaskClass() {
        return taskClass;
    }

    public String getViewName() {
        return viewName;
    }

    @Override
    public String toString() {
        return "id: " + id + "-jobClass: " + jobClass.getName() + "-taskClass: "
                + taskClass.getName() + "-view: " + viewName;
    }

}
