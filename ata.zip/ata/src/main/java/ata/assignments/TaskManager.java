package ata.assignments;

import java.util.Collection;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;

import ata.graphs.TasksGraphAndSlots;
import ata.task.jobs.Job;
import ata.task.tasks.Task;

/**
 * stores tasks.
 *
 */
public interface TaskManager {

    /**
     * initialize all (clear existing, create graph from scratch)
     * 
     * @param tasks
     */
    public void initAll(Multimap<Job, Task> tasks);

    /**
     * put a task
     * 
     * @param job
     * @param task
     * @return
     */
    public void put(Task task);

    /**
     * put a collection of tasks
     * 
     * @param task
     */
    public void putAll(Collection<Task> tasks);

    /**
     * remove a task
     * 
     * @param task
     * @return
     */
    public void remove(Task task);

    /**
     * remove the tasks in the given collection
     * 
     * @param tasks
     */
    public void removeAll(Collection<Task> tasks);

    /**
     * 
     * @return the tasks as an immutable SetMultimap (no duplicate values).
     */
    public ImmutableMultimap<Job, Task> getImmutableTasks();

    /**
     * 
     * @return the task graph and slots
     */
    public TasksGraphAndSlots getTasksGraphAndSlots();

    /**
     * nb of jobs
     * 
     * @return
     */
    public int nbJobs();

    /**
     * nb of tasks
     * 
     * @return
     */
    public int nbTasks();

    /**
     * nb of tasks in graph
     * 
     * @return
     */
    public int nbTasksInGraph();

}
