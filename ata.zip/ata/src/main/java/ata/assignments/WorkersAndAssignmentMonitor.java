package ata.assignments;

import java.util.Map;
import java.util.Set;

import com.google.common.collect.Multimap;

import ata.worker.Worker;

/**
 * stores the completed assignments and the unknown workers
 *
 */
public interface WorkersAndAssignmentMonitor {

    /**
     * binds the specified {@link AssignmentService} to this monitor.
     * 
     * @param assignmentService
     */
    public void setAssignmentService(AssignmentService assignmentService);

    /**
     * put a token for a given worker
     * 
     * @param worker
     * @param token
     * @return
     */
    public AssignerToken putToken(Worker worker, AssignerToken token);

    /**
     * get all the tokens
     * 
     * @return
     */
    public Map<Worker, AssignerToken> getTokens();

    /**
     * adds an unknown worker (not seen before). This SHOULD notify that a new
     * iteration is required.
     * 
     * @param worker
     * @return
     */
    public boolean addUnknownWorker(Worker worker);

    /**
     * get unknown workers
     * 
     * @return
     */
    public Set<Worker> getAndRemoveUnknownWorkers(boolean remove);

    /**
     * returns the minimum number of tasks completed for a given worker before
     * she can be reassigned tasks
     * 
     * @return
     */
    public int getMinNbCompletedAssignmentsForIteration();

    /**
     * returns the assignments that are eligible for next iteration and remove
     * them from the current buffer (optionally).
     * 
     * @param remove
     *            if {@code true}, will remove the assignments from the current
     *            buffer
     * @return eligible assignments
     */
    public Multimap<Worker, Assignment> getEligiblePlannedAssignmentsRemovedCompleted(
            boolean remove);

    /**
     * add an assignment which IS completed. This MAY notify that a new
     * iteration is required.
     * 
     * @param assignment
     * @return
     * 
     * @throws IllegalArgumentException
     *             if the assignment is NOT completed
     */
    public boolean addCompletedAssignment(Assignment assignment);

    // /**
    // * puts the assignments that are planned by an iteration
    // *
    // * @param assignments
    // * @return
    // * @throws IllegalArgumentException
    // * if one assignment is completed
    // */
    // public boolean putPlannedAssignments(
    // Multimap<Worker, Assignment> assignments);

    /**
     * 1-put new assignments in the planned assignments 2-remove the previous
     * ones for the same workers 3-collect the difference and put it in the
     * assignments to reinclude
     * 
     * @param niouAssignments
     *            the new assignments
     * @param the
     *            previously completed assignments
     * @return the nb of tasks that were not completed and added in buffer
     * @throws IllegalArgumentException
     *             if one assignment is completed
     */
    public int putNiouPlannedAssignmentsRemovePreviousUpdateReincludeBuffer(
            Multimap<Worker, Assignment> previouslyCompletedAssignments,
            Multimap<Worker, Assignment> niouAssignments, int iterationIndex);

    // /**
    // * 1-put new assignments in the planned assignments 2-remove the previous
    // * ones for the same workers 3-return the difference: tasks that were
    // * removed from TaskManager in some previous iteration
    // *
    // * @param niouAssignments
    // * the new assignments
    // * @param the
    // * previously completed assignments
    // * @return the planned assignments, currently used
    // * @throws IllegalArgumentException
    // * if one assignment is completed
    // */
    // public Collection<Task>
    // putNiouPlannedAssignmentsRemovePreviousGetDifferenceWorkerLevel(
    // Map<Integer, Assignment> previouslyCompletedAssignments,
    // Map<Integer, Assignment> niouAssignments, int iterationIndex,
    // Worker worker);

    /**
     * 
     * @return the assignments for a given worker (may be an empty set) or
     *         {@code null} if no assignments exist for this worker (meaning
     *         that we need to wait for the assignment service).
     */
    public Set<Assignment> getPlannedAssignments(Worker worker);

    /**
     * get the latest iteration index for the specified worker.
     * 
     * @param worker
     * @return the latest iteration index. {@code null} if the worker is not
     *         present (she was never assigned tasks)
     */
    public Integer getIterationIndex(Worker worker);

    /**
     * forces a reassignment for the given worker
     * 
     * @param worker
     */
    public void forceReassignment(Worker worker);

    /**
     * returns the assignments that were dropped but whose tasks may be
     * reincluded in the task manager (for the specified workers).
     * 
     * @param workers
     * @param remove
     *            if {@code true} will remove the specified worker
     * @return
     */
    public Multimap<Worker, Assignment> getReincludeBuffer(Set<Worker> workers,
            boolean remove);

    /**
     * returns the TOTAL nb of completed tasks (from the beginning)
     * 
     * @return
     */
    public int getTotalNbCompletedTasks();

    /**
     * returns the set of completed tasks that are in the current buffer for the
     * given worker
     * 
     * @param worker
     *            public int getMinNbCompletedAssignmentsForIteration()
     * @return
     */
    public Set<Assignment> getCompletedAssignments(Worker worker);

    /**
     * clear everything except token for this worker
     * 
     * @param worker
     * @return
     */
    public boolean clearAllAssignments(Worker worker);

}
