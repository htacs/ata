package ata.assignments;

/**
 * commodity class to ease instantiation of all different tools
 *
 */
public class ServicesBuilder {

    public static AssignmentIterationConfiguration newBasicAssignmentIterationConfiguration() {
        return new BasicAssignmentIterationConfiguration();
    }

    public static AssignmentIterationInput newBasicAssignmentIterationInput() {
        return new BasicAssignmentIterationInput();
    }

    public static AssignmentPolicy newBasicAssignmentPolicy(
            boolean testPolicy) {
        return new BasicAssignmentPolicy(testPolicy);
    }

    public static TaskManager newSynchronizedTaskManager() {
        return new SynchronizedTaskManager();
    }

    public static WorkersAndAssignmentMonitor newSynchronizedWorkersAndAssignmentMonitor(
            int nbAssignmentsAddedBetweenNotification,
            int minNbCompletedAssignmentsForIteration) {
        return new SynchronizedWorkersAndAssignmentsMonitor(
                nbAssignmentsAddedBetweenNotification,
                minNbCompletedAssignmentsForIteration);
    }

    public static AssignmentService newAssignmentService(
            TaskManager taskManager, WorkersAndAssignmentMonitor waMonitor) {
        return BasicAssignmentService.getInstance(taskManager, waMonitor);
    }
}
