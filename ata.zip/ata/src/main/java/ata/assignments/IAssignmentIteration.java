package ata.assignments;

import com.google.common.collect.Multimap;

import ata.worker.Worker;

public interface IAssignmentIteration {

    /**
     * run an assignment iteration. this has to update the input. In particular,
     * this MUST remove assigned tasks from it.
     * 
     * @param input
     * @return
     */
    public Multimap<Worker, Assignment> assign(AssignmentIterationInput input);

}
