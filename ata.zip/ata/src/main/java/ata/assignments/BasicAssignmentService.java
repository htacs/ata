package ata.assignments;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import ata.assigner.AssignerConfiguration;
import ata.assigner.BasicAssignerConfiguration;
import ata.assigner.WorkersAndAssignments;
import ata.simulation.MainAssignmentServicesSimulator;
import ata.worker.Worker;

/**
 * monitors AssignmentManager and assigns tasks when needed.<br/>
 * singleton.<br/>
 *
 */
public class BasicAssignmentService implements AssignmentService {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(BasicAssignmentService.class);

    private final static int TIMEOUT_ASSIGN_SERVICE_DAYS = Integer.MAX_VALUE;

    private final TimeUnit TIMEOUT_ASSIGN_SERVICE_TIMEUNIT = TimeUnit.DAYS;

    /**
     * singleton
     */
    private static BasicAssignmentService instance;

    /**
     * must be the same as the one in the waMonitor
     */
    private final int minNbCompletedAssignmentsForIteration;

    /**
     * queue: elements are produced by the AssignmentManager. They are consumed
     * by this in a separate thread.
     */
    private BlockingQueue<WorkersAndAssignments> assignerQueue;

    /**
     * input: tasks
     */
    private final TaskManager taskManager;

    /**
     * we update it after assignments.
     */
    private WorkersAndAssignmentMonitor waMonitor;

    /**
     * this is the result of the task assignment
     */
    private Future<Integer> nbIterationsFromFuture;

    /**
     * executor service where assignment is executed
     */
    private ExecutorService execService;

    private int iterationIndex;

    private BasicAssignmentService(TaskManager taskManager,
            WorkersAndAssignmentMonitor waMonitor) {
        assignerQueue = new LinkedBlockingQueue<>();
        this.taskManager = taskManager;
        this.waMonitor = waMonitor;
        this.minNbCompletedAssignmentsForIteration = waMonitor
                .getMinNbCompletedAssignmentsForIteration();

        this.iterationIndex = 0;

    }

    /**
     * returns an AssignmentService (singleton)
     * 
     * @return the unique instance of this class
     */
    static BasicAssignmentService getInstance(TaskManager taskManager,
            WorkersAndAssignmentMonitor waMonitor) {
        if (instance == null) {
            instance = new BasicAssignmentService(taskManager, waMonitor);
        }
        return instance;
    }

    @Override
    public Integer getNbIterationFromFuture()
            throws InterruptedException, ExecutionException {
        return nbIterationsFromFuture.get();
    }

    @Override
    public void addToQueue(WorkersAndAssignmentMonitor wam) {
        LOGGER.info(
                "adding worker and assignments monitor to assignment service queue");
        // get assignments and REMOVE them from buffer
        Multimap<Worker, Assignment> eligibleAssignments = wam
                .getEligiblePlannedAssignmentsRemovedCompleted(true);

        Set<Worker> unknownWorkers = wam.getAndRemoveUnknownWorkers(true);
        Map<Worker, AssignerToken> tokens = wam.getTokens();
        WorkersAndAssignments wa = new WorkersAndAssignments(unknownWorkers,
                eligibleAssignments, tokens);
        LOGGER.info(
                "reassignment: {} known workers, {} assignments and {} unknown workers",
                eligibleAssignments.keySet().size(), eligibleAssignments.size(),
                unknownWorkers.size());
        // put in queue
        assignerQueue.add(wa);
    }

    /**
     * starts the service (start consuming the queue)
     * 
     * @Override
     */
    public void start() {
        runService();
    }

    /**
     * stop assigning tasks
     * 
     * @Override
     */
    public void stop() {
        LOGGER.warn("attempting to stop assignment service...");
        nbIterationsFromFuture.cancel(true);
        execService.shutdownNow();
        try {
            execService.awaitTermination(TIMEOUT_ASSIGN_SERVICE_DAYS,
                    TIMEOUT_ASSIGN_SERVICE_TIMEUNIT);
        } catch (InterruptedException e) {
            LOGGER.warn("error when stopping assignment service");
        }
        LOGGER.warn("assignment service stopped");
    }

    /**
     * run the assignment
     */
    private void runService() {
        this.execService = Executors.newSingleThreadExecutor();
        this.nbIterationsFromFuture = execService.submit(getAssignerCallable());
        execService.shutdown();
    }

    /**
     * returns a callable that consumes the queue.
     */
    private Callable<Integer> getAssignerCallable() {
        final AssignerConfiguration assignerConf = new BasicAssignerConfiguration(
                true);
        final AssignmentPolicy assignPolicy = new BasicAssignmentPolicy(true);
        final AssignmentIterationConfiguration assignerIterConf = new BasicAssignmentIterationConfiguration();
        assignerIterConf.setAssignerConfiguration(assignerConf);
        assignerIterConf.setAssignmentPolicy(assignPolicy);

        return new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                // // TODO: remove try/catch (only for debug)
                // try {
                while (!Thread.currentThread().isInterrupted()) {
                    // take() : BLOCKING method: we may be waiting here
                    WorkersAndAssignments wa = assignerQueue.take();
                    Multimap<Worker, Assignment> previousAssignments = wa
                            .getPlannedAssignments();
                    Set<Worker> unknownWorkers = wa.getUnknownWorkers();
                    int nbTasksRequired = assignerConf.getMaxNbTasksPerWorker()
                            * (previousAssignments.keySet().size()
                                    + unknownWorkers.size());
                    /*
                     * although the task manager's methods are synchronized, we
                     * prevent any modification of it during the iteration.
                     */
                    synchronized (taskManager) {
                        LOGGER.info(
                                "----------------------------------------------------------------------------------------------");
                        LOGGER.info("iteration:\t " + iterationIndex);
                        LOGGER.info("jobs in input:\t{}", taskManager.nbJobs());
                        LOGGER.info("tasks in input:\t{}",
                                taskManager.nbTasks());
                        LOGGER.info("task in graph:\t{}",
                                taskManager.nbTasksInGraph());
                        LOGGER.info("known workers:\t{}",
                                previousAssignments.keySet().size());
                        LOGGER.info("unknown workers:\t{}",
                                unknownWorkers.size());
                        LOGGER.info("tasks required:\t{}", nbTasksRequired);
                        if (LOGGER.isDebugEnabled()) {
                            long totalNbCompleted = 0;
                            StringBuilder sb = new StringBuilder("[");
                            for (Worker w : previousAssignments.keySet()) {
                                long completedAssignments = previousAssignments
                                        .get(w).stream()
                                        .filter(a -> a.isCompleted()).count();
                                totalNbCompleted += completedAssignments;
                                sb.append("(w" + w.getId() + ":"
                                        + completedAssignments + "/"
                                        + previousAssignments.get(w).size()
                                        + "),");
                            }
                            sb.append("]");
                            LOGGER.debug(
                                    "assignments completed/total {}/{} - detail: {}",
                                    totalNbCompleted,
                                    previousAssignments.size(), sb);
                        }
                        LOGGER.info("---");

                        Multimap<Worker, Assignment> assignments = null;

                        if (nbTasksRequired <= taskManager.nbTasks()) {
                            // enough tasks to launch assignment

                            Thread.sleep(
                                    MainAssignmentServicesSimulator.WAIT_TIME_IN_ASSIGNMENT_FORCED_MS);

                            IAssignmentIteration currentIteration = new BasicAssignmentIteration(
                                    minNbCompletedAssignmentsForIteration,
                                    assignerIterConf, iterationIndex);

                            // System.out.println(
                            // "tasks that were completed before");
                            // for (Assignment a :
                            // previousAssignments.values())
                            // {
                            // System.out.println(a.getTask().getId());
                            // }

                            // build input
                            AssignmentIterationInput input = new BasicAssignmentIterationInput();
                            input.setPlannedEligibleAssignments(
                                    previousAssignments);
                            input.setTokens(wa.getTokens());
                            input.setUnknownWorkers(unknownWorkers);
                            input.setTaskManager(taskManager);

                            // assign
                            assignments = currentIteration.assign(input);

                        } else {
                            LOGGER.warn(
                                    "not enough tasks for workers, skipped reassignment");
                            // we put all workers with null values
                            assignments = MultimapBuilder.hashKeys()
                                    .hashSetValues().build();
                            for (Worker w : previousAssignments.keySet()) {
                                assignments.put(w, null);
                            }
                            for (Worker w : unknownWorkers) {
                                assignments.put(w, null);
                            }
                        }
                        /*
                         * update monitor and get remaining tasks these tasks
                         * were not completed and since their assignment a new
                         * iteration happened
                         */
                        int nbActuallyReincluded = 0;
                        int inBuffer = 0;
                        int nbPutIntReincludeBuffer = 0;

                        /*
                         * although the worker and assignment monitor's methods
                         * are synchronized, we prevent any modification of it
                         * during the iteration. This is not the longest phase
                         * so it's OK to block the monitor during that time.
                         */
                        synchronized (waMonitor) {

                            /*
                             * get the tasks that need to be re-included because
                             * they were dropped in a previous iteration
                             */
                            Multimap<Worker, Assignment> remainingAssignmentsFromPreviousIteration = waMonitor
                                    .getReincludeBuffer(assignments.keySet(),
                                            true);
                            inBuffer = remainingAssignmentsFromPreviousIteration
                                    .size();

                            // this will refill the remainingAssignments
                            nbPutIntReincludeBuffer = waMonitor
                                    .putNiouPlannedAssignmentsRemovePreviousUpdateReincludeBuffer(
                                            previousAssignments, assignments,
                                            iterationIndex);

                            /*
                             * now we can update the task manager only with
                             * tasks that were not completed. We need to handle
                             * the case were a task is completed while an
                             * assignment iteration occurs. In this case the
                             * concerned task belongs to the
                             * remainingAssignmentsFromPreviousIteration but is
                             * also in the set of completed tasks. We just need
                             * to avoid it in the loop below.
                             */
                            // System.out.println(
                            // "tasks that are actually
                            // reincorporated");
                            for (Assignment a : remainingAssignmentsFromPreviousIteration
                                    .values()) {
                                if (!previousAssignments.containsValue(a)) {
                                    taskManager.put(a.getTask());
                                    nbActuallyReincluded++;
                                    // System.out.println(a.getTask().getId());
                                }
                            }

                            // remainingTasks =
                            // waMonitor.putNiouPlannedAssignmentsRemovePreviousGetDifference(
                            // previousAssignments,
                            // assignments, iterationIndex);
                        }

                        LOGGER.info("---");
                        LOGGER.info("finished iteration:\t " + iterationIndex);
                        LOGGER.info("known workers:\t{}",
                                previousAssignments.keySet().size());
                        LOGGER.info("unknown workers:\t{}",
                                unknownWorkers.size());
                        LOGGER.info("jobs in input:\t{}", taskManager.nbJobs());
                        LOGGER.info("tasks in input:\t{}",
                                taskManager.nbTasks());
                        LOGGER.info("task in graph:\t{}",
                                taskManager.nbTasksInGraph());
                        LOGGER.info(
                                "tasks in the reinclude buffer from iteration {}\t: {}",
                                iterationIndex - 2, inBuffer);
                        LOGGER.info("tasks actually reincluded:\t{}",
                                nbActuallyReincluded);
                        LOGGER.info("tasks put in the reinclude buffer:\t{}",
                                nbPutIntReincludeBuffer);
                        LOGGER.info("tasks assigned:\t{}", assignments.size());
                        LOGGER.info(
                                "----------------------------------------------------------------------------------------------");

                        iterationIndex++;

                    }
                }
                // } catch (Exception e) {
                // LOGGER.error("exception during assignment", e);
                // }
                return iterationIndex;

            }
        };
    }

}
