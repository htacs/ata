package ata.assignments.comparator;

import java.util.Comparator;

import ata.assignments.Assignment;

/**
 * compares two assignment based on job id</br>
 *
 */
public class AssignmentJobIdComparator implements Comparator<Assignment> {

	private static AssignmentJobIdComparator instance = null;

	private AssignmentJobIdComparator() {

	}

	public static AssignmentJobIdComparator getInstance() {
		if (instance == null) {
			instance = new AssignmentJobIdComparator();
		}
		return instance;
	}

	@Override
	public int compare(Assignment o1, Assignment o2) {
		int res=0;
		res=Integer.compare(o1.getTask().getJob().getId(), o2.getTask().getJob().getId());		
		if (res == 0) {
			res = Integer.compare(o1.getTask().getId(), o2.getTask().getId());
		}
		return res;
	}

}
