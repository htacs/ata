package ata.assignments.comparator;

import java.util.Comparator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.assignments.Assignment;

/**
 * compares two assignment based on the date of completion</br>
 * (most recent first)</br>
 * there must be a date of answer!
 *
 */
public class AssignmentCompletionDateComparator implements Comparator<Assignment> {

	private static AssignmentCompletionDateComparator instance = null;

	private final static Logger LOGGER = LoggerFactory.getLogger(AssignmentCompletionDateComparator.class);

	private AssignmentCompletionDateComparator() {

	}

	public static AssignmentCompletionDateComparator getInstance() {
		if (instance == null) {
			instance = new AssignmentCompletionDateComparator();
		}
		return instance;
	}

	/**
	 * compare date if, then id
	 */
	@Override
	public int compare(Assignment o1, Assignment o2) {
		// if both have answers
		if (o1.getTaskAnswer() == null || o2.getTaskAnswer() == null) {
			LOGGER.error("trying to compare assigments with no task answer");
			return 0;
		}
		if (o1.equals(o2)) {
			return 0;
		}

		int res = o1.getTaskAnswer().getCompletionDate().compareTo(o2.getTaskAnswer().getCompletionDate());
		if (res == 0) {
			// safe since immutable (thread safe) id
			return Integer.compare(o1.getId(), o2.getId());
		}
		return res;

	}

}
