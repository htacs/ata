package ata.assignments;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.SetMultimap;

import ata.assigner.Assigner;
import ata.assigner.AssignerConfiguration;
import ata.assigner.AssignerFactory;
import ata.worker.Worker;

/**
 * basic assignment policy that just uses the tokens specified (except for
 * unknown workers: random)
 */
public class BasicAssignmentPolicy extends AbstractAssignmentPolicy {

    private final static AssignmentMethod INIT_METHOD = new AssignmentMethod(
            AssignerFactory.method.RandomMethod, null, null);

    BasicAssignmentPolicy(boolean testPolicy) {
        super(testPolicy);
    }

    @Override
    public SetMultimap<Assigner, Worker> getAssignmentPolicy(
            Set<Worker> unknownWorkers,
            Multimap<Worker, Assignment> previousAssignments,
            Map<Worker, AssignerToken> tokens,
            AssignerConfiguration assignerConf) {
        SetMultimap<Assigner, Worker> out = MultimapBuilder.hashKeys()
                .hashSetValues().build();

        // first we build all assigners: there must be only a single instance of
        // each assigner
        Map<AssignmentMethod, Assigner> assigners = buildAllAssigners(tokens,
                assignerConf);

        // unknown workers: if adaptive method, we need init phase
        for (Worker worker : unknownWorkers) {
            if (!tokens.containsKey(worker)) {
                throw new IllegalArgumentException("worker without token");
            }
            AssignmentMethod currentMethod = tokens.get(worker).getMethod();
            if (currentMethod.areAlphaBetaForced()
                    && assigners.get(currentMethod).isAdaptive()) {
                // use direct method
                out.put(assigners.get(currentMethod), worker);
            } else {
                // use init method
                out.put(assigners.get(INIT_METHOD), worker);
            }
        }

        // known workers
        for (Worker worker : previousAssignments.keySet()) {
            if (!tokens.containsKey(worker)) {
                throw new IllegalArgumentException("worker without token");
            }
            AssignmentMethod currentMethod = tokens.get(worker).getMethod();
            out.put(assigners.get(currentMethod), worker);

        }
        return out;
    }

    /**
     * instantiate all the assigners that are in tokens.values()
     * 
     * @param tokens
     * @param assignerConf
     * @return a map method -> Assigner
     */
    private Map<AssignmentMethod, Assigner> buildAllAssigners(
            Map<Worker, AssignerToken> tokens,
            AssignerConfiguration assignerConf) {
        // collect all possible methods
        Set<AssignmentMethod> allMethods = new HashSet<>();
        for (AssignerToken token : tokens.values()) {
            allMethods.add(token.getMethod());
        }

        // create an assigner for each method
        Map<AssignmentMethod, Assigner> assigners = new HashMap<>();
        for (AssignmentMethod method : allMethods) {
            Assigner current = AssignerFactory.getAssigner(method,
                    assignerConf);
            assigners.put(method, current);
        }

        // add the init one
        assigners.put(INIT_METHOD,
                AssignerFactory.getAssigner(INIT_METHOD, assignerConf));
        return assigners;
    }

}
