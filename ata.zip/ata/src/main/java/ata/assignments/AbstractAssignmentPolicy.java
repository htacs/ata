package ata.assignments;

/**
 * skelelon class
 *
 */
public abstract class AbstractAssignmentPolicy implements AssignmentPolicy {

    final boolean testPolicy;

    AbstractAssignmentPolicy(boolean testPolicy) {
        this.testPolicy = testPolicy;
    }

    @Override
    public boolean isTestPolicy() {
        return testPolicy;
    }

}
