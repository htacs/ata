package ata.assignments;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.SetMultimap;

import ata.assigner.Assigner;
import ata.assigner.AssignerConfiguration;
import ata.assigner.AssignerExtraArgs;
import ata.assigner.IAssignerExtraArgs;
import ata.graphs.TasksGraphAndSlots;
import ata.misc.RandomGeneratorCustom;
import ata.motivation.AlphaBetaComputation;
import ata.task.TasksJobsTools;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/**
 * <ol>
 * <li>computes alpha/beta of each worker</li>
 * <li>computes assignment for each worker</li>
 * <ul>
 * <li>If worker is known:the method passed in constructor (assigmentToken)</li>
 * <li>Else, the method specified by "initMethod"</li>
 * </ul>
 * </ol>
 *
 */
public class BasicAssignmentIteration implements IAssignmentIteration {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(BasicAssignmentIteration.class);

    /**
     * min nb of tasks required to have an iteration
     */
    private final int minNbTasksBeforeIteration;

    /**
     * conf
     */
    private final AssignerConfiguration assignerConf;

    /**
     * assigner -> set of Worker
     */
    private final AssignmentPolicy assignPolicy;

    private final int iterationIndex;

    public BasicAssignmentIteration(int minNbTasksBeforeIteration,
            AssignmentIterationConfiguration assignIterConf,
            int iterationIndex) {
        super();
        LOGGER.info("new assignment iteration");
        this.minNbTasksBeforeIteration = minNbTasksBeforeIteration;
        this.assignPolicy = assignIterConf.getAssignmentPolicy();
        this.assignerConf = assignIterConf.getAssignerConfiguration();
        this.iterationIndex = iterationIndex;
        LOGGER.info("assignment iteration is created");

    }

    @Override
    public Multimap<Worker, Assignment> assign(AssignmentIterationInput input) {
        LOGGER.info("starting assignment iteration");

        // unpack input
        Multimap<Worker, Assignment> eligibleAssignments = input
                .getEligibleAssignments();

        // pre condition: actually a warning suffice
        for (Worker w : eligibleAssignments.keySet()) {

            long nbCompletedAssignments = eligibleAssignments.get(w).stream()
                    .filter(a -> a.isCompleted()).count();
            if (nbCompletedAssignments < minNbTasksBeforeIteration) {
                LOGGER.warn(
                        "worker {} did not completed enough tasks: completed/expected: {}/{}",
                        w.getId(), nbCompletedAssignments,
                        minNbTasksBeforeIteration);
                // throw new IllegalArgumentException(
                // "worker must have completed at least "
                // + minNbTasksBeforeIteration
                // + " tasks before iteration");
            }
        }

        // unpack the rest and prepare assignment
        ImmutableMultimap<Job, Task> immutableJobs = input.getTaskManager()
                .getImmutableTasks();
        Multimap<Job, Task> jobs = TasksJobsTools
                .getMultimapCopy(immutableJobs);
        TasksGraphAndSlots mutableTasksGraphAndSlots = input.getTaskManager()
                .getTasksGraphAndSlots();
        Set<Worker> unknownWorkers = input.getUnknownWorkers();
        Map<Worker, AssignerToken> tokens = input.getTokens();

        IAssignerExtraArgs assignerExtraArgs = new AssignerExtraArgs();
        assignerExtraArgs.setTasksGraphAndSlots(mutableTasksGraphAndSlots);
        assignerExtraArgs.setAssignmentIndex(iterationIndex);

        Multimap<Worker, Assignment> out = MultimapBuilder.hashKeys()
                .hashSetValues().build();

        setAlphasAndBetas(eligibleAssignments);

        // get assigners
        SetMultimap<Assigner, Worker> assigners = assignPolicy
                .getAssignmentPolicy(unknownWorkers, eligibleAssignments,
                        tokens, assignerConf);

        // one round per assigner
        for (Assigner assigner : assigners.keySet()) {
            // we apply the assignment policy
            Set<Worker> workers = assigners.get(assigner);
            LOGGER.info("starting assignment for {} workers",
                    assigners.get(assigner).size());
            

            Multimap<Worker, Assignment> assignments = assignUsingAssigner(
                    assigner, workers, jobs, mutableTasksGraphAndSlots,
                    assignerExtraArgs);

            /*
             * this updates the input (jobs and extra args such as the
             * taskGraphAndSlots
             */
            removeFromTaskManager(assignments, input.getTaskManager());
            removeFromMutableJobs(assignments, jobs);

            int nbRandomAdditionalTasks = assignerConf
                    .getNbRandomAdditionalTasks();
            if (assignerConf.getNbRandomAdditionalTasks() > 0) {
                LOGGER.info("adding {} random assignment for each worker...",
                        nbRandomAdditionalTasks);
                Multimap<Worker, Assignment> randomAdditionalAssignments = addRandomAssignments(
                        workers, nbRandomAdditionalTasks, jobs, iterationIndex);

                assignments.putAll(randomAdditionalAssignments);

                removeFromTaskManager(randomAdditionalAssignments,
                        input.getTaskManager());
                removeFromMutableJobs(randomAdditionalAssignments, jobs);

            }

            out.putAll(assignments);

            // add empty assignments for workers who wouldn't have tasks
            for (Worker worker : workers) {
                if (!out.containsKey(worker)) {
                    out.put(worker, null);
                }
            }
            for (Worker worker : workers) {
                if (!out.containsKey(worker)) {
                    out.put(worker, null);
                }
            }

        }

        LOGGER.info("an assignment iteration has finished");
        LOGGER.info("results:\t {}",
                AssignmentsChecker.getStats(out, immutableJobs, assignerConf));
        return out;

    }

    private Multimap<Worker, Assignment> addRandomAssignments(
            Set<Worker> workers, int nbRandomAssignmentsToAdd,
            Multimap<Job, Task> mutableJobs, int iterationIndex) {
        // initialize all schedules
        Multimap<Worker, Assignment> out = MultimapBuilder.hashKeys()
                .hashSetValues().build();

        List<Task> taskList = new ArrayList<>(mutableJobs.values());

        Random r = RandomGeneratorCustom.getInstance().getRandom();

        for (Worker worker : workers) {
            while (out.get(worker).size() < nbRandomAssignmentsToAdd
                    && taskList.size() > 0) {
                int toPick = r.nextInt(taskList.size());
                Task task = taskList.get(toPick);
                out.put(worker, new Assignment(worker, task, iterationIndex,
                        assignerConf.getDurationValidity()));
                // remove task
                taskList.remove(toPick);
            }
        }
        return out;

    }

    private Multimap<Worker, Assignment> assignUsingAssigner(
            Assigner localAssigner, Set<Worker> workers,
            Multimap<Job, Task> mutableJobs,
            TasksGraphAndSlots mutableTasksGraphAndSlots,
            IAssignerExtraArgs assignerExtraArgs) {
        LOGGER.info("there are {} workers to assign", workers.size());

        LOGGER.info("running assigner {}", localAssigner.getClass().getName());

        Multimap<Worker, Assignment> out = localAssigner.getAssignments(workers,
                mutableJobs, assignerExtraArgs);

        LOGGER.info("assignment returns {} assignments for {} workers",
                out.size(), out.keySet().size());

        return out;
    }

    // /**
    // * the main method to assign tasks
    // *
    // * @param knownWorkersWhoWorked
    // * @param knownWorkersWhoDidNotWorked
    // * @param unknownWorkers
    // * @param completedAssignments
    // * @param immutableJobs
    // * @param mutableTasksGraphAndSlots
    // * mutated during the process!
    // * @return
    // */
    // public Map<Worker, AssignmentCollection> assign(
    // Set<Worker> knownWorkersWhoWorked,
    // Set<Worker> knownWorkersWhoDidNotWorked, Set<Worker> unknownWorkers,
    // Map<Worker, AssignmentCollection> completedAssignments,
    // ImmutableSetMultimap<Job, Task> immutableJobs,
    // TasksGraphAndSlots mutableTasksGraphAndSlots) {
    //
    // LOGGER.info("getting schedules in assignment iteration");
    // SetMultimap<Job, Task> mutableJobs = TasksJobsTools
    // .getMultimapCopy(immutableJobs);
    //
    // // compute alphas for known workers
    // setAlphasAndBetas(completedAssignments);
    //
    // AssignerConfiguration assignerConf = new BasicAssignerConfiguration();
    // assignerConf.setTasksGraphAndSlots(
    // BasicAssignerConfiguration.TASKS_GRAPH_AND_SLOTS,
    // mutableTasksGraphAndSlots);
    //
    // Map<Worker, AssignmentCollection> out = new HashMap<>();
    // if (this.assigner.isAdaptive()) {
    // // merge known workers
    // Set<Worker> knownWorkersToAssign = new HashSet<>();
    // knownWorkersToAssign.addAll(knownWorkersWhoWorked);
    // knownWorkersToAssign.addAll(knownWorkersWhoDidNotWorked);
    // // assign first workers with known alpha
    //
    // // 1--known workers
    // Map<Worker, AssignmentCollection> adaptiveAssignments = new HashMap<>();
    //
    // if (!knownWorkersToAssign.isEmpty()) {
    // LOGGER.info("there are {} KNOWN workers to assign",
    // knownWorkersToAssign.size());
    //
    // // assign first workers with known alpha
    // LOGGER.info("running assigner {}",
    // assigner.getClass().getName());
    // adaptiveAssignments = assigner.getAssignments(
    // knownWorkersToAssign, mutableJobs, assignerConf,
    // iterationIndex);
    // int returnedTasksAssignments = adaptiveAssignments.values()
    // .stream().map(ac -> ac.getAssignments().size())
    // .reduce(Integer::sum).orElse(0);
    // LOGGER.info("assigner returned {} assignments ",
    // returnedTasksAssignments);
    //
    // if (assigner.requireGraph()) {
    // // update
    // updateMutableJobsAndTaskGraph(adaptiveAssignments,
    // mutableJobs, mutableTasksGraphAndSlots);
    // }
    // LOGGER.info("adaptive assignment finished on {} workers",
    // adaptiveAssignments.keySet().size());
    // }
    //
    // // 2--unknown workers
    // Map<Worker, AssignmentCollection> randomAssignments = new HashMap<Worker,
    // AssignmentCollection>();
    // if (mutableJobs.isEmpty()) {
    // LOGGER.warn("no remaining tasks for {} unknown workers",
    // unknownWorkers.size());
    // } else if (!unknownWorkers.isEmpty()) {
    // LOGGER.info("there are {} UNKNOWN workers to assign",
    // unknownWorkers.size());
    //
    // LOGGER.info("running initAssigner {}",
    // initAssigner.getClass().getName());
    //
    // randomAssignments = initAssigner.getAssignments(unknownWorkers,
    // mutableJobs, assignerConf, iterationIndex);
    // int returnedTasksAssignments = randomAssignments.values()
    // .stream().map(ac -> ac.getAssignments().size())
    // .reduce(Integer::sum).get();
    //
    // LOGGER.info("initAssigner returned {} assignments ",
    // returnedTasksAssignments);
    //
    // if (assigner.requireGraph()) {
    // // update
    // updateMutableJobsAndTaskGraph(randomAssignments,
    // mutableJobs, mutableTasksGraphAndSlots);
    // }
    // }
    // LOGGER.info("random assignment finished on {} workers",
    // randomAssignments.keySet().size());
    //
    // out.putAll(adaptiveAssignments);
    // out.putAll(randomAssignments);
    //
    // LOGGER.info("adaptive assignment finished");
    // } else {
    // LOGGER.info("Starting non-adaptive assignment");
    // // ALL workers
    // Set<Worker> allWorkers = new HashSet<>();
    // allWorkers.addAll(knownWorkersWhoDidNotWorked);
    // allWorkers.addAll(knownWorkersWhoWorked);
    // allWorkers.addAll(unknownWorkers);
    //
    // Map<Worker, AssignmentCollection> directAssignments = assigner
    // .getAssignments(allWorkers, mutableJobs, assignerConf,
    // iterationIndex);
    //
    // // update
    // updateMutableJobsAndTaskGraph(directAssignments, mutableJobs,
    // mutableTasksGraphAndSlots);
    //
    // LOGGER.info("non-adaptive assignment finished on {} workers",
    // directAssignments.keySet().size());
    //
    // out.putAll(directAssignments);
    // }
    //
    // LOGGER.info("an assignment iteration has finished");
    // LOGGER.info("results:\t {}", AssignmentsChecker.getStats(out,
    // immutableJobs, maxNbTasksPerWorker, matchingThreshold));
    // return out;
    // }

    /**
     * routine called at each assignment (random, adaptive or direct). This
     * updates the tasks in the task manager and the task graph.
     * 
     * @param tasksAssigned
     * @param mutableJobs
     */
    private void removeFromTaskManager(
            Multimap<Worker, Assignment> assignmentsToRemove,
            TaskManager taskManager) {

        List<Task> tasksAssigned = new ArrayList<>();
        for (Assignment a : assignmentsToRemove.values()) {
            tasksAssigned.add(a.getTask());
        }

        taskManager.removeAll(tasksAssigned);

    }

    /**
     * removes from the mutable jobs the specified assignments/tasks
     * 
     * @param assignmentsToRemove
     * @param mutableJobs
     */
    private void removeFromMutableJobs(
            Multimap<Worker, Assignment> assignmentsToRemove,
            Multimap<Job, Task> mutableJobs) {
        for (Assignment a : assignmentsToRemove.values()) {
            mutableJobs.remove(a.getTask().getJob(), a.getTask());
        }
    }

    /**
     * set the alphas and betas of workers who worked before
     */
    private void setAlphasAndBetas(
            Multimap<Worker, Assignment> previousAssignments) {
        for (Worker worker : previousAssignments.keySet()) {
            worker.setAlpha(AlphaBetaComputation
                    .computeAlpha(previousAssignments.get(worker)));
            worker.setBeta(AlphaBetaComputation
                    .computeBeta(previousAssignments.get(worker)));
        }
    }

}
