package ata.assignments;

import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.Multimap;

import ata.assigner.AssignerConfiguration;
import ata.motivation.CalcMotivation;
import ata.motivation.CalcRelevance;
import ata.motivation.CalcSkillVariety;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/**
 * to print/get stats on assignments
 *
 */
public final class AssignmentsChecker {

    public static String getStats(Multimap<Worker, Assignment> schedules,
            Multimap<Job, Task> immutableJobsInInput,
            AssignerConfiguration assignerConf) {

        StringBuilder sb = new StringBuilder("\n---------\nAll assignments:\n");
        int totalWorkersAvailable = schedules.keySet().size();
        long nbWorkersAssigned = schedules.keySet().stream()
                .filter(w -> schedules.get(w).size() > 0).count();

        int tasksAssigned = schedules.size();
        int tasksSlotsAvailable = schedules.keySet().size()
                * assignerConf.getMaxNbTasksPerWorker();

        int percentWorkers = (int) Math.ceil(
                ((double) nbWorkersAssigned / totalWorkersAvailable) * 100);
        int percentTasks = (int) Math.ceil(
                ((double) tasksAssigned / immutableJobsInInput.size()) * 100);

        sb.append(String.format("workers assigned:\t %d/%d (%d%%)\n",
                nbWorkersAssigned, totalWorkersAvailable, percentWorkers));
        sb.append(String.format("tasks assigned:\t%d/%d (%d%%) (slots: %d)\n",
                tasksAssigned, immutableJobsInInput.size(), percentTasks,
                tasksSlotsAvailable));

        double totalMotivation = CalcMotivation.getInstance()
                .computeMotivation(schedules);
        // the maximum motivation value that we could get (very loose)
        double upperBoundMotivation = CalcMotivation.getInstance()
                .computeMaximumTheoreticalMotivation(
                        assignerConf.getMaxNbTasksPerWorker(),
                        schedules.keySet());

        sb.append(String.format("motiv: %.3f/%.3f \n", totalMotivation,
                upperBoundMotivation));

        double totalVariety = 0;
        for (Worker w : schedules.keySet()) {
            List<Task> tasks = new ArrayList<>();
            for (Assignment a : schedules.get(w)) {
                tasks.add(a.getTask());
            }
            totalVariety += CalcSkillVariety.getInstance()
                    .getSkillVariety(tasks);
        }

        double totalRelevance = 0;
        for (Worker w : schedules.keySet()) {
            List<Task> tasks = new ArrayList<>();
            for (Assignment a : schedules.get(w)) {
                tasks.add(a.getTask());
            }
            totalRelevance += CalcRelevance.getInstance()
                    .computeRelevance(tasks, w);
        }

        sb.append(String.format("variety: %.3f \n", totalVariety));
        sb.append(String.format("relevance: %.3f \n", totalRelevance));

        sb.append("-------------\n");
        return sb.toString();
    }

}
