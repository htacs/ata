package ata.assignments;

import ata.assigner.AssignerConfiguration;

/**
 * simple class that stores parameters
 *
 */
public class BasicAssignmentIterationConfiguration
        implements AssignmentIterationConfiguration {

    private AssignmentPolicy assignmentPolicy;

    private AssignerConfiguration assignerConfiguration;

    BasicAssignmentIterationConfiguration() {
    }

    @Override
    public void setAssignmentPolicy(AssignmentPolicy assignmentPolicy) {
        this.assignmentPolicy = assignmentPolicy;
    }

    @Override
    public void setAssignerConfiguration(
            AssignerConfiguration assignerConfiguration) {
        this.assignerConfiguration = assignerConfiguration;
    }

    @Override
    public AssignmentPolicy getAssignmentPolicy() {
        return assignmentPolicy;
    }

    @Override
    public AssignerConfiguration getAssignerConfiguration() {
        return assignerConfiguration;
    }

}
