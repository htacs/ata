package ata.assignments;

import java.util.Collection;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.Multimaps;

import ata.graphs.TasksGraphAndSlots;
import ata.graphs.TasksGraphAndSlotsEdgesSorted;
import ata.task.jobs.Job;
import ata.task.tasks.Task;

/**
 * manages tasks using a synchronized multimap and the task graph.<br/>
 * Thread-safe but blocking (synchronized).
 *
 */
public final class SynchronizedTaskManager implements TaskManager {

    /**
     * tasks in input for assignment
     */
    private final Multimap<Job, Task> tasks;

    /**
     * same thing, but with a graph
     */
    private final TasksGraphAndSlots tasksGraphAndSlots;

    private final Object LOCK = new Object();

    SynchronizedTaskManager() {
        this.tasks = Multimaps.synchronizedSetMultimap(
                MultimapBuilder.hashKeys().hashSetValues().build());
        this.tasksGraphAndSlots = new TasksGraphAndSlotsEdgesSorted();

    }

    @Override
    public void initAll(Multimap<Job, Task> tasks) {
        synchronized (LOCK) {
            this.tasks.clear();
            this.tasks.putAll(tasks);
            this.tasksGraphAndSlots.clear();
            this.tasksGraphAndSlots.initAll(tasks.values());
        }
    }

    @Override
    public void put(Task task) {
        synchronized (LOCK) {
            tasksGraphAndSlots.add(task);
            tasks.put(task.getJob(), task);
        }
    }

    @Override
    public void remove(Task task) {
        synchronized (LOCK) {
            tasksGraphAndSlots.remove(task);
            tasks.remove(task.getJob(), task);
        }
    }

    @Override
    public void removeAll(Collection<Task> tasks) {
        synchronized (LOCK) {
            for (Task t : tasks) {
                remove(t);
            }
        }
    }

    @Override
    public ImmutableMultimap<Job, Task> getImmutableTasks() {
        synchronized (LOCK) {
            return ImmutableMultimap.copyOf(tasks);
        }
    }

    @Override
    public TasksGraphAndSlots getTasksGraphAndSlots() {
        synchronized (LOCK) {
            return tasksGraphAndSlots;
        }
    }

    @Override
    public int nbJobs() {
        return tasks.keySet().size();
    }

    @Override
    public int nbTasks() {
        return tasks.size();
    }

    @Override
    public int nbTasksInGraph() {
        return tasksGraphAndSlots.nbTasks();
    }

    @Override
    public void putAll(Collection<Task> tasks) {
        synchronized (LOCK) {
            for (Task t : tasks) {
                put(t);
            }
        }
    }

}
