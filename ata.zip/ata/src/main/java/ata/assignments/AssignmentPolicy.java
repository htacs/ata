package ata.assignments;

import java.util.Map;
import java.util.Set;

import com.google.common.collect.Multimap;
import com.google.common.collect.SetMultimap;

import ata.assigner.Assigner;
import ata.assigner.AssignerConfiguration;
import ata.worker.Worker;

public interface AssignmentPolicy {

    /**
     * get an assignment policy
     * 
     * @param unknownWorkers
     * @param previousAssignments
     * @param tokens
     *            must contain all worker in unknownWorkers and
     *            previousAssignments
     * @param assignerConf
     *            is used to instantiate the assigner
     * @return
     */
    public SetMultimap<Assigner, Worker> getAssignmentPolicy(
            Set<Worker> unknownWorkers,
            Multimap<Worker, Assignment> previousAssignments,
            Map<Worker, AssignerToken> tokens,
            AssignerConfiguration assignerConf);

    /**
     * 
     * @return {@code true} if test policy
     */
    public boolean isTestPolicy();

}
