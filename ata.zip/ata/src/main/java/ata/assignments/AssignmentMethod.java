package ata.assignments;

import ata.assigner.AssignerFactory;

/**
 * a triplet (method, forcedAlpha, forcedBeta)
 *
 */
public class AssignmentMethod {

    private final AssignerFactory.method method;

    private Double forcedAlpha;

    private Double forcedBeta;

    public AssignmentMethod(AssignerFactory.method method, Double forcedAlpha,
            Double forcedBeta) {
        super();
        this.method = method;
        this.forcedAlpha = forcedAlpha;
        this.forcedBeta = forcedBeta;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((forcedAlpha == null) ? 0 : forcedAlpha.hashCode());
        result = prime * result
                + ((forcedBeta == null) ? 0 : forcedBeta.hashCode());
        result = prime * result + ((method == null) ? 0 : method.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AssignmentMethod other = (AssignmentMethod) obj;
        if (forcedAlpha == null) {
            if (other.forcedAlpha != null)
                return false;
        } else if (!forcedAlpha.equals(other.forcedAlpha))
            return false;
        if (forcedBeta == null) {
            if (other.forcedBeta != null)
                return false;
        } else if (!forcedBeta.equals(other.forcedBeta))
            return false;
        if (method != other.method)
            return false;
        return true;
    }

    public AssignerFactory.method getMethod() {
        return method;
    }

    public Double getForcedAlpha() {
        return forcedAlpha;
    }

    public Double getForcedBeta() {
        return forcedBeta;
    }

    public boolean areAlphaBetaForced() {
        return forcedAlpha != null && forcedBeta != null;
    }

    /**
     * can be used only once
     * 
     * @param forcedBeta
     */
    public void setForcedBeta(Double forcedBeta) {
        if (this.forcedBeta == null) {
            this.forcedBeta = forcedBeta;
        }
    }

    /**
     * can be used only once
     * 
     * @param forcedAlpha
     */
    public void setForcedAlpha(Double forcedAlpha) {
        if (this.forcedAlpha == null) {
            this.forcedAlpha = forcedAlpha;
        }
    }

}
