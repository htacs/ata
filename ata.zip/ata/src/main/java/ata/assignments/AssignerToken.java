package ata.assignments;

/**
 * information about the assigner.
 * 
 * Immutable except for alpha and beta which can be written only once.
 */
public class AssignerToken {

    /**
     * the token used
     */
    private final String tokenIn;

    private final AssignmentMethod method;

    /**
     * is it for testing? (to ease debugging)
     */
    private final boolean test;

    public AssignerToken(String tokenIn, AssignmentMethod method,
            boolean test) {
        super();
        this.tokenIn = tokenIn;
        this.method = method;
        this.test = test;
    }

    public String getTokenIn() {
        return tokenIn;
    }

    public AssignmentMethod getMethod() {
        return method;
    }

    public boolean isTestToken() {
        return test;
    }

    @Override
    public String toString() {
        return "assig. token: " + tokenIn + ";" + method + ";" + test;
    }

}
