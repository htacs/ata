package ata.assignments;

public class ExpiredAssignmentException extends Exception {

    private static final long serialVersionUID = 1L;

    public ExpiredAssignmentException(String message, Throwable cause) {
        super(message, cause);
    }

    public ExpiredAssignmentException(String message) {
        super(message);
    }

}
