package ata.assignments;

import java.util.concurrent.ExecutionException;

public interface AssignmentService {

    /**
     * starts the service (start consuming the queue)
     */
    public void start();

    /**
     * stop assigning tasks
     */
    public void stop();

    /**
     * add the worker and assignments contents to the queue for assignment
     * 
     * @param wa
     */
    public void addToQueue(WorkersAndAssignmentMonitor wam);

    /**
     * returns the result of the asynchronous computation
     * 
     * @return
     */
    public Integer getNbIterationFromFuture() throws  InterruptedException, ExecutionException ;
}
