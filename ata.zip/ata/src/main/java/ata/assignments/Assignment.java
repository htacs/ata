package ata.assignments;

import java.util.concurrent.atomic.AtomicInteger;

import org.joda.time.DateTime;

import ata.task.tasks.Task;
import ata.task.tasksAnswers.TaskAnswer;
import ata.worker.Worker;

/**
 * assignment worker-task-taskAnswer All fields are immutable or nearly
 * immutable (fields that can be set only once).
 *
 */
public class Assignment {

    /**
     * used only locally
     */
    private static final AtomicInteger idGenerator = new AtomicInteger(0);

    /**
     * worker, immutable except immutable field inside the worker.
     */
    private final Worker worker;
    /**
     * task, immutable.
     */
    private final Task task;

    /**
     * local id, USED for equals/hashcode
     */
    private final int id;

    /**
     * id given by the database. not final but can be set only once.
     */
    private Integer dbId;

    /**
     * the iteration index (first iteration=1)
     */
    private final int iterationIndex;

    /**
     * answer: optional since a worker may not answer
     */
    private TaskAnswer taskAnswer;

    /**
     * creation date. Immutable.
     */
    private final DateTime creationDate;

    /**
     * is this assignment active?. Immutable. Can be set only once.
     */
    private DateTime expirationDate;

    /**
     * the amt assignment
     */
    private AmtAssignment amtAssignment;

    /**
     * we do a DEEP COPY of the worker. no need to do it for the task which is
     * immutable.
     * 
     * @param worker
     * @param task
     * @param iterationIndex
     * @param durationValidity
     */
    public Assignment(Worker worker, Task task, int iterationIndex,
            long durationValidity) {
        this.worker = Worker.of(worker);
        this.task = task;
        creationDate = DateTime.now();
        expirationDate = DateTime.now().plus(durationValidity);
        id = idGenerator.incrementAndGet();
        this.iterationIndex = iterationIndex;
    }

    /**
     * used for copies
     * 
     * @param worker
     * @param task
     * @param iterationIndex
     * @param durationValidity
     */
    private Assignment(Worker worker, Task task, int iterationIndex,
            DateTime creationDate, DateTime expirationDate, int id,
            TaskAnswer taskAnswer, AmtAssignment amtAssignment, int dbId) {
        this.worker = Worker.of(worker);
        this.task = task;
        this.iterationIndex = iterationIndex;
        this.creationDate = creationDate;
        this.expirationDate = expirationDate;
        this.id = id;
        this.taskAnswer = taskAnswer;
        this.amtAssignment = amtAssignment;
        this.dbId = dbId;
    }

    /**
     * An exact deep copy.
     * 
     * @param a
     * @param durationValidity
     */
    private Assignment(Assignment a) {
        this(a.worker, a.task, a.iterationIndex, a.creationDate,
                a.expirationDate, a.id, a.taskAnswer, a.amtAssignment, a.dbId);
    }

    /**
     * An exact deep copy. static version.
     * 
     * @param a
     * @return
     */
    public static Assignment copyOf(Assignment a) {
        return new Assignment(a);
    }

    public Worker getWorker() {
        return worker;
    }

    public Task getTask() {
        return task;
    }

    public TaskAnswer getTaskAnswer() {
        return taskAnswer;
    }

    public Integer getId() {
        return Integer.valueOf(id);
    }

    /**
     * sets dbId using a trusted source of id (the db)
     * 
     * @param dbId
     */
    public void setDbId(Integer dbId) {
        this.dbId = dbId;
    }

    public boolean setTaskAnswer(TaskAnswer taskAnswer) {
        if (this.taskAnswer != null) {
            throw new IllegalStateException("answer already added");
        }
        this.taskAnswer = taskAnswer;
        /*
         * enforce correct assignment.unnecessary : done in taskanswer that
         * cannot exist without an assignment
         */
        // this.taskAnswer.setAssignment(this);

        // // expire the assignment
        // this.expire();

        return true;
    }

    public DateTime getCreationDate() {
        return creationDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        result = prime * result + ((task == null) ? 0 : task.hashCode());
        result = prime * result + ((worker == null) ? 0 : worker.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Assignment other = (Assignment) obj;
        if (id != other.id)
            return false;
        if (task == null) {
            if (other.task != null)
                return false;
        } else if (!task.equals(other.task))
            return false;
        if (worker == null) {
            if (other.worker != null)
                return false;
        } else if (!worker.equals(other.worker))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Assignment [worker=" + worker + ", task=" + task + ", id=" + id
                + ", dbId=" + dbId + ", taskAnswer=" + taskAnswer
                + ", creationDate=" + creationDate + ", expirationDate="
                + expirationDate + ", amtAssignment=" + amtAssignment
                + ", iterationIndex=" + iterationIndex + "]";
    }

    public DateTime getExpirationDate() {
        return expirationDate;
    }

    public boolean isExpired() {
        return expirationDate.compareTo(DateTime.now()) < 0;
    }

    /**
     * close the assignment
     */
    public void expire() throws ExpiredAssignmentException {
        if (this.expirationDate.compareTo(DateTime.now()) < 0) {
            throw new ExpiredAssignmentException("Assignment already expired");
        }
        // now minus 1 millisecond
        this.expirationDate = DateTime.now().minus(1);
    }
    
    public AmtAssignment getAmtAssignment() {
        return amtAssignment;
    }

    public void setAmtAssignment(AmtAssignment amtAssignment) {
        this.amtAssignment = amtAssignment;
    }

    public int getIterationIndex() {
        return iterationIndex;
    }

    public Integer getDbId() {
        if (dbId == null) {
            throw new IllegalStateException(
                    "db id is called but was not set before!");
        }
        return dbId;
    }

    public boolean isCompleted() {
        return taskAnswer != null;
    }

    public int getWebId() {
        return id;
    }

}
