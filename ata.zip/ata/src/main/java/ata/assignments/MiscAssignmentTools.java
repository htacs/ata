package ata.assignments;

import java.util.Collection;

public final class MiscAssignmentTools {

    /**
     * this is an ORDER INDEPENDENT hashcode.
     * 
     * @param assignments
     * @return
     */
    public static long getCollectionsHash(Collection<Assignment> assignments) {
        long hash = 3;
        for (Assignment a : assignments) {
            hash += a.hashCode();
        }
        return hash;
    }

}
