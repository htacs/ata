package ata.assignments;

import ata.assigner.AssignerConfiguration;

/**
 * defines the elements of an iteration configuration
 *
 */
public interface AssignmentIterationConfiguration {

    /**
     * returns the assignment policy
     */
    public AssignmentPolicy getAssignmentPolicy();

    /**
     * set the assignment policy
     * 
     * @param assignmentPolicy
     */
    public void setAssignmentPolicy(AssignmentPolicy assignmentPolicy);

    /**
     * returns the assigner configuration. Used to later to decide the
     * assignment policy when the workers to assign are known.  
     * 
     * @return
     */
    public AssignerConfiguration getAssignerConfiguration();

    /**
     * sets the assigner config
     * @param assignerConfiguration
     */
    public void setAssignerConfiguration(
            AssignerConfiguration assignerConfiguration);

}
