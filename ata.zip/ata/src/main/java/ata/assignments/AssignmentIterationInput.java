package ata.assignments;

import java.util.Map;
import java.util.Set;

import com.google.common.collect.Multimap;

import ata.worker.Worker;

/**
 * defines all the input data for an iteration
 *
 */
public interface AssignmentIterationInput {

    public Set<Worker> getUnknownWorkers();

    /**
     * planned eligible assignments for each worker: each worker must have
     * completed a certain number of assignments
     */
    public Multimap<Worker, Assignment> getEligibleAssignments();

    public TaskManager getTaskManager();

    public Map<Worker, AssignerToken> getTokens();

    public void setUnknownWorkers(Set<Worker> unknownWorkers);

    public void setPlannedEligibleAssignments(
            Multimap<Worker, Assignment> eligibleAssignments);

    public void setTaskManager(TaskManager taskManager);

    public void setTokens(Map<Worker, AssignerToken> tokens);

}
