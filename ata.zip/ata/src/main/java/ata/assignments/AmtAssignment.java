package ata.assignments;

import ata.assigner.AssignerFactory;

/**
 * the amt assignment. Immutable except the token out which can be set only
 * once.
 *
 */
public class AmtAssignment {

    /**
     * the assignment id of amt<br/>
     * it groups several of our assignments
     */
    private final String amtAssignmentId;

    private final String tokenIn;

    private final String workerId;

    private final String hitId;

    private String tokenOut;

    private final AssignerFactory.method method;

    public AmtAssignment(String amtAssignmentId, String tokenIn,
            String workerId, String hitId, AssignerFactory.method method) {
        super();
        this.amtAssignmentId = amtAssignmentId;
        this.tokenIn = tokenIn;
        this.workerId = workerId;
        this.hitId = hitId;
        this.method = method;
    }

    public String getTokenOut() {
        return tokenOut;
    }

    public void setTokenOut(String tokenOut) {
        if (this.tokenOut != null) {
            throw new IllegalStateException("token out already set!");
        }
        this.tokenOut = tokenOut;
    }

    public String getAmtAssignmentId() {
        return amtAssignmentId;
    }

    public String getTokenIn() {
        return tokenIn;
    }

    public String getWorkerId() {
        return workerId;
    }

    public String getHitId() {
        return hitId;
    }

    public AssignerFactory.method getMethod() {
        return method;
    }

    @Override
    public String toString() {
        String tOut = tokenOut == null ? "" : tokenOut;
        return "[id:" + amtAssignmentId + "-w:" + workerId + "-h" + hitId
                + "-tIn:" + tokenIn + "-tOut:" + tOut + "-m:" + method + "]";
    }

    public boolean isSubmitted() {
        return tokenOut != null;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((amtAssignmentId == null) ? 0 : amtAssignmentId.hashCode());
        result = prime * result + ((hitId == null) ? 0 : hitId.hashCode());
        result = prime * result + ((method == null) ? 0 : method.hashCode());
        result = prime * result + ((tokenIn == null) ? 0 : tokenIn.hashCode());
        result = prime * result
                + ((tokenOut == null) ? 0 : tokenOut.hashCode());
        result = prime * result
                + ((workerId == null) ? 0 : workerId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AmtAssignment other = (AmtAssignment) obj;
        if (amtAssignmentId == null) {
            if (other.amtAssignmentId != null)
                return false;
        } else if (!amtAssignmentId.equals(other.amtAssignmentId))
            return false;
        if (hitId == null) {
            if (other.hitId != null)
                return false;
        } else if (!hitId.equals(other.hitId))
            return false;
        if (method != other.method)
            return false;
        if (tokenIn == null) {
            if (other.tokenIn != null)
                return false;
        } else if (!tokenIn.equals(other.tokenIn))
            return false;
        if (tokenOut == null) {
            if (other.tokenOut != null)
                return false;
        } else if (!tokenOut.equals(other.tokenOut))
            return false;
        if (workerId == null) {
            if (other.workerId != null)
                return false;
        } else if (!workerId.equals(other.workerId))
            return false;
        return true;
    }
    
    

}
