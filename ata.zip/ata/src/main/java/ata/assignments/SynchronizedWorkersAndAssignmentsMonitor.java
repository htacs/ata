package ata.assignments;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.Multimaps;
import com.google.common.collect.Sets;

import ata.worker.Worker;

/**
 * a synchronized implementation of the assignment manager. Uses private lock
 * object idiom.
 *
 */
public final class SynchronizedWorkersAndAssignmentsMonitor
        implements WorkersAndAssignmentMonitor {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(SynchronizedWorkersAndAssignmentsMonitor.class);

    /**
     * worker -> token
     */
    private final Map<Worker, AssignerToken> tokens;

    /**
     * unknown workers (first time they arrive)
     */
    private final Set<Worker> unknownWorkers;

    /**
     * COMPLETED assignments, that might be eligible for assignment iteration.
     * They are a subset of the planned assignments, except if an assignment was
     * completed while the reassignment occured.
     */
    private final Multimap<Worker, Assignment> completedAssignments;

    /**
     * all PLANNED assignments.
     */
    private final Multimap<Worker, Assignment> plannedAssignments;

    /**
     * these are the tasks that were not completed and dropped because of a new
     * reassignment. This is a buffer because we will reinclude tasks not
     * completed in iteration i only during iteration i+2 for a given worker.
     */
    private final Multimap<Worker, Assignment> reincludeBuffer;

    /**
     * worker -> iteration index. The index is the last one given by the
     * assignment service in
     * {@link #putNiouPlannedAssignmentsRemovePreviousGetDifference(Multimap, Multimap, int)}
     */
    private final Map<Worker, Integer> iterationIndices;

    /**
     * lock for synchronized blocks
     */
    private final Object LOCK = new Object();

    /**
     * total of all assignments added so far (it deserves to be greater than the
     * number of assignments in buffer)
     */
    private AtomicInteger nbCompletedAssignmentsAdded = new AtomicInteger(0);

    /**
     * how many tasks have to be completed before we run another iteration
     */
    private final int nbAssignmentsAddedBetweenNotification;

    /**
     * how many task a worker should completed so as to be reassigned tasks
     */
    private final int minNbCompletedAssignmentsForIteration;

    /**
     * the assignment service that will be bound to this monitor
     */
    private AssignmentService assignmentService;

    SynchronizedWorkersAndAssignmentsMonitor(
            int nbAssignmentsAddedBetweenNotification,
            int minNbCompletedAssignmentsForIteration) {
        this.nbAssignmentsAddedBetweenNotification = nbAssignmentsAddedBetweenNotification;
        this.minNbCompletedAssignmentsForIteration = minNbCompletedAssignmentsForIteration;
        this.unknownWorkers = Sets.newConcurrentHashSet();
        this.completedAssignments = Multimaps.synchronizedSetMultimap(
                MultimapBuilder.hashKeys().hashSetValues().build());
        this.plannedAssignments = Multimaps.synchronizedSetMultimap(
                MultimapBuilder.hashKeys().hashSetValues().build());
        this.tokens = new ConcurrentHashMap<>();
        this.iterationIndices = new ConcurrentHashMap<>();
        this.reincludeBuffer = Multimaps.synchronizedSetMultimap(
                MultimapBuilder.hashKeys().hashSetValues().build());
    }

    @Override
    public void setAssignmentService(AssignmentService assignmentService) {
        this.assignmentService = assignmentService;
    }

    @Override
    public boolean addUnknownWorker(Worker worker) {
        LOGGER.info("worker {} added as unknown worker", worker.getId());
        synchronized (LOCK) {
            if (!unknownWorkers.add(worker)) {
                return false;
            }

        }
        // must be done outside of synchronized block
        notifyAssignmentService();
        return false;
    }

    @Override
    public Set<Worker> getAndRemoveUnknownWorkers(boolean remove) {
        synchronized (LOCK) {
            // workers are immutable, so we don't need a copy
            Set<Worker> out = ImmutableSet.copyOf(unknownWorkers);
            if (remove) {
                unknownWorkers.clear();
            }
            return out;
        }
    }

    @Override
    public Multimap<Worker, Assignment> getEligiblePlannedAssignmentsRemovedCompleted(
            boolean remove) {
        synchronized (LOCK) {
            Multimap<Worker, Assignment> out = MultimapBuilder.hashKeys()
                    .hashSetValues().build();
            Set<Worker> hasToBeRemoved = new HashSet<>();
            for (Worker w : completedAssignments.keySet()) {
                if (completedAssignments.get(w)
                        .size() >= minNbCompletedAssignmentsForIteration) {
                    /*
                     * we need a deep copy of assignments, because they can be
                     * completed while we perform reassignment
                     */
                    for (Assignment a : plannedAssignments.get(w)) {
                        out.put(a.getWorker(), Assignment.copyOf(a));
                    }
                    /*
                     * there may remain assignments in completed assignments
                     * that are not planned in the current iteration (they
                     * belong to the previous iteration)
                     */
                    for (Assignment a : completedAssignments.get(w)) {
                        if (!plannedAssignments.get(w).contains(a)) {
                            out.put(a.getWorker(), Assignment.copyOf(a));
                        }
                    }

                    // out.putAll(w, plannedAssignments.get(w));
                    // out.putAll(w, completedAssignments.get(w));
                    if (remove) {
                        hasToBeRemoved.add(w);
                    }
                }
            }
            // we do the remove loop outside to avoid concurrent modification
            for (Worker w : hasToBeRemoved) {
                completedAssignments.removeAll(w);
            }
            return out;
        }

    }

    @Override
    public boolean addCompletedAssignment(Assignment assignment) {
        if (!assignment.isCompleted()) {
            throw new IllegalArgumentException(
                    "assignment should be completed");
        }
        boolean hasToBeNotified = false;
        synchronized (LOCK) {
            if (completedAssignments.put(assignment.getWorker(), assignment)) {
                if (LOGGER.isTraceEnabled()) {
                    LOGGER.trace("worker {} added a completed assignment",
                            assignment.getWorker().getId());
                    StringBuilder sb = new StringBuilder("[");
                    for (Assignment a : completedAssignments
                            .get(assignment.getWorker())) {
                        sb.append(a.getTask().getId() + ",");
                    }
                    sb.append("](" + completedAssignments
                            .get(assignment.getWorker()).size() + ")");
                    LOGGER.trace("completed assignments of worker {}:{}",
                            assignment.getWorker().getId(), sb);
                }
                LOGGER.trace("total nb completed tasks : {}",
                        completedAssignments.size());

                int currentNbCompletedAssignmentsAdded = nbCompletedAssignmentsAdded
                        .incrementAndGet();
                hasToBeNotified = isNotifyRequired(
                        currentNbCompletedAssignmentsAdded);
            } else {
                // this may not be a problem but it is not really expected
                LOGGER.warn("couldn't insert assignment in monitor");
                return false;
            }
        }
        // this must be done OUTSIDE of a synchronized block
        if (hasToBeNotified) {
            notifyAssignmentService();
        }
        return true;
    }

    /**
     * 
     * @param currentNbCompletedAssignmentsAdded
     *            number of assignments added so far
     * @return {@code true} if notification is required
     */
    private boolean isNotifyRequired(int currentNbCompletedAssignmentsAdded) {
        // note: called from a synchronized block in method
        // addCompletedAssignments
        // we try to break as early as possible
        if (currentNbCompletedAssignmentsAdded < minNbCompletedAssignmentsForIteration) {
            return false;
        }
        if (currentNbCompletedAssignmentsAdded == 0) {
            return false;
        }
        // we must be at some multiple of nbAssignmentAddedBetweenNotification
        if (currentNbCompletedAssignmentsAdded
                % nbAssignmentsAddedBetweenNotification != 0) {
            return false;
        }
        // and we must have at least one worker who completed enough tasks
        for (Worker worker : completedAssignments.keySet()) {
            if (completedAssignments.get(worker)
                    .size() >= minNbCompletedAssignmentsForIteration) {
                return true;
            }
        }
        return false;
    }

    /**
     * must be done outside a synchronized block
     */
    private void notifyAssignmentService() {
        if (assignmentService == null) {
            throw new IllegalStateException(
                    "assignment service was not set before");
        }
        this.assignmentService.addToQueue(this);
    }

    @Override
    public int putNiouPlannedAssignmentsRemovePreviousUpdateReincludeBuffer(
            Multimap<Worker, Assignment> previouslyCompletedAssignments,
            Multimap<Worker, Assignment> niouAssignments, int iterationIndex) {
        // // pre condition
        // for (Assignment a : plannedAssignments.values()) {
        // if (a.isCompleted()) {
        // throw new IllegalArgumentException(
        // "assignment should NOT be completed");
        // }
        // }
        int nbReincluded = 0;
        synchronized (LOCK) {
            // init case
            if (plannedAssignments.isEmpty()) {
                plannedAssignments.putAll(niouAssignments);
                // nothing to put in difference
            } else {
                // we look into previous ones
                for (Worker worker : niouAssignments.keySet()) {
                    if (plannedAssignments.containsKey(worker)) {
                        // this worker has new assignments and already had
                        // assignments
                        for (Assignment previous : plannedAssignments
                                .get(worker)) {
                            // NOT completed => it has to be collected
                            if (!previouslyCompletedAssignments.values()
                                    .contains(previous)) {
                                if (!reincludeBuffer.put(worker, previous)) {
                                    throw new IllegalStateException(
                                            "assignment was already reincluded!");
                                }
                                nbReincluded++;
                            }
                        }
                        // now we that we have collected previous ones, we can
                        // remove the old ones and put the new ones
                        plannedAssignments.removeAll(worker);
                        /*
                         * we may have niouAssignments.get(worker) = a
                         * collection with a single null value
                         */
                        plannedAssignments.putAll(worker,
                                niouAssignments.get(worker));

                    } else {
                        plannedAssignments.putAll(worker,
                                niouAssignments.get(worker));
                    }
                }
            }
            // and in all cases
            for (Worker worker : niouAssignments.keySet()) {
                iterationIndices.put(worker, iterationIndex);
            }
        }
        return nbReincluded;
    }

    @Override
    public AssignerToken putToken(Worker worker, AssignerToken token) {
        // does not need to be synchronized with other objects and uses a
        // concurrent map.
        return this.tokens.put(worker, token);
    }

    @Override
    public Map<Worker, AssignerToken> getTokens() {
        // does not need to be synchronized with other objects and uses a
        // concurrent map
        return ImmutableMap.copyOf(tokens);
    }

    @Override
    public Set<Assignment> getPlannedAssignments(Worker worker) {
        synchronized (LOCK) {
            if (!plannedAssignments.containsKey(worker)) {
                return ImmutableSet.of();
            }
            if (plannedAssignments.get(worker).iterator().next() == null) {
                // not enough tasks, we return an empty set.
                return ImmutableSet.of();
            }
            // ok, we have assignments
            return ImmutableSet.copyOf(plannedAssignments.get(worker));

        }
    }

    @Override
    public Integer getIterationIndex(Worker worker) {
        synchronized (LOCK) {
            return iterationIndices.get(worker);// this may be null
        }
    }

    @Override
    public void forceReassignment(Worker worker) {
        // we use the unknown workers set
        addUnknownWorker(worker);
    }

    @Override
    public Multimap<Worker, Assignment> getReincludeBuffer(Set<Worker> workers,
            boolean remove) {
        synchronized (LOCK) {
            Multimap<Worker, Assignment> out = MultimapBuilder.hashKeys()
                    .hashSetValues().build();
            for (Worker worker : workers) {
                if (reincludeBuffer.containsKey(worker)) {
                    out.putAll(worker, reincludeBuffer.get(worker));
                    if (remove) {
                        reincludeBuffer.removeAll(worker);
                    }
                }
            }
            return out;
        }
    }

    @Override
    public int getTotalNbCompletedTasks() {
        return nbCompletedAssignmentsAdded.get();
    }

    @Override
    public Set<Assignment> getCompletedAssignments(Worker worker) {
        synchronized (LOCK) {
            return ImmutableSet.copyOf(completedAssignments.get(worker));
        }
    }

    @Override
    public int getMinNbCompletedAssignmentsForIteration() {
        return minNbCompletedAssignmentsForIteration;
    }

    @Override
    public boolean clearAllAssignments(Worker worker) {
        synchronized (LOCK) {
            boolean found = false;
            found = found || unknownWorkers.remove(worker);
            found = found || completedAssignments.removeAll(worker).size() > 0;
            found = found || plannedAssignments.removeAll(worker).size() > 0;
            found = found || reincludeBuffer.removeAll(worker).size() > 0;
            found = found || iterationIndices.remove(worker) != null;
            return found;
        }
    }

}
