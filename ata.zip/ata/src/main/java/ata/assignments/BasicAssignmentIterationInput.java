package ata.assignments;

import java.util.Map;
import java.util.Set;

import com.google.common.collect.Multimap;

import ata.worker.Worker;

/**
 * simple class that stores parameters
 *
 */
public class BasicAssignmentIterationInput implements AssignmentIterationInput {

    private Set<Worker> unknownWorkers;

    private Multimap<Worker, Assignment> eligibleAssignments;

    private TaskManager taskManager;

    private Map<Worker, AssignerToken> tokens;

    BasicAssignmentIterationInput() {

    }

    @Override
    public Set<Worker> getUnknownWorkers() {
        return unknownWorkers;
    }

    @Override
    public Multimap<Worker, Assignment> getEligibleAssignments() {
        return eligibleAssignments;
    }

    @Override
    public Map<Worker, AssignerToken> getTokens() {
        return tokens;
    }

    @Override
    public void setUnknownWorkers(Set<Worker> unknownWorkers) {
        this.unknownWorkers = unknownWorkers;
    }

    @Override
    public void setPlannedEligibleAssignments(
            Multimap<Worker, Assignment> eligibleAssignments) {
        this.eligibleAssignments = eligibleAssignments;
    }

    @Override
    public void setTokens(Map<Worker, AssignerToken> tokens) {
        this.tokens = tokens;
    }

    @Override
    public TaskManager getTaskManager() {
        return taskManager;
    }

    @Override
    public void setTaskManager(TaskManager taskManager) {
        this.taskManager = taskManager;

    }

}
