package ata.assigner;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import ata.task.tasks.Task;
import ata.worker.Worker;
import gnu.trove.list.TIntList;
import gnu.trove.list.array.TIntArrayList;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.TObjectIntMap;

final class MaxQAPPrintTools {
    private final static String PATTERN = "###.##";

    static String customFormat(double value) {
        DecimalFormat myFormatter = new DecimalFormat(PATTERN);
        return myFormatter.format(value);
    }

    /*********************************
     * String output
     */

    static String printResults(int[] permutation, int[][] possibleAssignments) {
        StringBuilder sb = new StringBuilder();
        sb.append("solution apx\n");
        for (int i = 0; i < permutation.length; i++) {
            sb.append("apxPermut[" + i + "]: " + permutation[i] + "\n");
        }

        sb.append("checking constraint C1\n");
        int nbConstraintsBroken = 0;
        for (int i = 0; i < permutation.length; i++) {
            if (possibleAssignments[i][permutation[i]] == 0) {
                sb.append("constraint broken: " + i + " is assigned to "
                        + permutation[i] + "\n");
                nbConstraintsBroken++;
            }
        }
        sb.append("constraints broken: " + nbConstraintsBroken + "/"
                + permutation.length + "\n");
        return sb.toString();

    }

    static String printIndex(TIntObjectMap<? extends Object> index) {
        StringBuilder sb = new StringBuilder();
        for (int i : index.keys()) {
            sb.append(i + ":\t\t" + index.get(i) + "\n");
        }
        return sb.toString();

    }

    /**
     * print square matrix
     * 
     * @param matrix
     */
    static String printDoubleMatrix(double[][] matrix) {

        int size = matrix.length;
        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i < size + 2; i++) {
            sb.append("_______");
        }
        sb.append("\n");
        for (int i = 0; i < size; i++) {
            sb.append("|");
            for (int j = 0; j < size; j++) {
                sb.append(customFormat(matrix[i][j]));
                sb.append("\t");
            }
            sb.append("|\n");
        }
        for (int i = 0; i < size + 2; i++) {
            sb.append("_______");
        }
        return sb.toString();
    }

    /**
     * print square matrix
     * 
     * @param matrix
     */
    static String printIntMatrix(int[][] matrix) {

        int size = matrix.length;
        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i < size + 2; i++) {
            sb.append("_______");
        }
        sb.append("\n");
        for (int i = 0; i < size; i++) {
            sb.append("|");
            for (int j = 0; j < size; j++) {
                sb.append(matrix[i][j]);
                sb.append("\t");
            }
            sb.append("|\n");
        }
        for (int i = 0; i < size + 2; i++) {
            sb.append("_______");
        }
        return sb.toString();
    }

    static String printMatches(Map<String, Worker> workerPool,
            TIntObjectMap<Worker> indexWorkers,
            TObjectIntMap<Worker> reverseIndexWorkers,
            TIntObjectMap<Task> indexTasks,
            TObjectIntMap<Task> reverseIndexTasks,
            Map<Task, List<Worker>> matchingWorkersJobs) {
        StringBuilder sb = new StringBuilder("");
        sb.append("task\t\t");
        for (Worker w : workerPool.values()) {
            sb.append("w_" + reverseIndexWorkers.get(w) + "\t");
        }
        sb.append("\n");
        for (Task t : indexTasks.valueCollection()) {
            sb.append(reverseIndexTasks.get(t) + "\t\t");
            for (Worker w : workerPool.values()) {
                if (matchingWorkersJobs.get(t).contains(w)) {
                    sb.append("yes\t");
                } else {
                    sb.append("no\t");
                }
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /*******************************************
     * LATEX
     */

    static String printIndexLatexWorkers(TIntObjectMap<Worker> index) {
        StringBuilder sb = new StringBuilder();
        sb.append(
                "\\begin{tabular}{|c|c|}\n\\hline\n\\textbf{Worker} & \\textbf{alpha} & \\textbf{keywords} \\\\ \n \\hline\n");
        TIntList keys = new TIntArrayList(index.keySet());
        keys.sort();

        for (int i : keys.toArray()) {
            sb.append("$w_" + i + "$ & $"
                    + (double) Math.round(1000 * index.get(i).getAlpha()) / 1000
                    + "$ & " + index.get(i).getKeywords()
                    + "\\\\ \n \\hline \n");
        }
        sb.append("\\end{tabular}");
        return sb.toString();

    }

    static String printIndexLatexTasks(TIntObjectMap<Task> index) {
        StringBuilder sb = new StringBuilder();
        sb.append(
                "\\begin{tabular}{|c|c|c|c|}\n\\hline\n\\textbf{Task} & \\textbf{keywords} & \\textbf{payment (\\$ cents)} \\\\ \n \\hline\n");
        TIntList keys = new TIntArrayList(index.keySet());
        keys.sort();

        for (int i : keys.toArray()) {
            sb.append("$t_" + i + "$ & " + index.get(i).getJob().getKeywords()
                    + " & $" + index.get(i).getJob().getPayment() + "$"
                    + "\\\\ \n \\hline \n");
        }
        sb.append("\\end{tabular}");
        return sb.toString();

    }

    static String printMatchesLatex(Map<String, Worker> workerPool,
            TIntObjectMap<Worker> indexWorkers,
            TObjectIntMap<Worker> reverseIndexWorkers,
            TIntObjectMap<Task> indexTasks,
            TObjectIntMap<Task> reverseIndexTasks,
            Map<Task, List<Worker>> matchingWorkersJobs) {
        StringBuilder sb = new StringBuilder(
                "\\begin{tabular}{|c|c|c|}\n \\hline \n");
        sb.append("\\textbf{Task} & ");
        for (Worker w : workerPool.values()) {
            sb.append("$w_" + reverseIndexWorkers.get(w) + "$ &");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append("\\\\ \n \\hline \n");

        TIntList keys = new TIntArrayList(indexTasks.keySet());
        keys.sort();

        for (int i : keys.toArray()) {
            sb.append("$t_" + i + "$ & ");
            for (Worker w : workerPool.values()) {
                if (matchingWorkersJobs.get(indexTasks.get(i)).contains(w)) {
                    sb.append("yes & ");
                } else {
                    sb.append("no & ");
                }
            }
            sb.delete(sb.length() - 2, sb.length() - 1);
            sb.append("\\\\ \n \\hline \n");
        }
        sb.append("\n\\end{tabular}");

        return sb.toString();
    }

    static String printDoubleMatrixLatex(double[][] matrix) {

        int size = matrix.length;
        StringBuilder sb = new StringBuilder("$\n\\begin{bmatrix}\n");

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                sb.append(customFormat(matrix[i][j]) + " & ");
            }
            sb.delete(sb.length() - 2, sb.length() - 1);
            sb.append("\\\\ \n");
        }
        sb.append("\\end{bmatrix}\n$");
        return sb.toString();
    }

    static String printNamedArrayLatex(String name, double[] array) {
        StringBuilder sb = new StringBuilder(
                "\\begin{tabular}{|c|c|}\\hline $i$ & $" + name
                        + "(i)$ \\\\ \n \\hline \n");
        for (int i = 0; i < array.length; i++) {
            sb.append("$" + i + "$ & " + customFormat(array[i])
                    + "\\\\ \n \\hline \n");
        }
        sb.append("\\end{tabular}");
        return sb.toString();
    }

    static String printADegreesLatex(double[] degrees) {
        StringBuilder sb = new StringBuilder(
                "\\begin{tabular}{|c|c|}\\hline $i$ & $\\textit{deg}_i^A$ \\\\ \n \\hline \n");
        for (int i = 0; i < degrees.length; i++) {
            sb.append("$" + i + "$ & $" + customFormat(degrees[i])
                    + "$\\\\ \n \\hline \n");
        }
        sb.append("\\end{tabular}");
        return sb.toString();
    }

    static String printResultsLatex(String name, int[] permutation,
            int[][] possibleAssignments, TIntObjectMap<Worker> indexSlotWorker,
            TObjectIntMap<Worker> reverseIndexWorker) {
        // check constraints
        boolean[] constraintsSatisfied = new boolean[permutation.length];
        for (int i = 0; i < permutation.length; i++) {
            if (possibleAssignments[i][permutation[i]] == 1) {
                constraintsSatisfied[i] = true;
            }
        }

        StringBuilder sb = new StringBuilder(
                "\\begin{tabular}{|c|c|c|c|}\n\\hline $i$ & $" + name
                        + "(i)$ & worker & $C_1$ satisfied ? \\\\ \n \\hline\n");
        for (int i = 0; i < permutation.length; i++) {
            boolean workerAssigned = false;
            String worker = "";
            if (indexSlotWorker.containsKey(permutation[i])) {
                int workerId = reverseIndexWorker
                        .get(indexSlotWorker.get(permutation[i]));
                worker = "$w_" + workerId + "$";
                workerAssigned = true;
            }
            sb.append("$" + i + "$ & $" + permutation[i] + "$ & " + worker
                    + " &\\textit{"
                    + (workerAssigned ? constraintsSatisfied[i] : "")
                    + "}\\\\ \n \\hline \n");

        }
        sb.append("\\end{tabular}");
        return sb.toString();

    }

}
