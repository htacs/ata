package ata.assigner;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import ata.assignments.AssignerToken;
import ata.assignments.Assignment;
import ata.assignments.AssignmentMethod;
import ata.simulation.StatsKeys;
import ata.simulation.StatsManager;
import ata.task.TasksJobsTools;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/**
 * skeleton
 */
abstract class AbstractAssigner implements Assigner, AssignerInternals {

    private static Logger LOGGER = LoggerFactory
            .getLogger(AbstractAssigner.class);

    private final static Multimap<Worker, Assignment> EMPTY_ASSIGNMENTS = MultimapBuilder
            .hashKeys().hashSetValues().build();

    /**
     * given at construction time in the
     */
    final AssignerConfiguration assignerConf;

    /**
     * given when assigning
     */
    IAssignerExtraArgs assignerExtraArgs;

    /**
     * computed when assigning
     */
    int actualNbTasksPerWorker;

    /**
     * some info about the method to use
     */
    AssignerToken assignmentToken;

    /**
     * forced alpha. must use the wrapper Double. not null -> will be used
     */
    Double forcedAlpha = null;

    /**
     * forced alpha. must use the wrapper Double. not null -> will be used
     */
    Double forcedBeta = null;

    protected AbstractAssigner(AssignerConfiguration assignerConf, AssignmentMethod method) {
        this.assignerConf = assignerConf;
        this.forcedAlpha=method.getForcedAlpha();
        this.forcedBeta=method.getForcedBeta();
    }

    @Override
    public final Multimap<Worker, Assignment> getAssignments(
            Set<Worker> workers, Multimap<Job, Task> mutableJobs,
            IAssignerExtraArgs assignerArgs) {

        if (workers.isEmpty()) {
            LOGGER.info("no workers, returning empty assignments");
            return EMPTY_ASSIGNMENTS;
        }

        // determine the actual nb of tasks that we are going to assign
        actualNbTasksPerWorker = AssignerFactory.getActualMaxNbTasksPerWorker(
                assignerConf.getMinNbTasksPerWorker(),
                assignerConf.getMaxNbTasksPerWorker(), workers, mutableJobs);
        // Setup
        long start = System.nanoTime();
        setupData(workers, mutableJobs, assignerArgs);
        long setupTime = System.nanoTime() - start;
        Multimap<Job, Task> mutableJobsCOPY = TasksJobsTools
                .getMultimapCopy(mutableJobs);
        StatsManager.getInstance().put(StatsKeys.TIME_Assignment_Setup,
                setupTime);

        // Exec
        long startAlgo = System.nanoTime();
        Multimap<Worker, Assignment> out = getAssignmentsImpl(workers,
                mutableJobsCOPY);
        long assignmentime = System.nanoTime() - startAlgo;

        StatsManager.getInstance().put(StatsKeys.TIME_Assignment_Exec,
                assignmentime);
        return out;
    }
    
    @Override
    public void setupData(Set<Worker> workers, Multimap<Job, Task> mutableJobs,
            IAssignerExtraArgs assignerExtraArgs) {
        this.assignerExtraArgs=assignerExtraArgs;
    }

}
