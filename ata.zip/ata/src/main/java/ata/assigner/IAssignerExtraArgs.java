package ata.assigner;

import ata.graphs.TasksGraphAndSlots;

public interface IAssignerExtraArgs {
    
    TasksGraphAndSlots getTasksGraphAndSlots();

    void setTasksGraphAndSlots(TasksGraphAndSlots tasksGraphAndSlots);
    
    int getAssignmentIndex();
    
    void setAssignmentIndex(int assignmentIndex);
}
