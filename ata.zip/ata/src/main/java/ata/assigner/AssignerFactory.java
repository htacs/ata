package ata.assigner;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Multimap;

import ata.assigner.LSAPAlgorithms.LSAPFactory;
import ata.assignments.AssignmentMethod;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/***
 * this class is in charge of instantiating assignment algorithms
 *
 */
public class AssignerFactory {

	private final static Logger LOGGER = LoggerFactory.getLogger(AssignerFactory.class);

	public enum method {
		MaxSumDivGreedy, MaxQAPArkin, MaxQAPArkinGreedyMatching, RandomMethod,
	};

	private AssignerFactory() {

	}

	/**
	 * builds an assigner using the given token
	 * 
	 * @return
	 */
	public static Assigner getAssigner(AssignmentMethod assignmentMethod, AssignerConfiguration assignerConf) {
		AbstractAssigner assigner = null;
		switch (assignmentMethod.getMethod()) {

		case MaxQAPArkin:
			assigner = new MaxQAPArkinGamma(assignerConf,
					LSAPFactory.getAlgorithm(LSAPFactory.Algorithm.HungarianAlgorithm), assignmentMethod);
			break;
		case MaxQAPArkinGreedyMatching:
			assigner = new MaxQAPArkinGamma(assignerConf,
					LSAPFactory.getAlgorithm(LSAPFactory.Algorithm.GreedyMatching), assignmentMethod);
			break;
		case RandomMethod:
			assigner = new RandomMethod(assignerConf, assignmentMethod);
			break;
		default:
			throw new IllegalStateException("no assigner");
		}

		LOGGER.info("assigner instantiated with params: {}", assignerConf);

		return assigner;
	}

	/**
	 * max(minNbTasksPerWorker, min(maxNbTasksPerWorker, ceil(nb tasks / nb
	 * workers)))
	 */
	public static int getActualMaxNbTasksPerWorker(int minNbTasksPerWorker, int maxNbTasksPerWorker,
			Set<Worker> workers, Multimap<Job, Task> jobs) {
		if (workers.isEmpty()) {
			throw new IllegalArgumentException("no workers!");
		}
		int actualMaxNbTasksPerWorker = jobs.size() / workers.size() + ((jobs.size() % workers.size() == 0) ? 0 : 1);
		actualMaxNbTasksPerWorker = Math.min(maxNbTasksPerWorker, actualMaxNbTasksPerWorker);
		actualMaxNbTasksPerWorker = Math.max(minNbTasksPerWorker, actualMaxNbTasksPerWorker);
		return actualMaxNbTasksPerWorker;
	}

}
