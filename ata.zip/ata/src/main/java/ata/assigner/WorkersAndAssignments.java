package ata.assigner;

import java.util.Map;
import java.util.Set;

import com.google.common.collect.Multimap;

import ata.assignments.AssignerToken;
import ata.assignments.Assignment;
import ata.worker.Worker;

/**
 * used in the queue.
 * producer= AssignmentService using WorkersAndAssignmentMonitor<br/>
 * consumer=AssignmentService (for assignment)
 *
 */
public final class WorkersAndAssignments {

    private final Set<Worker> unknownWorkers;

    private final Multimap<Worker, Assignment> assignments;

    private final Map<Worker, AssignerToken> tokens;

    public WorkersAndAssignments(Set<Worker> unknownWorkers,
            Multimap<Worker, Assignment> assignments,
            Map<Worker, AssignerToken> tokens) {
        super();
        this.unknownWorkers = unknownWorkers;
        this.assignments = assignments;
        this.tokens = tokens;
    }

    public Set<Worker> getUnknownWorkers() {
        return unknownWorkers;
    }

    public Multimap<Worker, Assignment> getPlannedAssignments() {
        return assignments;
    }

    public Map<Worker, AssignerToken> getTokens() {
        return tokens;
    }

}
