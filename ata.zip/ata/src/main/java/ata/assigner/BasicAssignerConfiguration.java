package ata.assigner;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.configuration.Configuration;

import ata.configuration.ConfigurationLoader;

public class BasicAssignerConfiguration implements AssignerConfiguration {

    private final static String MIN_NB_TASKS_PER_WORKER = "minNbTaskPerWorker";

    private final static String MAX_NB_TASKS_PER_WORKER = "maxNbTaskPerWorker";

    private final static String MATCHING_THRESHOLD = "matchingTreshold";

    private final static String FORCED_ALPHA = "forcedAlpha";

    private final static String FORCED_BETA = "forcedBeta";

    private final static String DURATION_VALIDITY = "durationValidity";

    private final static String EPSILON_DOUBLE = "epsilonDouble";

    private final static String NB_RANDOM_ADDITIONAL_TASKS = "nbRandomAdditionalTasks";

    private Map<String, Object> configuration;

    /**
     * 
     * @param loadDefaultConf
     *            if {@code true} loads the default configuration
     */
    public BasicAssignerConfiguration(boolean loadDefaultConf) {
        configuration = new HashMap<>();
        if (loadDefaultConf) {
            Configuration conf = ConfigurationLoader.getConfiguration();
            setDurationValidity(
                    conf.getLong(ConfigurationLoader.KEY_ASSIGNMENT_VALIDITY));
            setMatchingThreshold(
                    conf.getDouble(ConfigurationLoader.KEY_MATCHING_THRESHOLD));
            setMinNbTasksPerWorker(
                    conf.getInt(ConfigurationLoader.KEY_MIN_KEYWORDS_WORKER));
            setMaxNbTasksPerWorker(
                    conf.getInt(ConfigurationLoader.KEY_MAX_NB_TASKS));
            setNbRandomAdditionalTasks(conf.getInt(
                    ConfigurationLoader.KEY_NB_RANDOM_ADDITIONAL_TASKS));

        }
    }

    @Override
    public String toString() {
        return configuration.toString();
    }

    @Override
    public Integer getMinNbTasksPerWorker() {
        return (Integer) configuration.get(MIN_NB_TASKS_PER_WORKER);
    }

    @Override
    public void setMinNbTasksPerWorker(Integer minNbTasksPerWorker) {
        configuration.put(MIN_NB_TASKS_PER_WORKER, minNbTasksPerWorker);
    }

    @Override
    public Integer getMaxNbTasksPerWorker() {
        return (Integer) configuration.get(MAX_NB_TASKS_PER_WORKER);
    }

    @Override
    public void setMaxNbTasksPerWorker(Integer maxNbTasksPerWorker) {
        configuration.put(MAX_NB_TASKS_PER_WORKER, maxNbTasksPerWorker);
    }

    @Override
    public void setMatchingThreshold(Double matchingThreshold) {
        configuration.put(MATCHING_THRESHOLD, matchingThreshold);

    }

    @Override
    public Double getMatchingThreshold() {
        return (Double) configuration.get(MATCHING_THRESHOLD);
    }

    @Override
    public Double getForcedAlpha() {
        return (Double) configuration.get(FORCED_ALPHA);
    }

    @Override
    public void setForcedAlpha(Double forcedAlpha) {
        configuration.put(FORCED_ALPHA, forcedAlpha);
    }

    @Override
    public Double getForcedBeta() {
        return (Double) configuration.get(FORCED_BETA);
    }

    @Override
    public void setForcedBeta(Double forcedBeta) {
        configuration.put(FORCED_ALPHA, forcedBeta);
    }

    @Override
    public Long getDurationValidity() {
        return (Long) configuration.get(DURATION_VALIDITY);
    }

    @Override
    public void setDurationValidity(Long durationValidity) {
        configuration.put(DURATION_VALIDITY, durationValidity);
    }

    @Override
    public Double getEpsilonDouble() {
        return (Double) configuration.get(EPSILON_DOUBLE);
    }

    @Override
    public void setEpsilonDouble(Double epsilonDouble) {
        configuration.put(EPSILON_DOUBLE, epsilonDouble);
    }

    @Override
    public Integer getNbRandomAdditionalTasks() {
        return (Integer) configuration.get(NB_RANDOM_ADDITIONAL_TASKS);
    }

    @Override
    public void setNbRandomAdditionalTasks(Integer nbRandomAdditionalTasks) {
        configuration.put(NB_RANDOM_ADDITIONAL_TASKS, nbRandomAdditionalTasks);

    }

}
