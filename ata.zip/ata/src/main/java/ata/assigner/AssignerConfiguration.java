package ata.assigner;

/**
 * interface for configuration. all returned values are boxed so as to handle
 * missing values that are returned as null;
 *
 */
public interface AssignerConfiguration {

    Integer getMinNbTasksPerWorker();

    void setMinNbTasksPerWorker(Integer minNbTasksPerWorker);

    Integer getMaxNbTasksPerWorker();

    void setMaxNbTasksPerWorker(Integer maxNbTasksPerWorker);

    Integer getNbRandomAdditionalTasks();

    void setNbRandomAdditionalTasks(Integer nbRandomAdditionalTasks);

    Double getMatchingThreshold();

    void setMatchingThreshold(Double matchingThreshold);

    /**
     * 
     * @return {@code null} if unset
     */
    Double getForcedAlpha();

    void setForcedAlpha(Double forcedAlpha);

    /**
     * 
     * @return {@code null} if unset
     */
    Double getForcedBeta();

    void setForcedBeta(Double forcedBeta);

    Long getDurationValidity();

    void setDurationValidity(Long durationValidity);

    Double getEpsilonDouble();

    void setEpsilonDouble(Double epsilonDouble);
}
