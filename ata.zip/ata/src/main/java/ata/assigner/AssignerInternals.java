package ata.assigner;

import java.util.Set;

import com.google.common.collect.Multimap;
import com.google.common.collect.SetMultimap;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/**
 * defines internals method to process assignment.
 */
interface AssignerInternals {

    /**
     * defined in the concrete class
     */
    Multimap<Worker, Assignment> getAssignmentsImpl(Set<Worker> workers,
            Multimap<Job, Task> mutableJobs);

    /**
     * defined in the concrete class, first method called by
     * {@link #getAssignments(Set, SetMultimap, Object...)}
     * 
     */
    void setupData(Set<Worker> workers, Multimap<Job, Task> mutableJobs,
            IAssignerExtraArgs assignerArgs);

}
