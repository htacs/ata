package ata.assigner;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Multimap;

import ata.assigner.LSAPAlgorithms.LSAPAlgorithm;
import ata.assignments.Assignment;
import ata.assignments.AssignmentMethod;
import ata.graphs.TasksGraphAndSlots;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/**
 * the generic version of maxQapArkin, we can plug any lsap algorithm
 *
 */
class MaxQAPArkinGamma extends AbstractAssigner {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(MaxQAPArkinGamma.class);

    private static final boolean ADAPTIVE = true;

    private static final boolean REQUIRE_GRAPH = true;

    /**
     * input
     */
    private MaxQAPInputAdapter inputAdapter;

    /**
     * the lsap algorithm<br/>
     * instances: {@link #GreedyMatching}
     */
    private final LSAPAlgorithm lsapAlgo;

    MaxQAPArkinGamma(AssignerConfiguration assignerConf, LSAPAlgorithm lsapAlgo,
            AssignmentMethod method) {
        super(assignerConf, method);
        LOGGER.info("MaxQAPArkin-Gamma instanciated");
        LOGGER.info("matching algorithm used:\t" + lsapAlgo.getName());
        this.lsapAlgo = lsapAlgo;
    }

    @Override
    public void setupData(Set<Worker> workers, Multimap<Job, Task> mutableJobs,
            IAssignerExtraArgs assignerExtraArgs) {
        super.assignerExtraArgs = assignerExtraArgs;
        TasksGraphAndSlots tasksGraphAndSlots = assignerExtraArgs
                .getTasksGraphAndSlots();
        inputAdapter = new ConcreteMaxQAPInputAdapter(workers,
                tasksGraphAndSlots, actualNbTasksPerWorker, super.forcedAlpha,
                super.forcedBeta);
    }

    @Override
    public Multimap<Worker, Assignment> getAssignmentsImpl(Set<Worker> workers,
            Multimap<Job, Task> mutableJobs) {
        LOGGER.info("MaxQAPArkin-Gamma begins assignation");

        int[] permutation = MaxQAPArkinAlgo.computeMaxQAPArkin(inputAdapter,
                lsapAlgo);

        Multimap<Worker, Assignment> out = inputAdapter.buildAssignments(
                permutation, assignerConf.getMatchingThreshold(),
                assignerConf.getDurationValidity(),
                assignerExtraArgs.getAssignmentIndex());

        LOGGER.info("MaxQAPArkin-Gamma has finished assignation");
        return out;

    }

    @Override
    public boolean isAdaptive() {
        return ADAPTIVE;
    }

    @Override
    public boolean requireGraph() {
        return REQUIRE_GRAPH;
    }

    /**
     * returns the solution value using the maxqap formulation
     */
    public static double getSolutionValueFromMaxQAPFormulation(
            int[] permutation, MaxQAPInputAdapter adapter) {
        int size = adapter.size();
        double quadPart = 0;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                quadPart += adapter.getA(permutation[i], permutation[j])
                        * adapter.getB(i, j);
            }
        }
        double linearPart = 0;
        for (int i = 0; i < size; i++) {
            linearPart += adapter.getC(i, permutation[i]);
        }

        return quadPart + linearPart;

    }
}
