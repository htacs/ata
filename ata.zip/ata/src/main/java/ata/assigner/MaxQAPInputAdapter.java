package ata.assigner;

import com.google.common.collect.Multimap;

import ata.assignments.Assignment;
import ata.graphs.TasksGraphAndSlots;
import ata.worker.Worker;

public interface MaxQAPInputAdapter {

    /**
     * get the graph and slots
     */
    TasksGraphAndSlots getTasksGraphAndSlots();

    /**
     * get A_{ij}
     */
    double getA(int i, int j);

    /**
     * get B_{ij}
     */
    double getB(int i, int j);

    /**
     * get C_{ij}
     */
    double getC(int i, int j);

    /**
     * an upper bound on the values of c
     */
    double getCUpperBound();

    /**
     * size of the problem
     */
    int size();

    int getNbTasksThatCanAssigned();

    /**
     * translates the output of maxqap problem to output for our problem
     */
    Multimap<Worker, Assignment> buildAssignments(int[] permutation,
            double matchingThreshold, long durationValidity,
            int iterationIndex);
    
    Double getForcedAlpha();
    
    Double getForcedBeta();

}
