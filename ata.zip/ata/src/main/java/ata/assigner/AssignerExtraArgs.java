package ata.assigner;

import ata.graphs.TasksGraphAndSlots;

public class AssignerExtraArgs implements IAssignerExtraArgs {

    private TasksGraphAndSlots tasksGraphAndSlots;

    private int assignmentIndex;

    @Override
    public TasksGraphAndSlots getTasksGraphAndSlots() {
        return tasksGraphAndSlots;
    }

    @Override
    public void setTasksGraphAndSlots(TasksGraphAndSlots tasksGraphAndSlots) {
        this.tasksGraphAndSlots = tasksGraphAndSlots;
    }

    @Override
    public int getAssignmentIndex() {
        return assignmentIndex;
    }

    @Override
    public void setAssignmentIndex(int assignmentIndex) {
        this.assignmentIndex = assignmentIndex;
    }

}
