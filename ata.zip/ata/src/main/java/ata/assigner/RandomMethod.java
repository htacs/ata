package ata.assigner;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import ata.assignments.Assignment;
import ata.assignments.AssignmentMethod;
import ata.misc.RandomGeneratorCustom;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

/**
 * picks random tasks for each worker
 *
 */
class RandomMethod extends AbstractAssigner {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(RandomMethod.class);

    private static final boolean ADAPTIVE = false;

    private static final boolean REQUIRE_GRAPH = false;

    RandomMethod(AssignerConfiguration assignerConf, AssignmentMethod method) {
        super(assignerConf, method);
        LOGGER.info("Random instantiated");
    }

    @Override
    public boolean isAdaptive() {
        return ADAPTIVE;
    }

    @Override
    public boolean requireGraph() {
        return REQUIRE_GRAPH;
    }

    /**
     * {@inheritDoc}
     */
    public Multimap<Worker, Assignment> getAssignmentsImpl(Set<Worker> workers,
            Multimap<Job, Task> mutableJobs) {
        LOGGER.info("Random begins assignation");
        // no need to copy "jobs", we are already using a copy

        // initialize all schedules
        Multimap<Worker, Assignment> out = MultimapBuilder.hashKeys()
                .hashSetValues().build();

        List<Task> taskList = new ArrayList<>(mutableJobs.values());

        Random r = RandomGeneratorCustom.getInstance().getRandom();

        for (Worker worker : workers) {
            while (out.get(worker).size() < actualNbTasksPerWorker
                    && taskList.size() > 0) {
                int toPick = r.nextInt(taskList.size());
                Task task = taskList.get(toPick);
                out.put(worker,
                        new Assignment(worker, task,
                                assignerExtraArgs.getAssignmentIndex(),
                                assignerConf.getDurationValidity()));
                // remove task
                taskList.remove(toPick);
            }

        }
        LOGGER.info("Random finished assignation");
        return out;
    }

}