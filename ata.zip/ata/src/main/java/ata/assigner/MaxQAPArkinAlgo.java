package ata.assigner;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.assigner.LSAPAlgorithms.GreedyMatchingTool;
import ata.assigner.LSAPAlgorithms.LSAPAlgorithm;
import ata.assigner.LSAPAlgorithms.LSAPInputAdapter;
import ata.assigner.LSAPAlgorithms.LSAPMappingToCostAdapter;
import ata.graphs.Edge;
import ata.misc.RandomGeneratorCustom;
import ata.simulation.MainSimulator;
import ata.simulation.StatsKeys;
import ata.simulation.StatsManager;
import gnu.trove.map.TDoubleIntMap;
import gnu.trove.map.hash.TDoubleIntHashMap;
import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.TIntHashSet;

/**
 * the algorithm of MaxQAP arkin. We can plug various algorithms for the lsap
 * problem. stateless
 *
 */
final class MaxQAPArkinAlgo {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(MaxQAPArkinAlgo.class);

    private MaxQAPArkinAlgo() {

    }

    /**
     * the algorithm from Arkin et al, with an additional matrix to define
     * possible assignments
     */
    static int[] computeMaxQAPArkin(MaxQAPInputAdapter maxQapInputAdapter,
            LSAPAlgorithm lsapAlgorithm) {

        
        LOGGER.info("starting maxQAPArkin with matrices of size "
                + maxQapInputAdapter.size());
        LOGGER.info("maxQapInputAdapter has forcedAlpha/forcedBeta : {}/{}", maxQapInputAdapter.getForcedAlpha(), maxQapInputAdapter.getForcedBeta());
        // 1-matching
        long startGetEdges = System.nanoTime();
        Edge[] edges = maxQapInputAdapter.getTasksGraphAndSlots()
                .copyToArrayAndSortEdges();
        long timeGetEdges = System.nanoTime() - startGetEdges;

        long startMatching = System.nanoTime();
        List<Edge> matching = GreedyMatchingTool.getGreedyMatching(edges,
                maxQapInputAdapter.size());
        long matchingTime = System.nanoTime() - startMatching;

        // 2-build auxiliary problem (matrices, edges)
        long startLsap = System.nanoTime();

        // compute the b(i)
        double[] bArray = getB(matching, maxQapInputAdapter);
        // compute the degrees
        double[] degrees = getDegrees(maxQapInputAdapter);
        // build the auxiliary problem
        LOGGER.info("computing auxiliary problem");
        long setupTimeLSAPBAndDegrees = System.nanoTime() - startLsap;


        LSAPInputAdapter lsapInputAdapter = new LSAPMappingToCostAdapter(bArray,
                degrees, maxQapInputAdapter);
        lsapAlgorithm.setup(lsapInputAdapter);

        // added for measurements, only used in offline experiments
        if (MainSimulator.MEASURE_NB_ZEROS_IN_LSAP) {
            long startCountValues = System.nanoTime();
            TDoubleIntMap valueCounter = new TDoubleIntHashMap();

            for (int i = 0; i < lsapInputAdapter.size(); i++) {
                for (int j = 0; j < lsapInputAdapter.size(); j++) {
                    valueCounter.adjustOrPutValue(
                            lsapInputAdapter.getProfit(i, j), 1, 1);
                }
            }
            long timeCountValues = System.nanoTime() - startCountValues;

            LOGGER.info("zeros in lsap: {}/{}", valueCounter.get(0.0),
                    lsapInputAdapter.size() * lsapInputAdapter.size());
            LOGGER.info("different values in lsap: {}/{}", valueCounter.size(),
                    lsapInputAdapter.size() * lsapInputAdapter.size());
            LOGGER.info("time count values in lsap: {} ms",
                    (long) (timeCountValues / 1E6));
            StatsManager.getInstance().put(StatsKeys.LSAP_NB_VALUES_AT_ZERO,
                    valueCounter.get(0.0));
            StatsManager.getInstance().put(StatsKeys.LSAP_NB_DIFFERENT_VALUES,
                    valueCounter.size());
            StatsManager.getInstance().put(StatsKeys.TIME_COUNT_VALUES,
                    timeCountValues);
        }

        // 3-solve auxiliary problem
        long startExecute = System.nanoTime();
        int[] auxPermutation = lsapAlgorithm.execute();
        long execTimeLSAP = System.nanoTime() - startExecute;

        /* clear data in lsapAlgorithm to ease gc */
        lsapAlgorithm.clear();

        LOGGER.info("finished auxiliary problem");

        // 4- build the solution
        LOGGER.info("building solution");
        long startSwitch = System.nanoTime();
        int[] apxPermutation = new int[maxQapInputAdapter.size()];
        int vertexA, vertexB;
        TIntSet verticesSeen = new TIntHashSet();

        for (Edge edge : matching) {
            vertexA = maxQapInputAdapter.getTasksGraphAndSlots()
                    .getSlot(edge.getVertexA());
            vertexB = maxQapInputAdapter.getTasksGraphAndSlots()
                    .getSlot(edge.getVertexB());
            verticesSeen.add(vertexA);
            verticesSeen.add(vertexB);
            if (RandomGeneratorCustom.getInstance().getRandom()
                    .nextDouble() >= 0.5) {
                // no permutation
                apxPermutation[vertexA] = auxPermutation[vertexA];
                apxPermutation[vertexB] = auxPermutation[vertexB];
            } else {
                // permutation
                apxPermutation[vertexA] = auxPermutation[vertexB];
                apxPermutation[vertexB] = auxPermutation[vertexA];
            }
        }

        // the vertex that is not in the matching
        for (int i = 0; i < maxQapInputAdapter.size(); i++) {
            if (!verticesSeen.contains(i)) {
                apxPermutation[i] = auxPermutation[i];
            }
        }
        long switchTime = System.nanoTime() - startSwitch;

        StatsManager.getInstance().put(
                StatsKeys.TIME_Assignment_Detail_MaxQAPArkin_Matching_GetAndSortEdges,
                timeGetEdges);
        StatsManager.getInstance().put(
                StatsKeys.TIME_Assignment_Detail_MaxQAPArkin_Matching_GreedyMatching,
                matchingTime);
        StatsManager.getInstance().put(
                StatsKeys.TIME_Assignment_Detail_MaxQAPArkin_LSAP_Setup_BAndDegrees,
                setupTimeLSAPBAndDegrees);
        StatsManager.getInstance().put(
                StatsKeys.TIME_Assignment_Detail_MaxQAPArkin_LSAP_Solve,
                execTimeLSAP);
        StatsManager.getInstance().put(
                StatsKeys.TIME_Assignment_Detail_MaxQAPArkin_Switch,
                switchTime);

        return apxPermutation;
    }

    /**
     * compute the b(i)
     * 
     * @param matching
     * @return
     */
    private static double[] getB(List<Edge> matching,
            MaxQAPInputAdapter adapter) {
        LOGGER.info("computing b(i)");
        double[] out = new double[adapter.size()];
        int slotA;
        int slotB;
        for (Edge e : matching) {
            slotA = adapter.getTasksGraphAndSlots().getSlot(e.getVertexA());
            slotB = adapter.getTasksGraphAndSlots().getSlot(e.getVertexB());
            out[slotA] = e.getWeight();
            out[slotB] = e.getWeight();
        }

        // by default the i that is not in the matching will have b(i)=0, it's
        // ok.

        return out;
    }

    /**
     * compute degrees in A
     * 
     * @param matrixA
     * @return
     */
    private static double[] getDegrees(MaxQAPInputAdapter adapter) {
        LOGGER.info("computing degrees");
        double[] out = new double[adapter.size()];
        for (int i = 0; i < adapter.size(); i++) {
            double degree = 0;
            for (int j = 0; j < adapter.size(); j++) {
                if (i != j) {
                    degree += adapter.getA(i, j);
                }
            }
            out[i] = degree;
        }

        return out;
    }

}
