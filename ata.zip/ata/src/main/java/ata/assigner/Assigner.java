package ata.assigner;

import java.util.Set;

import com.google.common.collect.Multimap;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

public interface Assigner {

    /**
     * the main method to assign
     */
    public Multimap<Worker, Assignment> getAssignments(Set<Worker> workers,
            Multimap<Job, Task> mutableJobs, IAssignerExtraArgs extraArgs);

    /**
     * is it an assigner that require computation of alpha/beta ?
     */
    public boolean isAdaptive();

    /**
     * does this assigner require a graph already built (e.g. to easily compute
     * a greedy matching)
     */
    public boolean requireGraph();

}
