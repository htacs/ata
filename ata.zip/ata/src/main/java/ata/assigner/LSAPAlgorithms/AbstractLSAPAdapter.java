package ata.assigner.LSAPAlgorithms;

abstract class AbstractLSAPAdapter implements LSAPInputAdapter {

    @Override
    public double getMaxProfit() {
        double maxCost = Double.MIN_VALUE;
        for (int i = 0; i < size(); i++) {
            for (int j = 0; j < size(); j++) {
                maxCost = Math.max(maxCost, getProfit(i, j));
            }
        }
        return maxCost;
    }

    @Override
    public double[][] getAsMatrix() {
        double[][] profitMatrix = new double[size()][size()];
        for (int i = 0; i < size(); i++) {
            for (int j = 0; j < size(); j++) {
                profitMatrix[i][j] = getProfit(i, j);
            }
        }
        return profitMatrix;
    }
}
