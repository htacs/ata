package ata.assigner.LSAPAlgorithms;

/**
 * small tool to limit the visibility of lsap classes. entry point for
 * instantiating lsap algorithms.
 *
 */
public final class LSAPFactory {

    public enum Algorithm {
        GreedyMatching, HungarianAlgorithm
    }

    public static LSAPAlgorithm getAlgorithm(LSAPFactory.Algorithm algorithm) {
        switch (algorithm) {
        case GreedyMatching:
            return new GreedyMatching();
        case HungarianAlgorithm:
        default:
        		throw new IllegalStateException("put here your implementation of the hungarian algorithm");
        }
    }

}
