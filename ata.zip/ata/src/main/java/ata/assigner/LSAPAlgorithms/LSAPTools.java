package ata.assigner.LSAPAlgorithms;

class LSAPTools {

    /**
     * returns the solution value given a costMatrix
     */
    static double getSolutionValue(LSAPInputAdapter adapter, int[] res) {
        double out = 0;
        for (int i = 0; i < res.length; i++) {
            out += adapter.getProfit(i, res[i]);
        }
        return out;
    }

}
