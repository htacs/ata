package ata.assigner.LSAPAlgorithms;

public interface LSAPInputAdapter {

    /**
     * get the weight when assigning slot i to slot j
     */
    double getProfit(int i, int j);
    

    double[][] getAsMatrix();

    /**
     * size of the problem (we assume a n*n problem)
     */
    int size();

    /**
     * return max_{i,j} (profit(i,j))
     */
    double getMaxProfit();

    /**
     * return an upper bound on (profit(i,j))
     */
    double getUpperBoundProfit();
    
    /**
     * return an lower bound on (profit(i,j))
     */
    double getLowerBoundProfit();

}
