package ata.assigner.LSAPAlgorithms;

public interface LSAPAlgorithm {
    /**
     * the name of the algorithm
     */
    public abstract String getName();
    
    public void setup(LSAPInputAdapter inputAdapter);

    /**
     * solve the problem
     */
    public abstract int[] execute();
    
    /**
     * set the input to null, so as to release resources
     */
    public void clear();
}
