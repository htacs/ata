package ata.assigner.LSAPAlgorithms;

import java.util.Arrays;
import java.util.List;
import java.util.function.IntConsumer;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.graphs.LightEdge;
import ata.graphs.LightEdgeComparator;
import ata.simulation.StatsKeys;
import ata.simulation.StatsManager;

/**
 * the greedy matching algorithm<br/>
 * runs in O(|E| log |V|) time <br/>
 * 1/2 approximation for maximum weight matching problem<br/>
 * 1/2 approximation for maximum weight perfect matching problem if complete
 * graph with even number of vertices
 *
 */
class GreedyMatching implements LSAPAlgorithm {

	private final static Logger LOGGER = LoggerFactory.getLogger(GreedyMatching.class);

	/**
	 * the number of vertices above which we'll use a parallel version to
	 * instantiate edges
	 */
	public final static int THRESHOLD_PARALLEL_INSTANTIATION = 1000;

	private final static boolean PARALLEL_INSTANTIATION_ENABLED = false;

	/**
	 * edges, sorted by descending order of weight
	 */
	private LightEdge[] sortedEdges;
	/**
	 * N
	 */
	private int size;

	private final String name = "GreedyMatching";

	@SuppressWarnings("unused")
	public void setup(LSAPInputAdapter adapter) {
		this.size = adapter.size();
		LOGGER.info("GreedyMatching is creating edges");

		long startAllocate = System.nanoTime();
		int nbEdges = size * size;
		sortedEdges = new LightEdge[nbEdges];

		long timeAllocate = System.nanoTime() - startAllocate;

		long startInstantiate = System.nanoTime();

		if (size >= THRESHOLD_PARALLEL_INSTANTIATION && PARALLEL_INSTANTIATION_ENABLED) {
			// parallel version
			// get partitions
			int cpus = Runtime.getRuntime().availableProcessors();
			int tasksPerCpu = size / cpus + ((size % cpus == 0) ? 0 : 1);
			int[] min = new int[size];
			int[] max = new int[size];
			for (int i = 0; i < cpus; i++) {
				min[i] = tasksPerCpu * i;
				max[i] = Math.min(size - 1, tasksPerCpu * (i + 1) - 1);
			}

			// parallel version
			IntStream is = IntStream.range(0, cpus).parallel();

			// run everything in parallel
			is.forEach(new IntConsumer() {
				@Override
				public void accept(int core) {
					int startIndex = tasksPerCpu * size * core;
					int nbEdges = computeEdges(startIndex, min[core], max[core], adapter, sortedEdges);
					LOGGER.info(String.format("cpu %d has finished (%,d edges computed)", core, nbEdges));
				}
			});

		} else {
			int index = 0;
			for (int i = 0; i < size; i++) {
				for (int j = 0; j < size; j++) {
					sortedEdges[index] = new LightEdge(i, size + j, adapter.getProfit(i, j));
					index++;
				}
			}
		}
		long timeInstanciate = System.nanoTime() - startInstantiate;
		LOGGER.debug(String.format("allocating edges: %,d ms / instantiating edges: %,d ms",
				(long) (timeAllocate / 1E6), (long) (timeInstanciate / 1E6)));

		long startSort = System.nanoTime();
		// sort them
		Arrays.sort(sortedEdges, LightEdgeComparator.getInstance().reversed());

		long sort = System.nanoTime() - startSort;
		LOGGER.debug(String.format("sorting edges: %,d ms", (long) (sort / 1E6)));

		if (sortedEdges.length != size * size) {
			LOGGER.warn(String.format("%,d  edges created (expected %,d)", sortedEdges.length, size * size));
		}
		LOGGER.info(String.format("GreedyMatching created %,d edges", sortedEdges.length));
		LOGGER.info("GreedyMatching has finished creating edges");

		StatsManager.getInstance().put(StatsKeys.TIME_Assignment_Detail_MaxQAPArkin_LSAP_Setup_Build,
				timeAllocate + timeInstanciate);
		StatsManager.getInstance().put(StatsKeys.TIME_Assignment_Detail_MaxQAPArkin_LSAP_Setup_Sort, sort);
	}

	/**
	 * computes only edges whose vertices are within the given bounds
	 *
	 * @param minIndex
	 * @param maxIndex
	 * @param sortedEdges
	 * @return
	 */
	private int computeEdges(int startIndex, int minIndex, int maxIndex, LSAPInputAdapter adapter, LightEdge[] edges) {
		int out = 0;
		int size = adapter.size();
		int currentIndex = startIndex;
		for (int i = minIndex; i <= maxIndex; i++) {
			for (int j = 0; j < size; j++) {
				sortedEdges[currentIndex] = new LightEdge(i, size + j, adapter.getProfit(i, j));
				currentIndex++;
				out++;
			}
		}
		return out;
	}

	public int[] execute() {
		LOGGER.info(String.format("GreedyMatching computes matching on %,d edges", sortedEdges.length));
		List<LightEdge> matching = GreedyMatchingTool.getGreedyMatching(this.sortedEdges, 2 * size);
		// List<Edge> matching = GreedyMatchingTool
		// .getGreedyMatching(this.sortedEdges);
		LOGGER.info("GreedyMatching builds solution");
		int[] solution = getSolution(matching);
		LOGGER.info("Greedymatching has finished");
		return solution;

	}

	// /**
	// * builds the permutation sigma^chapeau
	// *
	// * @return
	// */
	// private int[] getSolution(List<Edge> bestMatching) {
	// // build the permutation
	// int[] out = new int[size];
	// for (Edge e : bestMatching) {
	// out[e.getVertexA().getId()] = e.getVertexB().getId() - size;
	// // logger.trace("edge " + e + "=> " + String.valueOf(e.getVertexA())
	// // + "-" + String.valueOf(e.getVertexB() - size));
	// }
	// return out;
	// }

	/**
	 * builds the permutation sigma^chapeau
	 *
	 * @return
	 */
	private int[] getSolution(List<LightEdge> matching) {
		int[] out = new int[size];
		for (LightEdge e : matching) {
			out[e.getVertexA()] = e.getVertexB() - size;
		}
		return out;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void clear() {
		Arrays.fill(sortedEdges, null);
	}

}
