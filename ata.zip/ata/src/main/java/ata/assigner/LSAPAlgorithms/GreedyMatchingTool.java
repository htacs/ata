package ata.assigner.LSAPAlgorithms;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.graphs.Edge;
import ata.graphs.LightEdge;
import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.TIntHashSet;

public final class GreedyMatchingTool {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(GreedyMatchingTool.class);

    /**
     * compute a GREEDY matching. This is NOT a MAXIMUM weight matching. See
     * [Arkin01] or [Hassin06].<br/>
     * general purpose method (works for Node/Edge graph) <br/>
     * must be given a set of edges SORTED BY DESCENDING ORDER OF WEIGHT
     *
     * @param sortedEdges
     * @return
     * @throws IllegalArgumentException
     *             if edges are not correctly sorted
     */
    public static List<Edge> getGreedyMatching(Iterable<Edge> sortedEdges,
            int nbVertices) {
        LOGGER.info("begin computing greedy matching using sorted set");
        // // check that ordering is OK
        List<Edge> matching = new ArrayList<>(nbVertices);
        TIntSet verticesMatched = new TIntHashSet(nbVertices);
        for (Edge e : sortedEdges) {
            int vertexA = e.getVertexA().getId();
            int vertexB = e.getVertexB().getId();
            if (verticesMatched.contains(vertexA)) {
                continue;
            }
            if (verticesMatched.contains(vertexB)) {
                continue;
            }
            matching.add(e);
            verticesMatched.add(vertexA);
            verticesMatched.add(vertexB);
            if (verticesMatched.size() == nbVertices) {
                break;
            }
        }

        LOGGER.info("greedy matching finished");
        LOGGER.info("edges in matching " + matching.size());
        return matching;
    }

    /**
     * compute a GREEDY matching. This is NOT a MAXIMUM weight matching. See
     * [Arkin01] or [Hassin06].<br/>
     * general purpose method (works for Node/Edge graph) <br/>
     * must be given a set of edges SORTED BY DESCENDING ORDER OF WEIGHT
     */
    public static List<Edge> getGreedyMatching(Edge[] sortedEdges,
            int nbVertices) {
        LOGGER.info("begin computing greedy matching using array of edges");

        List<Edge> matching = new ArrayList<>(nbVertices);
        TIntSet verticesMatched = new TIntHashSet(nbVertices);

        for (int i = 0; i < sortedEdges.length; i++) {
            int vertexA = sortedEdges[i].getVertexA().getId();
            int vertexB = sortedEdges[i].getVertexB().getId();
            if (verticesMatched.contains(vertexA)) {
                continue;
            }
            if (verticesMatched.contains(vertexB)) {
                continue;
            }
            matching.add(sortedEdges[i]);
            verticesMatched.add(vertexA);
            verticesMatched.add(vertexB);
            if (verticesMatched.size() == nbVertices) {
                break;
            }
        }

        LOGGER.info("greedy matching finished");
        LOGGER.info("edges in matching " + matching.size());
        return matching;
    }

    /**
     * compute a GREEDY matching. This is NOT a MAXIMUM weight matching. See
     * [Arkin01] or [Hassin06].<br/>
     * general purpose method (works for Node/Edge graph) <br/>
     * must be given a set of edges SORTED BY DESCENDING ORDER OF WEIGHT
     */
    public static List<LightEdge> getGreedyMatching(LightEdge[] sortedEdges,
            int nbVertices) {
        LOGGER.info("begin computing greedy matching using array of edges");

        List<LightEdge> matching = new ArrayList<>(nbVertices);
        TIntSet verticesMatched = new TIntHashSet(nbVertices);

        for (int i = 0; i < sortedEdges.length; i++) {
            int vertexA = sortedEdges[i].getVertexA();
            int vertexB = sortedEdges[i].getVertexB();
            if (verticesMatched.contains(vertexA)) {
                continue;
            }
            if (verticesMatched.contains(vertexB)) {
                continue;
            }
            matching.add(sortedEdges[i]);
            verticesMatched.add(vertexA);
            verticesMatched.add(vertexB);
            if (verticesMatched.size() == nbVertices) {
                break;
            }
        }

        LOGGER.info("greedy matching finished");
        LOGGER.info("edges in matching " + matching.size());
        return matching;
    }
}
