package ata.assigner.LSAPAlgorithms;

import ata.assigner.MaxQAPInputAdapter;

public class LSAPMappingToCostAdapter extends AbstractLSAPAdapter
        implements LSAPInputAdapter {
    /* input fields */
    private final double[] bArray;
    private final double[] degrees;
    private final MaxQAPInputAdapter inputAdapter;

    public LSAPMappingToCostAdapter(double[] bArray, double[] degrees,
            MaxQAPInputAdapter mapping) {
        super();
        this.bArray = bArray;
        this.degrees = degrees;
        this.inputAdapter = mapping;
    }

    @Override
    public double getProfit(int i, int j) {
        return bArray[i] * degrees[j] + inputAdapter.getC(i, j);
    }

    @Override
    public int size() {
        return bArray.length;
    }

    @Override
    public double getUpperBoundProfit() {
        /* normally it's at most 1.0 */
        double maxBArray = Double.MIN_VALUE;
        for (int i = 0; i < bArray.length; i++) {
            maxBArray = Math.max(maxBArray, bArray[i]);
        }
        /* an upper bound is size (alpha=1 on all the column) */
        double maxDegrees = Double.MIN_VALUE;
        for (int j = 0; j < degrees.length; j++) {
            maxDegrees = Math.max(maxDegrees, degrees[j]);
        }
        double maxCij = inputAdapter.getCUpperBound();

        return maxBArray * maxDegrees + maxCij;
    }

    @Override
    public double getLowerBoundProfit() {
        return 0.0;
    }
}
