package ata.assigner.LSAPAlgorithms;

import java.util.Arrays;

import ata.misc.CompOps;

class OptimalSolution implements LSAPAlgorithm {

    private final static String NAME = "OptimalSolution for LSAP";

    private double[][] profitMatrix;

    OptimalSolution() {
    }

    @Override
    public void clear() {
        this.profitMatrix = null;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public void setup(LSAPInputAdapter inputAdapter) {
        this.profitMatrix = inputAdapter.getAsMatrix();
    }

    @Override
    public int[] execute() {
        return getOptimalAssignment();
    }

    /**
     * get the optimal assignment by enumerating all possible solutions<br/>
     * could be improved, currently it enumerates all arrangements of size k and
     * is order-sensitive while we don't care about the order ("k among n")
     * @return
     */
    private int[] getOptimalAssignment() {
        int size = profitMatrix.length;
        int[] currentSolution = new int[size];
        boolean[] colsAssigned = new boolean[size];
        int nextRow = 0;
        computeAllSolutionsRecursive(currentSolution, colsAssigned, nextRow,
                size);
        return bestSolution;

    }

    /**
     * 
     * @param currentSolution
     *            map worker slot -> task slot
     * @param tasksAssigned
     *            tasksAssigned[i]=true if task on slot i was already assigned
     * @param nextWorkerSlot
     * @param size
     *            the number of tasks
     * @param slotToWorker
     * @param slotToTask
     */
    private void computeAllSolutionsRecursive(int[] currentSolution,
            boolean[] colsAssigned, int nextRow, int size) {
        if (nextRow == size) {
            evaluateBestSolution(currentSolution);
            return;
        }
        for (int i = 0; i < size; i++) {
            if (!colsAssigned[i]) {
                currentSolution[nextRow] = i;
                colsAssigned[i] = true;
                computeAllSolutionsRecursive(currentSolution, colsAssigned,
                        nextRow + 1, size);
                colsAssigned[i] = false;
            }
        }

    }

    private int[] bestSolution;

    /**
     * builds and evaluate the current solution, update the best solution
     */
    private void evaluateBestSolution(int[] currentSolution) {
        LSAPMatrixToCostAdapter adapter = new LSAPMatrixToCostAdapter(
                profitMatrix);
        if (bestSolution != null) {
            double previousValue = LSAPTools.getSolutionValue(adapter,
                    bestSolution);
            double currentValue = LSAPTools.getSolutionValue(adapter,
                    currentSolution);
            if (CompOps.geq(currentValue, previousValue)) {
                bestSolution = Arrays.copyOf(currentSolution,
                        currentSolution.length);
            }
        } else {
            bestSolution = Arrays.copyOf(currentSolution,
                    currentSolution.length);
        }

    }
}
