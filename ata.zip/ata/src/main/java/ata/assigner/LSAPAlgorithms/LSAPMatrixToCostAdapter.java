package ata.assigner.LSAPAlgorithms;

public class LSAPMatrixToCostAdapter extends AbstractLSAPAdapter
        implements LSAPInputAdapter {

    private final double[][] profitMatrix;

    public LSAPMatrixToCostAdapter(double[][] profitMatrix) {
        super();
        this.profitMatrix = profitMatrix;
    }

    @Override
    public double getProfit(int i, int j) {
        return profitMatrix[i][j];
    }

    @Override
    public int size() {
        return profitMatrix.length;
    }

    @Override
    public double getUpperBoundProfit() {
        double maxProfit = Double.MIN_VALUE;
        for (int i = 0; i < size(); i++) {
            for (int j = 0; j < size(); j++) {
                maxProfit = Math.max(maxProfit, profitMatrix[i][j]);
            }
        }
        return maxProfit;
    }

    @Override
    public double getLowerBoundProfit() {
        double minProfit = Double.MIN_VALUE;
        for (int i = 0; i < size(); i++) {
            for (int j = 0; j < size(); j++) {
                minProfit = Math.max(minProfit, profitMatrix[i][j]);
            }
        }
        return minProfit;
    }

}
