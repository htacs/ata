package ata.assigner;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import ata.assignments.Assignment;
import ata.graphs.TasksGraphAndSlots;
import ata.misc.RandomGeneratorCustom;
import ata.motivation.CalcRelevance;
import ata.motivation.CalcSkillVariety;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

/**
 * see [1] = Arkin, E. M., Hassin, R., & Sviridenko, M. (2001). Approximating
 * the maximum quadratic assignment problem. Information Processing Letters,
 * 77(1), 13-16.</br>
 * prepares matrices A, B, and C. Builds mapping index <-> task and index <->
 * worker</br>
 * needs to be passed to the class that actually computes the assignment
 *
 */
class ConcreteMaxQAPInputAdapter implements MaxQAPInputAdapter {

    private final static Logger LOGGER = LoggerFactory
            .getLogger(ConcreteMaxQAPInputAdapter.class);

    /*
     * INPUT DATA
     */

    private final int actualNbTasksPerWorker;

    // private double matchingThreshold;
    /**
     * workers who need tasks (with known alpha and beta)
     */
    private final Set<Worker> workerPool;

    /**
     * the graph with tasks as vertices (and not slots!)<br/>
     * MUST BE ALREADY SORTED BY DESC. ORDER OF WEIGHT
     */
    private final TasksGraphAndSlots tasksGraphAndSlots;

    /**
     * INTERMEDIATE DATA
     */

    /**
     * int (position in matrix) <-> worker
     */
    private TIntObjectMap<Worker> indexSlotWorker;

    /**
     * the list of workers, used to impose an order
     */
    private ImmutableList<Worker> workersList;

    /*
     * OUTPUT DATA: see Arkin et al.
     */
    private double[][] matrixA;

    private double[][] matrixB;

    private final Double forcedAlpha;

    private final Double forcedBeta;

    ConcreteMaxQAPInputAdapter(Set<Worker> workerPool,
            TasksGraphAndSlots tasksGraphAndSlots, int actualNbTasksPerWorker,
            Double forcedAlpha, Double forcedBeta) {
        this.actualNbTasksPerWorker = actualNbTasksPerWorker;
        this.workerPool = workerPool;
        this.tasksGraphAndSlots = tasksGraphAndSlots;
        this.forcedAlpha=forcedAlpha;
        this.forcedBeta=forcedBeta;
        buildMatricesAndIndices();
    }

    /**
     * to call at the beginning
     */
    private void buildMatricesAndIndices() {
        LOGGER.info("starting to build data for maxQAP");
        LOGGER.info("starting to build indices for maxQAP");
        // resize if there are not enough tasks
        int nbAvailableTasks = tasksGraphAndSlots.nbTasks();

        
        // build list of workers
        RandomGeneratorCustom.getInstance().reseedRandom();
        List<Worker> tempList = new ArrayList<>(workerPool);
        Collections.shuffle(tempList,
                RandomGeneratorCustom.getInstance().getReseededRandom());
        workersList = ImmutableList.copyOf(tempList);

        // build index worker<->slot
        this.indexSlotWorker = getSlotToWorkerMap(workersList,
                actualNbTasksPerWorker, nbAvailableTasks);

        LOGGER.info("finished building indices for maxQAP");
        LOGGER.info("starting to build matrices for maxQAP");
        int maxRow, maxCol;
        // build A
        // it is not strictly necessary to build it and this is not an expensive
        // step. We choose to build it since it makes
        // the code/algo more readable and more similar to the original
        // algorithm (Arkin00).
        LOGGER.info("matrix A...");
        Instant startA = Instant.now();
        this.matrixA = new double[size()][size()];
        int index = 0;
        for (Worker w : workersList) {
            // we stop at most at "size": workers may not receive tasks!
            maxRow = Math.min(size() - 1,
                    (index + 1) * actualNbTasksPerWorker - 1);
            for (int i = index * actualNbTasksPerWorker; i <= maxRow; i++) {
                maxCol = Math.min(size() - 1,
                        (index + 1) * actualNbTasksPerWorker - 1);
                for (int j = index * actualNbTasksPerWorker; j <= maxCol; j++) {
                    double alpha = forcedAlpha == null ? w.getAlpha()
                            : forcedAlpha.doubleValue();
                    matrixA[i][j] = alpha;
                }
            }
            index++;
        }
        long durA = Duration.between(startA, Instant.now()).toMillis();
        LOGGER.info("{} ms", durA);

        // build B
        // building B is costly and not necessary if we have a structure where
        // the edges are stored and sorted.
        if (tasksGraphAndSlots == null) {
            Instant startB = Instant.now();
            // we optimize a bit by using the symmetry property of the distance
            LOGGER.info("matrix B...");
            this.matrixB = new double[size()][size()];
            for (int i = 0; i < size(); i++) {
                for (int j = i; j < size(); j++) {
                    double distance = CalcSkillVariety.getInstance()
                            .getSkillVariety(tasksGraphAndSlots.getTask(i),
                                    tasksGraphAndSlots.getTask(j));
                    matrixB[i][j] = distance;
                    matrixB[j][i] = distance;
                }
            }
            long durB = Duration.between(startB, Instant.now()).toMillis();
            LOGGER.info(String.format("%d ms", durB));
        } else {
            LOGGER.warn("matrix B not built, using the graph");
        }
        // build C
        LOGGER.info("matrix C...");
        Instant startC = Instant.now();
        LOGGER.warn("matrix C not built, using directly computeCij(i,j)");
 
        long durC = Duration.between(startC, Instant.now()).toMillis();
        LOGGER.info(String.format("%d ms", durC));

        LOGGER.info("finished building matrices for maxQAP");
        LOGGER.info("finished building data for maxQAP");

    }

    @Override
    public TasksGraphAndSlots getTasksGraphAndSlots() {
        return tasksGraphAndSlots;
    }

    @Override
    public double getA(int i, int j) {
        return matrixA[i][j];
    }

    @Override
    public double getB(int i, int j) {
        return CalcSkillVariety.getInstance().getSkillVariety(
                tasksGraphAndSlots.getTask(i), tasksGraphAndSlots.getTask(j));
    }

    /**
     * this can be called from outside and avoids building matric C
     * 
     * @return
     */
    @Override
    public double getC(int i, int j) {
        Task currentTask = tasksGraphAndSlots.getTask(i);
        Worker currentWorker = indexSlotWorker.get(j);

        if (currentTask == null) {
            System.out.println();
        }
        if (currentWorker != null) {
            double beta = forcedBeta == null ? currentWorker.getBeta()
                    : forcedBeta.doubleValue();
            return CalcRelevance.getInstance().computeRelevance(currentTask,
                    currentWorker) * (actualNbTasksPerWorker - 1) * (beta);
        }
        return 0;
    }

    @Override
    public double getCUpperBound() {
        return CalcRelevance.getInstance().getMaxPossibleRelevance()
                * (actualNbTasksPerWorker - 1) * 1.0;
    }

    @Override
    public int getNbTasksThatCanAssigned() {
        return Math.min(size(), actualNbTasksPerWorker * workersList.size());
    }

    @Override
    public int size() {
        return tasksGraphAndSlots.nbTasks();
    }

    /**
     * builds assignments tasks<->workers using the permutation from the maxQAP
     * algorithm
     */
    @Override
    public Multimap<Worker, Assignment> buildAssignments(int[] apxPermutation,
            double matchingThreshold, long durationValidity,
            int iterationIndex) {
        Multimap<Worker, Assignment> out = MultimapBuilder.hashKeys()
                .hashSetValues().build();

        for (int i = 0; i < apxPermutation.length; i++) {
            // get task
            Task currentTask = tasksGraphAndSlots.getTask(i);
            // get associated worker
            Worker currentWorker = indexSlotWorker.get(apxPermutation[i]);
            // if this there is an assignment
            if (currentWorker != null) {
                out.put(currentWorker, new Assignment(currentWorker,
                        currentTask, iterationIndex, durationValidity));
            }
        }
        return out;
    }

    /********* other tools ****************/

    static TIntObjectMap<Worker> getSlotToWorkerMap(Collection<Worker> workers,
            int actualMaxNbTasksPerWorker, int nbSlots) {
        TIntObjectMap<Worker> slotToWorker = new TIntObjectHashMap<>();
        int currentSlot = 0;
        Iterator<Worker> iterWorkers = workers.iterator();
        while (iterWorkers.hasNext() && currentSlot < nbSlots) {
            Worker currentWorker = iterWorkers.next();
            int i = 0;
            while (i < actualMaxNbTasksPerWorker && currentSlot < nbSlots) {
                slotToWorker.put(currentSlot, currentWorker);
                currentSlot++;
                i++;
            }
        }

        return slotToWorker;
    }

    static TIntObjectMap<Task> getSlotToTaskMap(
            Multimap<Job, Task> mutableJobs) {
        TIntObjectMap<Task> slotToTask = new TIntObjectHashMap<>();
        int currentSlot = 0;
        for (Task t : mutableJobs.values()) {
            slotToTask.put(currentSlot, t);
            currentSlot++;
        }
        return slotToTask;
    }

    @Override
    public Double getForcedAlpha() {
        return forcedAlpha;
    }

    @Override
    public Double getForcedBeta() {
       return forcedBeta;
    }
}
