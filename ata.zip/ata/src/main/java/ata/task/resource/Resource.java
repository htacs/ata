package ata.task.resource;

import java.net.URL;

/**
 * an external resource for a task (img, audio)
 */
public abstract class Resource {

    /**
     * URL of resource
     */
    private final URL url;

    /**
     * location of resource on localhost
     */
    private final String path;

    public Resource(URL url, String path) {
        super();
        this.url = url;
        this.path = path;
    }

    // TODO: return a copy
    public URL getUrl() {
        return url;
    }

    public String getPath() {
        return path;
    }

    @Override
    public String toString() {
        if (url == null) {
            return "no resource";
        }
        return "url: " + url.toString() + "\tpath: " + path;
    }

}
