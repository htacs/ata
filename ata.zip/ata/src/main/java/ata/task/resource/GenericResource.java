package ata.task.resource;

import java.net.URL;

public class GenericResource extends Resource {

	public GenericResource(URL resourceUrl, String resourcePath) {
		super(resourceUrl, resourcePath);
	}

}
