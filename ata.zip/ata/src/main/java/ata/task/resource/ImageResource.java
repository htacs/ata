package ata.task.resource;

import java.net.URL;

public class ImageResource extends Resource{

	public ImageResource(URL resourceUrl, String resourcePath) {
		super(resourceUrl, resourcePath);
		
	}
	
	
	
}
