package ata.task.resource;

import java.net.URL;

public class AudioResource extends Resource{

	public AudioResource(URL resourceUrl, String resourcePath) {
		super(resourceUrl, resourcePath);
		
	}
	
	
}
