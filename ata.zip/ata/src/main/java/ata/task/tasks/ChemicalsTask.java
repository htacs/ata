package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.CANT_DECIDE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class ChemicalsTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "What is the relation between this chemical and this disease ?";

    private final static String KEY_DIRECT = "directRelation";
    private final static String VALUE_DIRECT = "Direct Relation";

    private final static String KEY_INDIRECT = "indirectRelation";
    private final static String VALUE_INDIRECT = "Indirect Relation";

    private final static String KEY_NO_RELATION = "noRelation";
    private final static String VALUE_NO_RELATION = "No Relation";

    private final static String CONTENT1 = "Chemical";
    private final String chemical;

    private final static String CONTENT2 = "Disease";
    private final String disease;

    private final static String CONTENT3 = "Sentence";
    private final String sentence;

    public ChemicalsTask(int id, Resource resource, Job job, String chemical,
            String disease, String sentence) {
        super(id, resource, job);
        this.chemical = chemical;
        this.disease = disease;
        this.sentence = sentence;
        List<Answer> possibleAnswers1 = new ArrayList<>();
        possibleAnswers1.add(new Answer(KEY_DIRECT, VALUE_DIRECT));
        possibleAnswers1.add(new Answer(KEY_INDIRECT, VALUE_INDIRECT));
        possibleAnswers1.add(new Answer(KEY_NO_RELATION, VALUE_NO_RELATION));
        possibleAnswers1.add(CANT_DECIDE);
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers1, Question.type.radio, true);

        super.questions.add(question1);

        Content content1 = new Content(CONTENT1, chemical, Content.type.text);
        Content content2 = new Content(CONTENT2, disease, Content.type.text);
        Content content3 = new Content(CONTENT3, sentence, Content.type.text);
        super.contents.add(content1);
        super.contents.add(content2);
        super.contents.add(content3);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkAllAnswered(answerParameterMap);
    }

    public String getChemical() {
        return chemical;
    }

    public String getDisease() {
        return disease;
    }

    public String getSentence() {
        return sentence;
    }

}
