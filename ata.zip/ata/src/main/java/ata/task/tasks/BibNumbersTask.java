package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.KEY_NO;
import static ata.task.tasks.CommonQuestionsAnswers.KEY_YES;
import static ata.task.tasks.CommonQuestionsAnswers.NO;
import static ata.task.tasks.CommonQuestionsAnswers.YES;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class BibNumbersTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "Can you determine bib numbers from this image?";

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "If yes, please enter the bib numbers separated by a semi-colon (;)";

    public static final String PLEASE_GIVE_NUMBERS_SEMICOLON = "Numbers only, separated by a \";\" (e.g. 1378;1250)";

    public static final String SEPARATOR = ";";

    private final static String CONTENT1 = "Picture";

    public BibNumbersTask(int id, Resource resource, Job job) {
        super(id, resource, job);

        Question question0 = super.getBrokenLinkQuestion();

        List<Answer> possibleAnswers = new ArrayList<>();
        possibleAnswers.add(YES);
        possibleAnswers.add(NO);
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers, Question.type.radio, true);

        List<Answer> possibleAnswers2 = new ArrayList<>();
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.bibNumbers, false);

        super.questions.add(question0);
        super.questions.add(question1);
        super.questions.add(question2);

        Content content = new Content(CONTENT1,
                this.getResource().getPath().toString(), Content.type.img);
        super.contents.add(content);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        // check broken link check box
        if (answerParameterMap
                .get(this.getQuestions().get(0).getId()) != null) {
            return new HashMap<>();
        }

        int size = this.getQuestions().size();
        List<Question> questionsToCheck = this.getQuestions().subList(1, size);
        // first check presence of values
        Map<String, String> out = super.checkFirstThenAllOthersOnSubset(
                answerParameterMap, KEY_YES, questionsToCheck);
        if (!out.isEmpty()) {
            return out;
        }
        // yes/no is checked
        if (answerParameterMap.get(QUESTION1_ID)[0].equals(KEY_NO)) {
            // nothing to do
            return out;
        }
        // yes is checked and there is something entered

        String[] res = answerParameterMap.get(QUESTION2_ID)[0].split(SEPARATOR);
        for (String s : res) {
            try {
                Integer.parseInt(s);
            } catch (NumberFormatException e) {
                out.put(QUESTION2_ID, PLEASE_GIVE_NUMBERS_SEMICOLON);
                break;
            }
        }

        return out;
    }

}
