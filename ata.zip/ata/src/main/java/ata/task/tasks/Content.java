package ata.task.tasks;

public class Content {

	public enum type {
		text, img, url, audio
	};

	/**
	 * an short identifier e.g. "question1"<br/>
	 * used as hashcode !
	 */
	private final String id;

	/**
	 * the question, might contain html
	 */
	private final String content;


	/**
	 * determines the way it is displayed
	 */
	private final String type;
	
	

	public Content(String id, String content, Content.type type) {
		super();
		this.id = id;
		this.content = content;
		this.type = type.toString();

	}

	public String getId() {
		return id;
	}

	

	public String getType() {
		return type;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Content) {
			Content other = (Content) obj;
			return this.id.equals(other.getId());
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.getId().hashCode();
	}

	public String getContent() {
		return content;
	}
	
	

}
