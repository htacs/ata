package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.CANT_DECIDE;
import static ata.task.tasks.CommonQuestionsAnswers.NO;
import static ata.task.tasks.CommonQuestionsAnswers.NOT_AVAILABLE;
import static ata.task.tasks.CommonQuestionsAnswers.OTHER;
import static ata.task.tasks.CommonQuestionsAnswers.YES;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class HousingAccessibilityTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "Is this area a residential area?";

    private final static String KEY_RESIDENTIAL = "residential";
    private final static String VALUE_RESIDENTIAL = "Residential";

    private final static String KEY_NOT_RESIDENTIAL = "notResidential";
    private final static String VALUE_NOT_RESIDENTIAL = "Not Residential";

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "If it's residential, which homes are the most prevalent in the area?";

    private final static String KEY_PRIVATE_HOUSE = "privateHouse";
    private final static String VALUE_PRIVATE_HOUSE = "Private House";

    private final static String KEY_APARTMENT_BLOCK = "apartmentBlock";
    private final static String VALUE_APARTMENT_BLOCK = "Apartment Block";

    private final static String QUESTION3_ID = "question3";
    private final static String QUESTION3_VALUE = "If it's residential, does the area have proper sidewalks that are wheelchair friendly?";

    private final static String CONTENT1 = "Street View URL";
    private final String url;

    public HousingAccessibilityTask(int id, Resource resource, Job job,
            String url) {
        super(id, resource, job);
        this.url = url;

        List<Answer> possibleAnswers1 = new ArrayList<Answer>();
        possibleAnswers1.add(new Answer(KEY_RESIDENTIAL, VALUE_RESIDENTIAL));
        possibleAnswers1
                .add(new Answer(KEY_NOT_RESIDENTIAL, VALUE_NOT_RESIDENTIAL));
        possibleAnswers1.add(NOT_AVAILABLE);
        possibleAnswers1.add(CANT_DECIDE);
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers1, Question.type.radio, true);

        List<Answer> possibleAnswers2 = new ArrayList<Answer>();
        possibleAnswers2
                .add(new Answer(KEY_PRIVATE_HOUSE, VALUE_PRIVATE_HOUSE));
        possibleAnswers2
                .add(new Answer(KEY_APARTMENT_BLOCK, VALUE_APARTMENT_BLOCK));
        possibleAnswers2.add(OTHER);
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.radio, false);

        List<Answer> possibleAnswers3 = new ArrayList<Answer>();
        possibleAnswers3.add(YES);
        possibleAnswers3.add(NO);
        Question question3 = new Question(QUESTION3_ID, QUESTION3_VALUE,
                possibleAnswers3, Question.type.radio, false);

        super.questions.add(question1);
        super.questions.add(question2);
        super.questions.add(question3);

        Content content1 = new Content(CONTENT1, url, Content.type.url);
        super.contents.add(content1);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkFirstThenAllOthers(answerParameterMap,
                KEY_RESIDENTIAL);
    }

    public String getUrl() {
        return url;
    }

}
