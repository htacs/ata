package ata.task.tasks.comparator;

import java.util.Comparator;

import ata.task.tasks.Task;

/**
 * put tasks in the order of their ids
 *
 */
public class TaskIdComparator implements Comparator<Task> {

    private static TaskIdComparator instance = null;

    public static TaskIdComparator getInstance() {
        if (instance == null) {
            instance = new TaskIdComparator();
        }
        return instance;
    }

    /**
     * we trust the ids, they ARE unique
     */
    @Override
    public int compare(Task o1, Task o2) {
        return Integer.compare(o1.getId(), o2.getId());
    }
}
