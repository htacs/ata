package ata.task.tasks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class PoliceFatalitiesTask extends Task {

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "What is the cause of death?";

    private final static String QUESTION3_ID = "question3";
    private final static String QUESTION3_VALUE = "What is the race of the deceased?";

    private final static String QUESTION4_ID = "question4";
    private final static String QUESTION4_VALUE = "Was the deceased armed?";

    private final static String QUESTION5_ID = "question5";
    private final static String QUESTION5_VALUE = "Did the deceased had priors?";

    private final static String QUESTION6_ID = "question6";
    private final static String QUESTION6_VALUE = "Was the officer involved fired or suspended?";

    private final static String deathCausesPath = "/policeDeathCauses.txt";
    private final static String racesPath = "/policeDeceasedRace.txt";
    private final static String armedPath = "/policeDeceasedArmed.txt";
    private final static String yesNoUnclearPath = "/policeYesNoUnclear.txt";

    private final static String CONTENT1 = "News on website";
    private final String url;

    public PoliceFatalitiesTask(int id, Resource resource, Job job,
            String url) {
        super(id, resource, job);
        this.url = url;

        Question question1 = super.getBrokenLinkQuestion();

        List<Answer> possibleAnswers2 = new ArrayList<Answer>();
        List<String> deathCauses = super.loadPossibleAnswers(deathCausesPath);
        deathCauses.forEach(s -> possibleAnswers2.add(new Answer(s, s)));
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.select, true);

        List<Answer> possibleAnswers3 = new ArrayList<Answer>();
        List<String> raceDeceased = super.loadPossibleAnswers(racesPath);
        raceDeceased.forEach(s -> possibleAnswers3.add(new Answer(s, s)));
        Question question3 = new Question(QUESTION3_ID, QUESTION3_VALUE,
                possibleAnswers3, Question.type.select, true);

        List<Answer> possibleAnswers4 = new ArrayList<Answer>();
        List<String> deceasedArmed = super.loadPossibleAnswers(armedPath);
        deceasedArmed.forEach(s -> possibleAnswers4.add(new Answer(s, s)));
        Question question4 = new Question(QUESTION4_ID, QUESTION4_VALUE,
                possibleAnswers4, Question.type.select, true);

        List<Answer> possibleAnswers5 = new ArrayList<Answer>();
        List<String> yesNoUnclear = super.loadPossibleAnswers(yesNoUnclearPath);
        yesNoUnclear.forEach(s -> possibleAnswers5.add(new Answer(s, s)));
        Question question5 = new Question(QUESTION5_ID, QUESTION5_VALUE,
                possibleAnswers5, Question.type.select, true);

        List<Answer> possibleAnswers6 = new ArrayList<Answer>();
        yesNoUnclear.forEach(s -> possibleAnswers6.add(new Answer(s, s)));
        Question question6 = new Question(QUESTION6_ID, QUESTION6_VALUE,
                possibleAnswers6, Question.type.select, true);

        super.questions.add(question1);
        super.questions.add(question2);
        super.questions.add(question3);
        super.questions.add(question4);
        super.questions.add(question5);
        super.questions.add(question6);

        Content content1 = new Content(CONTENT1, url, Content.type.url);
        super.contents.add(content1);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkFirstNullThenAll(answerParameterMap);
    }

    public String getUrl() {
        return url;
    }

}
