package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.BROKEN_RES_QUESTION_ID;
import static ata.task.tasks.CommonQuestionsAnswers.BROKEN_RES_QUESTION_VALUE;
import static ata.task.tasks.CommonQuestionsAnswers.KEY_BROKEN;
import static ata.task.tasks.CommonQuestionsAnswers.VALUE_BROKEN;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.google.common.collect.ImmutableList;

import ata.assignments.Assignment;
import ata.graphs.Node;
import ata.misc.RandomGeneratorCustom;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

/**
 * abstract class for any kind of task
 *
 */
public abstract class Task implements Node {
    // common content

    /**
     * a unique ID given by the db. not necessarily the one from CF.
     */
    private final int id;

    /**
     * external resource attached to this task. never null (even if empty).
     */
    private final Resource resource;

    /**
     * the job to which this task is associated
     */
    private final Job job;

    /**
     * a "fake" id to be displayed on the web
     */
    private final int webId;

    /**
     * Question object to be instanciated by the concrete task<br/>
     * used a list to enforce the order in which question appear
     */
    List<Question> questions;

    List<Content> contents;

    /**
     * generate a task answer
     * 
     * @param assignment
     * @param answerDate
     * @param objects
     * @return
     */
    public abstract TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap);

    /**
     * 
     * @param answerParameterMap
     * @return
     */
    public abstract Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap);

    public Task(int id, Resource resource, Job job) {
        super();
        this.id = id;
        this.resource = resource;
        this.job = job;
        this.questions = new ArrayList<>();
        this.contents = new ArrayList<>();
        // set web id
        int a = RandomGeneratorCustom.getInstance().getRandom().nextInt(id);
        int b = (int) Math.floor((double) a / 10000) * 10000;
        this.webId = a - b;
    }

    public int getId() {
        return id;
    }

    public Resource getResource() {
        return resource;
    }

    public Job getJob() {
        return job;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("");
        sb.append("task " + id);
        sb.append("-" + this.getClass().getSimpleName());
        // sb.append("-res:" + this.resource.toString());
        sb.append("-job " + this.getJob());
        return sb.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        // if node, use the id
        if (obj instanceof Node) {
            Node other = (Node) obj;
            if (id != other.getId()) {
                return false;
            }
            return true;
        }
        // else classic comparison
        if (getClass() != obj.getClass())
            return false;
        Task other = (Task) obj;
        if (id != other.id)
            return false;
        return true;
    }
    
    
    

    public List<Question> getQuestions() {
        return ImmutableList.copyOf(questions);
    }


    /**
     * checks that ALL question are answered
     * 
     * @param answerParameterMap
     * @return
     */
    public Map<String, String> checkAllAnswered(
            Map<String, String[]> answerParameterMap) {
        Map<String, String> errors = new HashMap<>();
        for (Question question : this.questions) {
            // something must be checked
            if (answerParameterMap.get(question.getId()) == null) {
                errors.put(question.getId(), Question.PLEASE_SELECT_AN_ANSWER);
            } else {
                if (answerParameterMap.get(question.getId())[0].equals("")) {
                    errors.put(question.getId(),
                            Question.PLEASE_SELECT_AN_ANSWER);
                }
            }
        }
        return errors;
    }

    /**
     * Checks thats a subset is answered
     * 
     * 
     * @param answerParameterMap
     * @param questionsToCheck
     *            the set of questions that is checked
     * @return
     */
    public Map<String, String> checkSubsetAnswered(
            Map<String, String[]> answerParameterMap,
            List<Question> questionsToCheck) {
        Map<String, String> errors = new HashMap<>();
        for (Question question : questionsToCheck) {
            // something must be checked
            if (answerParameterMap.get(question.getId()) == null) {
                errors.put(question.getId(), Question.PLEASE_SELECT_AN_ANSWER);

            } else {
                if (answerParameterMap.get(question.getId())[0].equals("")) {
                    errors.put(question.getId(),
                            Question.PLEASE_SELECT_AN_ANSWER);
                } else if (answerParameterMap.get(question.getId())[0]
                        .equals(Question.SELECT)) {
                    errors.put(question.getId(),
                            Question.PLEASE_SELECT_AN_ANSWER);
                }
            }
        }
        return errors;
    }

    /**
     * checks if the parameter passed are non-empty, using the question from
     * this task
     * 
     * @param answerParameterMap
     * @return
     */
    public Map<String, String> checkFirstThenAllOthers(
            Map<String, String[]> answerParameterMap,
            String valueThatImpliesOtherCheck) {
        return checkFirstThenAllOthersOnSubset(answerParameterMap,
                valueThatImpliesOtherCheck, this.getQuestions());
    }

    /**
     * checks if the parameter passed are non-empty, using the question from
     * this task
     * 
     * @param answerParameterMap
     * @return
     */
    public Map<String, String> checkFirstThenAllOthersOnSubset(
            Map<String, String[]> answerParameterMap,
            String valueThatImpliesOtherCheck,
            List<Question> questionsToCheck) {
        Map<String, String> errors = new HashMap<>();
        Question question1 = questionsToCheck.get(0);
        if (answerParameterMap.get(question1.getId()) == null) {
            errors.put(question1.getId(), Question.PLEASE_SELECT_AN_ANSWER);
        } else {
            String answer = answerParameterMap.get(question1.getId())[0];
            if (answer.equals(valueThatImpliesOtherCheck)) {
                // build a subset
                List<Question> questionsToCheckSubset = questionsToCheck
                        .subList(1, questionsToCheck.size());
                // check subset
                errors.putAll(checkSubsetAnswered(answerParameterMap,
                        questionsToCheckSubset));
            }
        }
        return errors;
    }

    /**
     * checks the
     * 
     * @param answerParameterMap
     * @return
     */
    public Map<String, String> checkFirstNullThenAll(
            Map<String, String[]> answerParameterMap) {
        // check broken link check box
        if (answerParameterMap
                .get(this.getQuestions().get(0).getId()) != null) {
            return new HashMap<>();
        }
        int size = this.getQuestions().size();
        List<Question> questionsToCheck = this.getQuestions().subList(1, size);
        return checkSubsetAnswered(answerParameterMap, questionsToCheck);
    }

    /**
     * all option of a select are checked
     * 
     * @param answerParameterMap
     * @return
     */
    public Map<String, String> checkAllNonEmptySelects(
            Map<String, String[]> answerParameterMap) {
        Map<String, String> errors = new HashMap<>();
        for (Question q : this.getQuestions()) {
            // check that it is filled
            if (answerParameterMap.get(q.getId()) != null) {
                if (answerParameterMap.get(q.getId())[0].equals(Question.SELECT)
                        || answerParameterMap.get(q.getId())[0].equals("")) {
                    errors.put(q.getId(), Question.PLEASE_SELECT_AN_ANSWER);
                }
            } else {
                errors.put(q.getId(), Question.PLEASE_SELECT_AN_ANSWER);
            }
        }
        return errors;
    }

    /**
     * checks if the parameter passed are non-empty, using the question from
     * this task
     * 
     * @param answerParameterMap
     * @return
     */
    public Map<String, String> checkNonEmptyNumbers(
            Map<String, String[]> answerParameterMap) {
        Map<String, String> errors = new HashMap<>();
        for (Question question : this.questions) {
            if (answerParameterMap.get(question.getId()) == null) {
                errors.put(question.getId(), Question.PLEASE_SELECT_AN_ANSWER);
            } else {
                if (answerParameterMap.get(question.getId())[0].equals("")) {
                    errors.put(question.getId(),
                            Question.PLEASE_ENTER_A_NUMBER);
                }
            }
        }
        return errors;
    }

    /**
     * loads a list of words from a file (one line=one word)
     * 
     * @param filePath
     * @return
     */
    List<String> loadPossibleAnswers(String filePath) {
        BufferedReader br = null;
        List<String> out = new ArrayList<>();
        try {
            br = new BufferedReader(new InputStreamReader(
                    getClass().getResourceAsStream(filePath)));
            String line = null;
            while ((line = br.readLine()) != null) {
                out.add(line);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return out;

    }

    Question getBrokenLinkQuestion() {
        List<Answer> possibleAnswers1 = new ArrayList<Answer>();
        possibleAnswers1.add(new Answer(KEY_BROKEN, VALUE_BROKEN));
        return new Question(BROKEN_RES_QUESTION_ID, BROKEN_RES_QUESTION_VALUE,
                possibleAnswers1, Question.type.checkBox, false);
    }

    public List<Content> getContents() {
        return contents;
    }

    public int getWebId() {
        return webId;
    }

}
