package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.UNKNOWN;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class WikiImageGenderTask extends Task {

    private final static String QUESTION2_ID = "question1";
    private final static String QUESTION2_VALUE = "How many persons are present on the picture?";

    private final static String QUESTION3_ID = "question2";
    private final static String QUESTION3_VALUE = "If there are persons, which gender is dominant among them?";

    private final static String KEY_NO_PERSON = "noPerson";
    private final static String VALUE_NO_PERSON = "No Person";

    private final static String KEY_ONE_PERSON = "onePerson";
    private final static String VALUE_ONE_PERSON = "One Person";

    private final static String KEY_SEVERAL_ONE_DOMINANT = "severalPersonsOneDominant";
    private final static String VALUE_SEVERAL_ONE_DOMINANT = "Several Persons, but one person's depiction is dominant";

    private final static String KEY_SEVERAL_NO_DOMINANT = "severalPersonsNoDominant";
    private final static String VALUE_SEVERAL_NO_DOMINANT = "Several Persons, no single person's depiction is dominant";

    private final static String KEY_MOSTLY_FEMALE = "mostlyFemale";
    private final static String VALUE_MOSTLY_FEMALE = "Mostly Female";

    private final static String KEY_MOSTLY_MALE = "mostlyMale";
    private final static String VALUE_MOSTLY_MALE = "Mostly Male";

    private final static String CONTENT1 = "Picture";

    public WikiImageGenderTask(int id, Resource resource, Job job) {
        super(id, resource, job);

        Question question1 = super.getBrokenLinkQuestion();

        List<Answer> possibleAnswers2 = new ArrayList<>();
        possibleAnswers2.add(new Answer(KEY_NO_PERSON, VALUE_NO_PERSON));
        possibleAnswers2.add(new Answer(KEY_ONE_PERSON, VALUE_ONE_PERSON));
        possibleAnswers2.add(new Answer(KEY_SEVERAL_ONE_DOMINANT,
                VALUE_SEVERAL_ONE_DOMINANT));
        possibleAnswers2.add(
                new Answer(KEY_SEVERAL_NO_DOMINANT, VALUE_SEVERAL_NO_DOMINANT));
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.radio, true);

        List<Answer> possibleAnswers3 = new ArrayList<>();
        possibleAnswers3
                .add(new Answer(KEY_MOSTLY_FEMALE, VALUE_MOSTLY_FEMALE));
        possibleAnswers3.add(new Answer(KEY_MOSTLY_MALE, VALUE_MOSTLY_MALE));
        possibleAnswers3.add(UNKNOWN);
        Question question3 = new Question(QUESTION3_ID, QUESTION3_VALUE,
                possibleAnswers3, Question.type.radio, false);

        super.questions.add(question1);
        super.questions.add(question2);
        super.questions.add(question3);

        Content content = new Content(CONTENT1,
                this.getResource().getPath().toString(), Content.type.img);
        super.contents.add(content);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        // check broken link check box
        if (answerParameterMap
                .get(this.getQuestions().get(0).getId()) != null) {
            return new HashMap<>();
        }
        int size = this.getQuestions().size();
        List<Question> questionsToCheck = this.getQuestions().subList(1, size);
        // check first, then others
        Map<String, String> errors = new HashMap<>();
        Question question1 = questionsToCheck.get(0);
        if (answerParameterMap.get(question1.getId()) == null) {
            errors.put(question1.getId(), Question.PLEASE_SELECT_AN_ANSWER);
        } else {
            String answer = answerParameterMap.get(question1.getId())[0];
            if (!answer.equals(KEY_NO_PERSON)) {
                // build a subset
                List<Question> questionsToCheckSubset = questionsToCheck
                        .subList(1, questionsToCheck.size());
                // check subset
                errors.putAll(checkSubsetAnswered(answerParameterMap,
                        questionsToCheckSubset));
            }
        }
        return errors;
    }

}
