package ata.task.tasks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class SmartphoneTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "What is the full name of the device?";

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "Is it a smartphone or a tablet?";

    private final static String KEY_SMARTPHONE = "smartphone";
    private final static String VALUE_SMARTPHONE = "Smartphone";

    private final static String KEY_TABLET = "tablet";
    private final static String VALUE_TABLET = "Tablet";

    private final static String CONTENT1 = "Model Code";
    private final String model;

    public SmartphoneTask(int id, Resource resource, Job job, String model) {
        super(id, resource, job);
        this.model = model;
        List<Answer> possibleAnswers = new ArrayList<>();
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers, Question.type.freetext, true);

        List<Answer> possibleAnswers2 = new ArrayList<>();
        possibleAnswers2.add(new Answer(KEY_SMARTPHONE, VALUE_SMARTPHONE));
        possibleAnswers2.add(new Answer(KEY_TABLET, VALUE_TABLET));
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.radio, true);

        super.questions.add(question1);
        super.questions.add(question2);

        Content content1 = new Content(CONTENT1, model, Content.type.text);
        super.contents.add(content1);
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkAllAnswered(answerParameterMap);
    }

    public String getModel() {
        return model;
    }

}
