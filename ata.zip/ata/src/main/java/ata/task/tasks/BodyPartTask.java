package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.CANT_DECIDE;
import static ata.task.tasks.CommonQuestionsAnswers.NO;
import static ata.task.tasks.CommonQuestionsAnswers.YES;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class BodyPartTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "Is the first body element part of the second element?";

    private final String firstPart;

    private final String secondPart;

    private final static String CONTENT1 = "Part 1";

    private final static String CONTENT2 = "Part 2";

    public BodyPartTask(int id, Resource resource, Job job, String firstPart,
            String secondPart) {
        super(id, resource, job);
        this.firstPart = firstPart;
        this.secondPart = secondPart;
        List<Answer> possibleAnswers = new ArrayList<>();
        possibleAnswers.add(NO);
        possibleAnswers.add(YES);
        possibleAnswers.add(CANT_DECIDE);
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers, Question.type.radio, true);
        super.questions.add(question1);

        Content content1 = new Content(CONTENT1, firstPart, Content.type.text);
        Content content2 = new Content(CONTENT2, secondPart, Content.type.text);
        super.contents.add(content1);
        super.contents.add(content2);
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkAllAnswered(answerParameterMap);
    }

    public String getFirstPart() {
        return firstPart;
    }

    public String getSecondPart() {
        return secondPart;
    }

}
