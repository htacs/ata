package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.CANT_DECIDE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class HateSpeechTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "Classify the tweet";

    private final static String KEY_HATE_SPEECH = "hateSpeech";
    private final static String VALUE_HATE_SPEECH = "The tweet contains hate speech";

    private final static String KEY_OFFENSIVE_LANGUAGE = "offensiveLanguage";
    private final static String VALUE_OFFENSIVE_LANGUAGE = "The tweet uses offensive language but not hate speech";

    private final static String KEY_NOT_OFFENSIVE = "notOffensive";
    private final static String VALUE_NOT_OFFENSIVE = "The tweet is not offensive";

    private final String CONTENT1 = "Tweet";
    private final String tweet;

    public HateSpeechTask(int id, Resource resource, Job job, String tweet) {
        super(id, resource, job);
        this.tweet = tweet;
        List<Answer> possibleAnswers = new ArrayList<>();
        possibleAnswers.add(new Answer(KEY_HATE_SPEECH, VALUE_HATE_SPEECH));
        possibleAnswers.add(
                new Answer(KEY_OFFENSIVE_LANGUAGE, VALUE_OFFENSIVE_LANGUAGE));
        possibleAnswers.add(new Answer(KEY_NOT_OFFENSIVE, VALUE_NOT_OFFENSIVE));
        possibleAnswers.add(CANT_DECIDE);
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers, Question.type.radio, true);
        super.questions.add(question1);

        Content content1 = new Content(CONTENT1, tweet, Content.type.text);
        super.contents.add(content1);
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkAllAnswered(answerParameterMap);
    }

    public String getTweet() {
        return tweet;
    }

}
