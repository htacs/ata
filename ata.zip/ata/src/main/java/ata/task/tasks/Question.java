package ata.task.tasks;

import java.util.ArrayList;
import java.util.List;

public class Question {

    public enum type {
        freetext, radio, select, bibNumbers, checkBox, number, biSelect
    };

    /**
     * an short identifier e.g. "question1"<br/>
     * used as hashcode !
     */
    private final String id;

    /**
     * the question, might contain html
     */
    private final String questionText;

    /**
     * key:shortIdentifier of the answer. <br/>
     * Value=readable answer, to be displayed.
     */
    private final List<Answer> possibleAnswers;

    /**
     * determines the way it is displayed
     */
    private final String type;

    /**
     * answer required or not ?
     */
    private final boolean required;

    public static final String PLEASE_SELECT_AN_ANSWER = "Please select an answer.";

    public static final String PLEASE_ENTER_AN_ANSWER = "Please enter an answer.";

    public static final String PLEASE_ENTER_A_NUMBER = "Please enter a number (0 if necessary).";

    public static final String SELECT = "--select--";

    // public Question() {
    // this.id = "";
    // this.questionText = "";
    // this.possibleAnswers = new ArrayList<>();
    // this.type = "";
    // }

    public Question(String id, String questionText,
            List<Answer> possibleAnswers, Question.type type,
            boolean required) {
        super();
        this.id = id;
        this.questionText = questionText;
        this.possibleAnswers = new ArrayList<>(possibleAnswers);
        this.type = type.toString();
        this.required = required;

    }

    public String getId() {
        return id;
    }

    public String getQuestionText() {
        return questionText;
    }

    public List<Answer> getPossibleAnswers() {
        return possibleAnswers;
    }

    public String getType() {
        return type;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Question) {
            Question other = (Question) obj;
            return this.id.equals(other.getId());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return this.getId().hashCode();
    }

    public String getPleaseSelectAnAnswer() {
        return PLEASE_SELECT_AN_ANSWER;
    }

    public String getSelect() {
        return SELECT;
    }

    public boolean isRequired() {
        return required;
    }

}
