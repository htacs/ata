package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.FEMALE;
import static ata.task.tasks.CommonQuestionsAnswers.KEY_YES;
import static ata.task.tasks.CommonQuestionsAnswers.MALE;
import static ata.task.tasks.CommonQuestionsAnswers.NO;
import static ata.task.tasks.CommonQuestionsAnswers.YES;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class PeopleAndFoodTask extends Task {

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "Is there somebody eating?";

    private final static String QUESTION3_ID = "question3";
    private final static String QUESTION3_VALUE = "If people are eating please give their gender";

    private final static String QUESTION4_ID = "question4";
    private final static String QUESTION4_VALUE = "If people are eating please give their age";

    private final static String KEY_ADULT = "adult";
    private final static String VALUE_ADULT = "Adult/Teenager (13 or older)";

    private final static String KEY_YOUNG = "kid";
    private final static String VALUE_YOUNG = "Kid (younger than 13)";

    private final static String CONTENT1 = "Picture";

    public PeopleAndFoodTask(int id, Resource resource, Job job) {
        super(id, resource, job);
        Question question1 = super.getBrokenLinkQuestion();
        //
        List<Answer> possibleAnswers2 = new ArrayList<>();
        possibleAnswers2.add(YES);
        possibleAnswers2.add(NO);
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.radio, true);

        List<Answer> possibleAnswers3 = new ArrayList<>();
        possibleAnswers3.add(MALE);
        possibleAnswers3.add(FEMALE);
        Question question3 = new Question(QUESTION3_ID, QUESTION3_VALUE,
                possibleAnswers3, Question.type.radio, false);

        List<Answer> possibleAnswers4 = new ArrayList<>();
        possibleAnswers4.add(new Answer(KEY_ADULT, VALUE_ADULT));
        possibleAnswers4.add(new Answer(KEY_YOUNG, VALUE_YOUNG));
        Question question4 = new Question(QUESTION4_ID, QUESTION4_VALUE,
                possibleAnswers4, Question.type.radio, false);

        super.questions.add(question1);
        super.questions.add(question2);
        super.questions.add(question3);
        super.questions.add(question4);

        Content content1 = new Content(CONTENT1,
                this.getResource().getPath().toString(), Content.type.img);
        super.contents.add(content1);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        // check broken link check box
        if (answerParameterMap
                .get(this.getQuestions().get(0).getId()) != null) {
            return new HashMap<>();
        }
        int size = this.getQuestions().size();
        List<Question> questionsToCheck = this.getQuestions().subList(1, size);
        // check first, then others
        Map<String, String> errors = new HashMap<>();
        Question question1 = questionsToCheck.get(0);
        if (answerParameterMap.get(question1.getId()) == null) {
            errors.put(question1.getId(), Question.PLEASE_SELECT_AN_ANSWER);
        } else {
            String answer = answerParameterMap.get(question1.getId())[0];
            if (answer.equals(KEY_YES)) {
                // build a subset
                List<Question> questionsToCheckSubset = questionsToCheck
                        .subList(1, questionsToCheck.size());
                // check subset
                errors.putAll(checkSubsetAnswered(answerParameterMap,
                        questionsToCheckSubset));
            }
        }
        return errors;
    }

}
