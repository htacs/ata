package ata.task.tasks;

import java.util.Map;

import org.joda.time.DateTime;

import com.eclipsesource.json.JsonObject;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

/**
 * represents any CF task using a k-v pairs
 *
 */
public class GenericTask extends Task {

    // private final static String QUESTION1_ID = "question1";
    // private final static String QUESTION1_VALUE = "question1_value";
    //
    // private final static String QUESTION2_ID = "question2";
    // private final static String QUESTION2_VALUE = "question2_value";
    //
    // private final static String KEY_Q1_ANSWER1 = "keyQ1Answer1";
    // private final static String VALUE_Q1_ANSWER1 = "valueQ1Answer1";
    //
    // private final static String KEY_Q1_ANSWER2 = "keyQ1Answer2";
    // private final static String VALUE_Q1_ANSWER2 = "valueQ1Answer2";
    //
    // private final static String KEY_Q2_ANSWER1 = "keyQ2Answer1";
    // private final static String VALUE_Q2_ANSWER1 = "valueQ2Answer1";
    //
    // private final static String KEY_Q2_ANSWER2 = "keyQ2Answer2";
    // private final static String VALUE_Q2_ANSWER2 = "valueQ2Answer2";

    private final JsonObject items;

    public GenericTask(int id, Resource resource, JsonObject items, Job job) {
        super(id, resource, job);
        this.items = items;
        // List<Answer> possibleAnswers1 = new ArrayList<>();
        // possibleAnswers1.add(new Answer(KEY_Q1_ANSWER1, VALUE_Q1_ANSWER1));
        // possibleAnswers1.add(new Answer(KEY_Q1_ANSWER2, VALUE_Q1_ANSWER2));
        //
        // List<Answer> possibleAnswers2 = new ArrayList<>();
        // possibleAnswers2.add(new Answer(KEY_Q2_ANSWER1, VALUE_Q2_ANSWER1));
        // possibleAnswers2.add(new Answer(KEY_Q2_ANSWER2, VALUE_Q2_ANSWER2));
        //
        // Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
        // possibleAnswers1, Question.type.radio, true);
        // Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
        // possibleAnswers2, Question.type.radio, true);
        //
        // super.questions.add(question1);
        // super.questions.add(question2);

    }

    public JsonObject getItems() {
        return items;
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkAllAnswered(answerParameterMap);
    }

}
