package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.CANT_DECIDE;
import static ata.task.tasks.CommonQuestionsAnswers.KEY_NEGATIVE;
import static ata.task.tasks.CommonQuestionsAnswers.NEGATIVE;
import static ata.task.tasks.CommonQuestionsAnswers.NEUTRAL;
import static ata.task.tasks.CommonQuestionsAnswers.POSITIVE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class AirlineSentimentTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "Classify the tone of the tweet against the airline";

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "If the tone is negative, please categorize the reason";

    private final static String CONTENT1 = "Tweet";

    private final static String pathReasons = "/airlineReasons.txt";

    private final String tweet;

    public AirlineSentimentTask(int id, Resource resource, Job job,
            String tweet) {
        super(id, resource, job);
        this.tweet = tweet;
        List<Answer> possibleAnswers = new ArrayList<>();
        possibleAnswers.add(NEGATIVE);
        possibleAnswers.add(NEUTRAL);
        possibleAnswers.add(POSITIVE);
        possibleAnswers.add(CANT_DECIDE);
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers, Question.type.radio, true);

        List<Answer> possibleAnswers2 = new ArrayList<>();
        List<String> reasons = super.loadPossibleAnswers(pathReasons);
        reasons.forEach(s -> possibleAnswers2.add(new Answer(s, s)));
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.select, false);

        super.questions.add(question1);
        super.questions.add(question2);

        Content content = new Content(CONTENT1, tweet, Content.type.text);
        super.contents.add(content);
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkFirstThenAllOthers(answerParameterMap, KEY_NEGATIVE);
    }

    public String getTweet() {
        return tweet;
    }

}
