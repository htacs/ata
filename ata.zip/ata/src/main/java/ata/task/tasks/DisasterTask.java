package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.*;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class DisasterTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "Is the article relevant to a disaster?";

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "If yes, what is the keyword that best describes this disaster ?";

    private final static String keywordsFilePath = "/disasterKeywords.txt";

    private final static String CONTENT1 = "Tweet";
    private final String tweet;

    public DisasterTask(int id, Resource resource, Job job, String tweet) {
        super(id, resource, job);
        this.tweet = tweet;
        List<Answer> possibleAnswers1 = new ArrayList<>();
        possibleAnswers1.add(RELEVANT);
        possibleAnswers1.add(NOT_RELEVANT);
        possibleAnswers1.add(CANT_DECIDE);
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers1, Question.type.radio, true);

        List<Answer> possibleAnswers2 = new ArrayList<>();
        List<String> possibleKeywords = super.loadPossibleAnswers(
                keywordsFilePath);
        possibleKeywords.stream()
                .forEach(s -> possibleAnswers2.add(new Answer(s, s)));
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.select, false);

        super.questions.add(question1);
        super.questions.add(question2);

        Content content1 = new Content(CONTENT1, tweet, Content.type.text);
        super.contents.add(content1);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkFirstThenAllOthers(answerParameterMap, KEY_RELEVANT);
    }

    public String getTweet() {
        return tweet;
    }

}
