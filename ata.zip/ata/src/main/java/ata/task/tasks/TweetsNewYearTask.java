package ata.task.tasks;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class TweetsNewYearTask extends Task {

    private final static String QUESTION1_ID = "question1BiSelect";
    private final static String QUESTION1_VALUE = "Determine the main category that best matches this tweet";

    private final static String QUESTION2_ID = "question2BiSelect";
    private final static String QUESTION2_VALUE = "Determine the sub-category that best matches this tweet";

    private final static String pathCategories = "/tweetsNewYearCategories.txt";

    private final static String CONTENT1 = "Tweet";
    private final String tweet;

    public TweetsNewYearTask(int id, Resource resource, Job job, String tweet) {
        super(id, resource, job);
        this.tweet = tweet;
        List<Answer> mainAnswers = new ArrayList<>();
        List<Answer> subAnswers = new ArrayList<>();
        Map<String, List<String>> categories = getCategories(pathCategories);
        for (String mainCategory : categories.keySet()) {
            mainAnswers
                    .add(new Answer(cleanAnswerId(mainCategory), mainCategory));
            for (String subCategory : categories.get(mainCategory)) {
                subAnswers.add(new Answer(cleanAnswerId(subCategory),
                        subCategory, cleanAnswerId(mainCategory)));
            }
        }
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                mainAnswers, Question.type.biSelect, true);
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                subAnswers, Question.type.biSelect, true);

        super.questions.add(question1);
        super.questions.add(question2);

        Content content1 = new Content(CONTENT1, tweet, Content.type.text);
        super.contents.add(content1);
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkAllNonEmptySelects(answerParameterMap);
    }

    public String getTweet() {
        return tweet;
    }

    /**
     * load categories and sub categories
     * 
     * @param pathCategories
     * @return
     */
    public Map<String, List<String>> getCategories(String pathCategories) {
        Map<String, List<String>> out = new HashMap<>();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(
                    getClass().getResourceAsStream(pathCategories)));
            String line = null;
            while ((line = br.readLine()) != null) {
                String mainCategory = line.split(";")[0];
                String subCategory = line.split(";")[1];
                if (out.containsKey(mainCategory)) {
                    out.get(mainCategory).add(subCategory);
                } else {
                    List<String> subCat = new ArrayList<>();
                    subCat.add(subCategory);
                    out.put(mainCategory, subCat);
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return out;
    }

    public String cleanAnswerId(String answerId) {
        String out = answerId;
        out = out.replaceAll("/", "_");
        out = out.replaceAll(" ", "_");
        out = out.replaceAll("&", "_");
        return out;
    }
}
