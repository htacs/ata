package ata.task.tasks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class IndianTerrorismTask extends Task {

    // private final static String QUESTION1_ID = "question1";
    // private final static String QUESTION1_VALUE = "How many people of each
    // category were killed?";

    private final static String KEY_CIVILIANS = "civilians";
    private final static String VALUE_CIVILIANS = "Civilians deaths";

    private final static String KEY_MILITANTS = "militants";
    private final static String VALUE_MILITANTS = "Militants/Terrorists/Insurgents deaths";

    private final static String KEY_SECURITY = "security";
    private final static String VALUE_SECURITY = "Security Forces deaths";

    private final static String CONTENT1 = "Sentence";
    private final String sentence;

    public IndianTerrorismTask(int id, Resource resource, Job job,
            String sentence) {
        super(id, resource, job);
        this.sentence = sentence;

        List<Answer> possibleAnswers1 = new ArrayList<Answer>();
        Question question1 = new Question(KEY_CIVILIANS, VALUE_CIVILIANS,
                possibleAnswers1, Question.type.number, true);

        List<Answer> possibleAnswers2 = new ArrayList<Answer>();
        Question question2 = new Question(KEY_MILITANTS, VALUE_MILITANTS,
                possibleAnswers2, Question.type.number, true);

        List<Answer> possibleAnswers3 = new ArrayList<Answer>();
        Question question3 = new Question(KEY_SECURITY, VALUE_SECURITY,
                possibleAnswers3, Question.type.number, true);

        super.questions.add(question1);
        super.questions.add(question2);
        super.questions.add(question3);

        Content content1 = new Content(CONTENT1, sentence, Content.type.text);
        super.contents.add(content1);
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkNonEmptyNumbers(answerParameterMap);
    }

    public String getSentence() {
        return sentence;
    }

}
