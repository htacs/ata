package ata.task.tasks;

public class Answer {

	private final String key;

	private final String value;

	// optional: the key of a main answer

	private String parent;

	public Answer(String key, String value) {
		super();
		this.key = key;
		this.value = value;
	}

	public Answer(String key, String value, String parent) {
		this(key, value);
		this.parent = parent;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public String getParent() {
		return parent;
	}

}
