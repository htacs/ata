package ata.task.tasks;

import static ata.task.tasks.CommonQuestionsAnswers.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class CompanyCategorizationTask extends Task {

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "Does the website matches the company name?";

    private final static String QUESTION3_ID = "question3";
    private final static String QUESTION3_VALUE = "Select the category that best matches this company";

    private final static String pathCategories = "/companyCategories.txt";

    private final static String CONTENT1 = "Company Name";
    private final String companyName;

    private final static String CONTENT2 = "Website";
    private final String url;

    public CompanyCategorizationTask(int id, Resource resource, Job job,
            String url, String companyName) {
        super(id, resource, job);
        this.url = url;
        this.companyName = companyName;

        Question question1 = super.getBrokenLinkQuestion();

        List<Answer> possibleAnswers2 = new ArrayList<>();
        possibleAnswers2.add(YES);
        possibleAnswers2.add(NO);
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.radio, true);

        List<Answer> possibleAnswers3 = new ArrayList<>();
        List<String> categories = super.loadPossibleAnswers(pathCategories);
        categories.forEach(s -> possibleAnswers3.add(new Answer(s, s)));
        Question question3 = new Question(QUESTION3_ID, QUESTION3_VALUE,
                possibleAnswers3, Question.type.radio, true);
        super.questions.add(question1);
        super.questions.add(question2);
        super.questions.add(question3);

        Content content1 = new Content(CONTENT1, companyName,
                Content.type.text);
        Content content2 = new Content(CONTENT2, url, Content.type.url);
        super.contents.add(content1);
        super.contents.add(content2);
    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkFirstNullThenAll(answerParameterMap);
    }

    public String getUrl() {
        return url;
    }

    public String getCompanyName() {
        return companyName;
    }

}
