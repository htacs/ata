package ata.task.tasks;

/**
 * a set of key/values frequently used
 *
 */
public final class CommonQuestionsAnswers {

	public final static String KEY_YES = "yes";
	public final static String VALUE_YES = "Yes";
	public final static Answer YES = new Answer(KEY_YES, VALUE_YES);

	public final static String KEY_NO = "no";
	public final static String VALUE_NO = "No";
	public final static Answer NO = new Answer(KEY_NO, VALUE_NO);

	public final static String KEY_UNKNOWN = "unknown";
	public final static String VALUE_UNKNOWN = "Unknown";
	public final static Answer UNKNOWN = new Answer(KEY_UNKNOWN, VALUE_UNKNOWN);

	public final static String KEY_RELEVANT = "relevant";
	public final static String VALUE_RELEVANT = "Relevant";
	public final static Answer RELEVANT = new Answer(KEY_RELEVANT, VALUE_RELEVANT);

	public final static String KEY_NOT_RELEVANT = "notRelevant";
	public final static String VALUE_NOT_RELEVANT = "Not Relevant";
	public final static Answer NOT_RELEVANT = new Answer(KEY_NOT_RELEVANT, VALUE_NOT_RELEVANT);

	public final static String KEY_CANT_DECIDE = "cantDecide";
	public final static String VALUE_CANT_DECIDE = "I can't decide";
	public final static Answer CANT_DECIDE = new Answer(KEY_CANT_DECIDE, VALUE_CANT_DECIDE);

	public final static String KEY_OTHER = "other";
	public final static String VALUE_OTHER = "Other";
	public final static Answer OTHER = new Answer(KEY_OTHER, VALUE_OTHER);

	public final static String KEY_NOT_AVAILABLE = "notAvailable";
	public final static String VALUE_NOT_AVAILABLE = "Not Available";
	public final static Answer NOT_AVAILABLE = new Answer(KEY_NOT_AVAILABLE, VALUE_NOT_AVAILABLE);

	public final static String KEY_HIGHLY_NEGATIVE = "highlyNegative";
	public final static String VALUE_HIGHLY_NEGATIVE = "Highly Negative";
	public final static Answer HIGHLY_NEGATIVE = new Answer(KEY_HIGHLY_NEGATIVE, VALUE_HIGHLY_NEGATIVE);

	public final static String KEY_NEGATIVE = "negative";
	public final static String VALUE_NEGATIVE = "Negative";
	public final static Answer NEGATIVE = new Answer(KEY_NEGATIVE, VALUE_NEGATIVE);

	public final static String KEY_NEUTRAL = "neutral";
	public final static String VALUE_NEUTRAL = "Neutral";
	public final static Answer NEUTRAL = new Answer(KEY_NEUTRAL, VALUE_NEUTRAL);

	public final static String KEY_POSITIVE = "positive";
	public final static String VALUE_POSITIVE = "Positive";
	public final static Answer POSITIVE = new Answer(KEY_POSITIVE, VALUE_POSITIVE);

	public final static String KEY_HIGHLY_POSITIVE = "highlyPositive";
	public final static String VALUE_HIGHLY_POSITIVE = "Highly Positive";
	public final static Answer HIGHLY_POSITIVE = new Answer(KEY_HIGHLY_POSITIVE, VALUE_HIGHLY_POSITIVE);

	public final static String KEY_MALE = "male";
	public final static String VALUE_MALE = "Male";
	public final static Answer MALE = new Answer(KEY_MALE, VALUE_MALE);

	public final static String KEY_FEMALE = "female";
	public final static String VALUE_FEMALE = "Female";
	public final static Answer FEMALE = new Answer(KEY_FEMALE, VALUE_FEMALE);

	public final static String BROKEN_RES_QUESTION_ID = "brokenResourceQuestion";
	public final static String BROKEN_RES_QUESTION_VALUE = "Is the resource (website/image/audio) NOT available ?";

	public final static String KEY_BROKEN = "brokenResource";
	public final static String VALUE_BROKEN = "Resource not available";
	public final static Answer BROKEN = new Answer(KEY_BROKEN, VALUE_BROKEN);

	public final static String KEY_FREETEXT = "freetext";
	public final static String VALUE_FREETEXT = "freetext";
	public final static Answer FREETEXT = new Answer(KEY_FREETEXT, VALUE_FREETEXT);

	public final static String KEY_TEXT_INCOMPREHENSIBLE = "incomprehensible";
	public final static String VALUE_INCOMPREHENSIBLE = "Text is incomprehensible";
	public final static Answer INCOMPREHENSIBLE = new Answer(KEY_TEXT_INCOMPREHENSIBLE, VALUE_INCOMPREHENSIBLE);

}
