package ata.task.tasks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class BeautifulAnimalsTask extends Task {

    private final static String QUESTION2_ID = "question2";
    private final static String QUESTION2_VALUE = "Rate the quality of this picture? (1=unacceptable, 5=exceptional)";

    private final static String[] labels = { "unacceptable", "", "", "",
            "exceptional" };
    private final static int levels = 5;

    private final static String CONTENT1 = "Picture";

    public BeautifulAnimalsTask(int id, Resource resource, Job job) {
        super(id, resource, job);

        Question question1 = super.getBrokenLinkQuestion();

        List<Answer> possibleAnswers2 = new ArrayList<>();
        for (int i = 1; i <= levels; i++) {
            String label = "";
            if (!labels[i - 1].equals("")) {
                label = "-" + labels[i - 1];
            }
            possibleAnswers2.add(new Answer(Integer.toString(i), i + label));
        }
        Question question2 = new Question(QUESTION2_ID, QUESTION2_VALUE,
                possibleAnswers2, Question.type.radio, true);

        super.questions.add(question1);
        super.questions.add(question2);

        Content content = new Content(CONTENT1,
                this.getResource().getPath().toString(), Content.type.img);
        super.contents.add(content);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkFirstNullThenAll(answerParameterMap);
    }

}
