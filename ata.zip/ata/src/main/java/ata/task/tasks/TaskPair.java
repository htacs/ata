package ata.task.tasks;

public class TaskPair {
	private Task t1;
	private Task t2;
	public TaskPair(Task t1, Task t2) {
		super();
		this.t1 = t1;
		this.t2 = t2;
	}
	public Task getT1() {
		return t1;
	}
	public Task getT2() {
		return t2;
	}
	
}
