package ata.task.tasks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import ata.assignments.Assignment;
import ata.task.jobs.Job;
import ata.task.resource.Resource;
import ata.task.tasksAnswers.TaskAnswer;

public class DressTask extends Task {

    private final static String QUESTION1_ID = "question1";
    private final static String QUESTION1_VALUE = "Which is the pattern or print of the dress ?";

    private final static String PATTERN_FILE_PATH = "/dressPatterns.txt";

    private final static String CONTENT1 = "Picture";

    public DressTask(int id, Resource resource, Job job) {
        super(id, resource, job);

        Question question0 = super.getBrokenLinkQuestion();

        List<Answer> possibleAnswers = new ArrayList<>();
        List<String> possibleKeywords = super.loadPossibleAnswers(
                PATTERN_FILE_PATH);
        possibleKeywords.stream()
                .forEach(s -> possibleAnswers.add(new Answer(s, s)));
        Question question1 = new Question(QUESTION1_ID, QUESTION1_VALUE,
                possibleAnswers, Question.type.radio, true);

        super.questions.add(question0);
        super.questions.add(question1);

        Content content1 = new Content(CONTENT1,
                this.getResource().getPath().toString(), Content.type.img);
        super.contents.add(content1);

    }

    @Override
    public TaskAnswer genTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        return TaskAnswer.genGenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, answerParameterMap);
    }

    @Override
    public Map<String, String> checkAnswer(
            Map<String, String[]> answerParameterMap) {
        return super.checkFirstNullThenAll(answerParameterMap);
    }

}
