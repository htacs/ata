package ata.task.tasks.comparator;

import java.util.Comparator;

import ata.task.tasks.Task;

/**
 * compares tasks using their duration
 *
 */
public class TaskDurationComparator implements Comparator<Task> {

	private static TaskDurationComparator instance = null;

	private TaskDurationComparator() {

	}

	public static TaskDurationComparator getInstance() {
		if (instance == null) {
			instance=new TaskDurationComparator();
		}
		return instance;
	}

	@Override
	public int compare(Task o1, Task o2) {
		int comp = Integer.compare(o1.getJob().getDuration(), o2.getJob().getDuration());
		if (comp == 0) {
			return Integer.compare(o1.getId(), o2.getId());
		}
		return comp;
	}

}
