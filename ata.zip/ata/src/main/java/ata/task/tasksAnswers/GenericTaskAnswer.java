package ata.task.tasksAnswers;

import org.joda.time.DateTime;

import com.eclipsesource.json.JsonObject;

import ata.assignments.Assignment;

/**
 * encapsulates any kind of answer
 *
 */
public class GenericTaskAnswer extends TaskAnswer {

	public GenericTaskAnswer(Assignment assignment, DateTime firstPresentedDate, DateTime completionDate,
			JsonObject answerContent) {
		super(assignment, firstPresentedDate, completionDate, answerContent);
	}
}
