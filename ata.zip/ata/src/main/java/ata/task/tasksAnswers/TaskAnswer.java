package ata.task.tasksAnswers;

import java.util.HashMap;
import java.util.Map;

import org.joda.time.DateTime;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonObject;

import ata.assignments.Assignment;

/**
 * answer given by a worker on a task
 *
 */
public abstract class TaskAnswer {
    /**
     * corresponding assignment. can be set only once.
     */
    private Assignment assignment;

    private final DateTime firstPresentedDate;

    /**
     * date of answer. Immutable so we can return the reference.
     */
    private final DateTime completionDate;

    /**
     * the content in json style (easier to maintain for the db)
     */
    private final JsonObject answerContent;

    public TaskAnswer(Assignment assignment, DateTime firstPresentedDate,
            DateTime completionDate, JsonObject answerContent) {
        this.assignment = assignment;
        this.firstPresentedDate = firstPresentedDate;
        this.completionDate = completionDate;
        this.answerContent = answerContent;
    }

    public Assignment getAssignment() {
        return assignment;
    }

    public DateTime getCompletionDate() {
        return completionDate;
    }

//    public void setAssignment(Assignment assignment) {
//        if (assignment != null) {
//            throw new IllegalStateException(
//                    "assignment already set for this answer");
//        }
//        this.assignment = assignment;
//    }

    public JsonObject getAnswerContent() {
        return JsonObject.unmodifiableObject(answerContent);
    }

    // public void setAnswerContent(JsonObject answerContent) {
    // this.answerContent = answerContent;
    // }

    public DateTime getFirstPresentedDate() {
        return firstPresentedDate;
    }

    @Override
    public String toString() {
        return "task answer:[" + answerContent + "]";
    }

    /**
     * generate a generic task answer<br/>
     * uses only the FIRST index of each value in the map
     * 
     * @param assignment
     * @param firstPresentedDate
     * @param completionDate
     * @param answerParameterMap
     * @param expectedNumberOfQuestions
     * @return
     */
    public static TaskAnswer genGenericTaskAnswer(Assignment assignment,
            DateTime firstPresentedDate, DateTime completionDate,
            Map<String, String[]> answerParameterMap) {
        Map<String, String> answerMap = new HashMap<>();
        for (String s : answerParameterMap.keySet()) {
            StringBuilder sb = new StringBuilder("(");
            for (String ans : answerParameterMap.get(s)) {
                sb.append(ans);
                sb.append(",");
            }
            sb.append(")");
            // String answer = answerParameterMap.get(s)[0];
            answerMap.put(s, sb.toString());
        }
        JsonObject jsonAnswer = TaskAnswer.buildJsonFromAnswerMap(answerMap);
        return new GenericTaskAnswer(assignment, firstPresentedDate,
                completionDate, jsonAnswer);
    }

    /**
     * builds a json object from an answer map<br/>
     * the answer map must have the form question:answer
     * 
     * @param answerMap
     * @return
     */
    public static JsonObject buildJsonFromAnswerMap(
            Map<String, String> answerMap) {
        StringBuilder jsonAsString = new StringBuilder();
        jsonAsString.append("{");
        for (String key : answerMap.keySet()) {
            jsonAsString.append("\"" + key + "\":");
            jsonAsString.append("\"" + answerMap.get(key) + "\"");
            jsonAsString.append(",");
        }
        jsonAsString.deleteCharAt(jsonAsString.length() - 1);
        jsonAsString.append("}");
        return Json.parse(jsonAsString.toString()).asObject();
    }

}
