package ata.task;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ListMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.SetMultimap;

import ata.misc.CompOps;
import ata.misc.RandomGeneratorCustom;
import ata.motivation.CalcCoverage;
import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;
import gnu.trove.set.hash.THashSet;

/**
 * all tools to compute things on sets of tasks or jobs
 *
 */
public final class TasksJobsTools {

    private static Logger LOGGER = LoggerFactory
            .getLogger(TasksJobsTools.class);

    private final static double ONE = 1.0;

    /**
     * get all keywords from a list of jobs
     * 
     * @param jobs
     * @return
     */
    public static Set<String> getAllKeywordsFromJobs(Collection<Job> jobs) {
        return getAllKeywordsFromJobs(jobs, ONE);
    }

    /**
     * get a sample of keywords in the specified jobs
     * 
     * @param jobs
     * @param percentSampling
     *            % of keywords to sample (in [0,1@])
     * @return
     */
    public static Set<String> getAllKeywordsFromJobs(Collection<Job> jobs,
            double percentSampling) {
        if (percentSampling > 1 || percentSampling < 0) {
            throw new IllegalArgumentException(
                    "percentSampling must be in [0,1]");
        }
        RandomGeneratorCustom.getInstance().reseedRandom();
        /* remove duplicates */
        Set<String> keywordsSet = new THashSet<String>();
        jobs.forEach(j -> keywordsSet.addAll(j.getKeywords()));
        if (Double.valueOf(percentSampling).equals(ONE)) {
            return keywordsSet;
        }
        return getSubsetOfKeywords(keywordsSet, percentSampling);

    }

    /**
     * 
     * @param keywordsSet
     * @param percentKeywords
     *            must be in [0,1]
     * @throws IllegalArgumentException
     *             if percentKeywords is not in [0,1]
     * @return returns a subset of keywordsSet of size
     *         (percentKeywords*keywordsSet.size())
     */
    public static Set<String> getSubsetOfKeywords(Set<String> keywordsSet,
            double percentKeywords) {
        if (CompOps.g(percentKeywords, ONE)
                || CompOps.l(percentKeywords, 0.0)) {
            throw new IllegalArgumentException(
                    "percent of keywords should be in [0,1]");
        }
        if (Double.valueOf(percentKeywords).equals(ONE)) {
            return keywordsSet;
        }
        List<String> keywordsList = new ArrayList<>(keywordsSet);
        int nbAvailableKeywords = keywordsList.size();
        Set<String> out = new HashSet<>();
        int toPick = (int) Math.floor(percentKeywords * nbAvailableKeywords);
        int picked = 0;
        Random r = RandomGeneratorCustom.getInstance().getReseededRandom();
        while (picked < toPick) {
            int index = r.nextInt(keywordsList.size());
            out.add(keywordsList.get(index));
            keywordsList.remove(index);
            picked++;
        }
        return out;
    }

    public static SetMultimap<Job, Task> getRandomSubsetOfTasks(
            Set<Job> jobsToUse, SetMultimap<Job, Task> jobs, int nbTasks,
            int maxNbTasksPerJob) {
        // reseed random
        RandomGeneratorCustom.getInstance().reseedRandom();
        int realTasksSize = Math.min(jobs.size(), nbTasks);
        SetMultimap<Job, Task> out = MultimapBuilder.hashKeys()
                .hashSetValues(nbTasks).build();
        // copies to allow repeatability of sampling
        List<Job> jobsList = new ArrayList<>(jobs.keySet());
        ListMultimap<Job, Task> copy = MultimapBuilder.hashKeys()
                .arrayListValues().build(jobs);
        for (int i = 0; i < realTasksSize; i++) {
            boolean taskStored = false;
            while (!taskStored) {
                // pick a job
                int jobIdx = RandomGeneratorCustom.getInstance()
                        .getReseededRandom().nextInt(jobsList.size());
                Job currentJob = jobsList.get(jobIdx);
                if (out.get(currentJob).size() < maxNbTasksPerJob) {
                    int taskIdx = RandomGeneratorCustom.getInstance()
                            .getReseededRandom()
                            .nextInt(copy.get(currentJob).size());
                    taskStored = out.put(currentJob,
                            copy.get(currentJob).get(taskIdx));
                }
            }
        }
        LOGGER.info("Sampling tasks: returning {} tasks over {} given",
                out.size(), jobs.size());
        return out;
    }

    /**
     * returns a set of jobs which has the desired size NOT EFFICIENT, use with
     * precautions
     * 
     * @param jobs
     * @param nbJobs
     * @return
     */
    public static Set<Job> getRandomSubsetOfJobs(Set<Job> jobs, int nbJobs,
            boolean useReseeded) {
        Random r = null;
        if (useReseeded) {
            // reseed random
            RandomGeneratorCustom.getInstance().reseedRandom();
            r = RandomGeneratorCustom.getInstance().getReseededRandom();
        } else {
            r = RandomGeneratorCustom.getInstance().getRandom();
        }
        // real size
        int realJobsSize = Math.min(jobs.size(), nbJobs);

        Set<Job> out = new HashSet<>(nbJobs);

        // below: we copy the input, this is not efficient, but the only way to
        // have a repeatable
        // randomization
        List<Job> jobsList = new ArrayList<>(jobs);

        for (int i = 0; i < realJobsSize; i++) {
            boolean jobStored = false;
            while (!jobStored) {
                // pick a job
                int jobIdx = r.nextInt(jobsList.size());
                Job currentJob = jobsList.get(jobIdx);
                jobStored = out.add(currentJob);
                if (jobStored) {
                    jobsList.remove(jobIdx);
                }
            }
        }
        LOGGER.info("Sampling jobs: returning {} jobs over {} given",
                out.size(), jobs.size());
        return out;
    }

    /**
     * returns for each job all the workers that match
     * 
     * @param jobs
     * @param workers
     * @param threshold
     * @return
     */
    public static Map<Job, Collection<Worker>> getAllMatchingsJobsWorkersFromJobs(
            Collection<Job> jobs, Collection<Worker> workers,
            double threshold) {
        Map<Job, Collection<Worker>> out = new HashMap<>();
        for (Job job : jobs) {
            Collection<Worker> matchingWorkers = new HashSet<>();
            for (Worker worker : workers) {
                if (CalcCoverage.matches(worker, job, threshold)) {
                    matchingWorkers.add(worker);
                }
            }
            out.put(job, matchingWorkers);
        }
        return out;
    }

    /**
     * returns for each task all the workers that match</br>
     * if no worker match, empty list
     * 
     * @param workers
     * @param tasks
     * @param threshold
     * @return
     */
    public static Map<Task, List<Worker>> getAllMatchingsTasksWorkers(
            Collection<Worker> workers, Collection<Task> tasks,
            double threshold) {
        Map<Task, List<Worker>> out = new HashMap<>();
        for (Task task : tasks) {
            List<Worker> matchingWorkers = new ArrayList<>();
            for (Worker worker : workers) {
                if (CalcCoverage.matches(worker, task, threshold)) {
                    matchingWorkers.add(worker);
                }
            }
            out.put(task, matchingWorkers);
        }
        return out;
    }

    /**
     * returns all tasks that matches this worker
     * 
     * @param tasks
     * @param worker
     * @param threshold
     * @return
     */
    public static Multimap<Job, Task> getMatchingTasks(Multimap<Job, Task> jobs,
            Worker worker, double threshold) {
        Multimap<Job, Task> out = MultimapBuilder.hashKeys().hashSetValues()
                .build();
        for (Entry<Job, Task> jobTask : jobs.entries()) {
            if (CalcCoverage.matches(worker, jobTask.getValue(), threshold)) {
                out.put(jobTask.getKey(), jobTask.getValue());
            }
        }
        return out;
    }

    /**
     * returns a copy of a multimap
     * 
     * @param toCopy
     * @return
     */
    public static Multimap<Job, Task> getMultimapCopy(
            Multimap<Job, Task> toCopy) {
        return MultimapBuilder.hashKeys().hashSetValues().build(toCopy);
    }

    /**
     * returns a hashcode that does NOT depends on the iteration order of the
     * collection
     * 
     * @param jobs
     * @return
     */
    public static long genJobsHashCodeOrderIndependent(Collection<Job> jobs) {
        long hash = 7;
        for (Job j : jobs) {
            hash += j.hashCode();
        }
        return hash;
    }

    /**
     * returns a hashcode that DOES depends on the iteration order of the
     * collection
     * 
     * @param jobs
     * @return
     */
    public static long genJobsHashCodeOrderDependent(Collection<Job> jobs) {
        long hash = 7;
        long prime = 11;
        for (Job j : jobs) {
            hash = hash * prime + j.hashCode();
        }
        return hash;
    }

    /**
     * returns a hashcode that does NOT depends on the iteration order of the
     * collection
     * 
     * @param tasks
     * @return
     */
    public static long genTasksHashCodeOrderIndependent(
            Collection<Task> tasks) {
        long hash = 7;
        for (Task t : tasks) {
            hash += t.hashCode();
        }
        return hash;
    }

    /**
     * returns a hashcode that DOES depends on the iteration order of the
     * collection
     * 
     * @param jobs
     * @return
     */
    public static long genTasksHashCodeOrderDependent(Collection<Task> tasks) {
        long hash = 7;
        long prime = 11;
        for (Task t : tasks) {
            hash = hash * prime + t.hashCode();
        }
        return hash;
    }

}
