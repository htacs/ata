package ata.task.jobs;

import java.util.Set;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonObject;

import ata.task.resource.Resource;
import ata.task.tasks.BodyPartTask;
import ata.task.tasks.Task;


public class BodyPartJob extends Job {


	protected BodyPartJob(int id, String name, String description, Set<String> keywords, int duration, int payment) {
		super(id, name, description, keywords, duration, payment);
	}

	@Override
	public Task buildTask(int id, String jsonAsString, String resURL, String resPath) {
		Resource resource = null;

		JsonObject items = Json.parse(jsonAsString).asObject();

		String firstPart = items.get("part_1").toString();

		String secondPart = items.get("part_2").toString();

		return new BodyPartTask(id, resource, this, firstPart, secondPart);
	}

}
