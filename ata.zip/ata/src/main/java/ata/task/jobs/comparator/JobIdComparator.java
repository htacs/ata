package ata.task.jobs.comparator;

import java.util.Comparator;

import ata.task.jobs.Job;

/**
 * put job in the order of their ids
 *
 */
public class JobIdComparator implements Comparator<Job> {

    private static JobIdComparator instance = null;

    public static JobIdComparator getInstance() {
        if (instance == null) {
            instance = new JobIdComparator();
        }
        return instance;
    }

    @Override
    public int compare(Job o1, Job o2) {
        int res = Integer.compare(o1.getId(), o2.getId());

        if (res == 0) {
            res = o1.getName().compareTo(o2.getName());
            if (res == 0) {
                res = o1.getDescription().compareTo(o2.getDescription());
                if (res == 0) {
                    res = Long.compare(o1.getPayment(), o2.getPayment());
                    if (res == 0) {
                        if (o1.getKeywords().equals(o2.getKeywords())) {
                            return 0;
                        }
                        return -1;
                    }
                }
            }

        }
        return res;
    }
}
