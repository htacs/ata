package ata.task.jobs;

import java.util.Set;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonObject;

import ata.task.resource.Resource;
import ata.task.tasks.ChemicalsTask;
import ata.task.tasks.Task;

public class ChemicalsJob extends Job {

	

	protected ChemicalsJob(int id, String name, String description, Set<String> keywords, int duration, int payment) {
		super(id, name, description, keywords, duration, payment);
	}

	@Override
	public Task buildTask(int id, String jsonAsString, String resURL, String resPath) {
		Resource resource = null;

		JsonObject items = Json.parse(jsonAsString).asObject();

		String chemical = items.get("chemical_name").toString();
		String disease = items.get("disease_name").toString();
		String sentence = items.get("form_sentence").toString();

		return new ChemicalsTask(id, resource, this, chemical, disease, sentence);
	}

}
