package ata.task.jobs;

import java.util.Set;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonObject;

import ata.task.resource.Resource;
import ata.task.tasks.EconomicNewsTask;
import ata.task.tasks.Task;

public class EconomicNewsJob extends Job {

    protected EconomicNewsJob(int id, String name, String description,
            Set<String> keywords, int duration, int payment) {
        super(id, name, description, keywords, duration, payment);
    }

    @Override
    public Task buildTask(int id, String jsonAsString, String resURL,
            String resPath) {
        Resource resource = null;

        JsonObject items = Json.parse(jsonAsString).asObject();

        String date = items.get("date").toString();
        String headline = items.get("headline").toString();
        String news = items.get("text").toString();

        return new EconomicNewsTask(id, resource, this, date, headline, news);
    }

}
