package ata.task.jobs;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableSet;

import ata.configuration.ConfigurationLoader;
import ata.configuration.JobConfig;
import ata.task.resource.GenericResource;
import ata.task.resource.Resource;
import ata.task.tasks.Task;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.set.hash.THashSet;

/**
 * a job contains a collection of tasks
*/
public abstract class Job {

    final static Logger LOGGER = LoggerFactory.getLogger(Job.class);

    /**
     * unique id given by the db
     */
    final int id;
    /**
     * name (short)
     */
    final String name;

    /**
     * description
     */
    final String description;
    /**
     * set of keywords
     */
    private final Set<String> keywords;
    /**
     * duration/allotted time in seconds
     */
    private final int duration;
    /**
     * payment in $ cents
     */
    private final int payment;
    // /**
    // * ALL tasks identified by their id
    // */
    // private transient ConcurrentMap<Integer, Task> tasks;

    /**
     * optional, used only for amt hitgroups
     */
    private String amtHitgroupId;

    protected Job(int id, String name, String description, Set<String> keywords,
            int duration, int payment) {
        super();
        this.name = name;
        this.description = description;
        this.id = id;
        this.keywords = new THashSet<>();
        keywords.forEach(k -> this.keywords.add(k));
        this.duration = duration;
        this.payment = payment;
        // this.tasks = new ConcurrentHashMap<Integer, Task>();
    }

    // /**
    // * inserts a task in the job
    // *
    // * @param task
    // * @return null if task was not in the job, the task with same id else
    // */
    // public Task addTask(Task task) {
    // return this.tasks.put(task.getId(), task);
    // }

    // /**
    // * adds a list of tasks to the job
    // *
    // * @param tasks
    // */
    // public void addTasks(List<Task> tasks) {
    // for (Task task : tasks) {
    // this.tasks.put(task.getId(), task);
    // }
    // }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    // public ConcurrentMap<Integer, Task> getTasks() {
    // return tasks;
    // }

    public Set<String> getKeywords() {
        return ImmutableSet.copyOf(keywords);
    }

    public boolean addKeyword(String keyword) {
        return this.keywords.add(keyword);
    }

    public int getDuration() {
        return duration;
    }

    public int getPayment() {
        return payment;
    }

    /**
     * "factory" method to instanciate a job
     * 
     * @param id
     * @param name
     * @param keywords
     * @param duration
     * @param payment
     * @return
     */
    public static Job buildJob(int id, String name, String description,
            Set<String> keywords, int duration, int payment) {
        // first get jobConfig

        TIntObjectMap<JobConfig> jobConfigs = null;
        try {
            jobConfigs = ConfigurationLoader.getJobConf();
        } catch (Exception e1) {
            LOGGER.error("error loading job conf", e1);
        }

        // current job
        JobConfig ja = null;
        if (jobConfigs.containsKey(id)) {
            ja = jobConfigs.get(id);
        } else {
            // by default we use the generic task if nothing is specified in the
            // config file
            ja = new JobConfig(true);
        }

        // then instantiate job

        // below: slow, uses reflections
        // get class to instantiate
        Class<? extends Object> jobClass = ja.getJobClass();

        Constructor<?> constructor = null;
        try {
            constructor = jobClass.getDeclaredConstructor(int.class,
                    String.class, String.class, Set.class, int.class,
                    int.class);

        } catch (NoSuchMethodException | SecurityException e) {
            LOGGER.error("error with job constructor", e);
        }
        Job jobInstance = null;
        try {
            jobInstance = (Job) constructor.newInstance(id, name, description,
                    keywords, duration, payment);
        } catch (InstantiationException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e) {
            LOGGER.error("error with job instantiation", e);
        }

        return jobInstance;
    }

    // removed keywords from hash/equals, too expensive
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((amtHitgroupId == null) ? 0 : amtHitgroupId.hashCode());
        result = prime * result
                + ((description == null) ? 0 : description.hashCode());
        result = prime * result + id;
        // result = prime * result + ((keywords == null) ? 0 :
        // keywords.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + payment;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Job other = (Job) obj;
        if (amtHitgroupId == null) {
            if (other.amtHitgroupId != null)
                return false;
        } else if (!amtHitgroupId.equals(other.amtHitgroupId))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (id != other.id)
            return false;
        // not used : slow
        // if (keywords == null) {
        // if (other.keywords != null)
        // return false;
        // } else if (!keywords.equals(other.keywords))
        // return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (payment != other.payment)
            return false;
        return true;
    }

    /**
     * "factory" method to copy a job</br>
     * TASKS ARE NOT COPIED
     * 
     * @param id
     * @param name
     * @param keywords
     * @param duration
     * @param payment
     * @return
     */
    public static Job buildJob(Job job) {
        Job out = buildJob(job.id, job.name, job.description, job.keywords,
                job.duration, job.payment);
        out.setAmtHitgroupId(job.amtHitgroupId);
        return out;
    }

    /**
     * the method to build tasks from the job instance
     * 
     * @param id
     * @param json
     * @param resPath
     * @param resUrl
     * @return
     */
    public abstract Task buildTask(int id, String jsonAsString, String resURL,
            String resPath);

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("{");
        sb.append(this.getClass().getSimpleName());
        sb.append(",id:" + this.id);
        sb.append(",name:" + this.name);
        sb.append(",dur:" + new Integer(this.duration));
        sb.append(",pay:" + new Integer(this.payment));
        sb.append("[");
        for (String kw : keywords) {
            sb.append(kw + ",");
        }
        sb.append("]");
        sb.append("}");
        return sb.toString();
    }

    // public int size() {
    // return tasks.size();
    // }

    public String getDescription() {
        return description;
    }

    // /**
    // * returns a random task. Expensive, but order can be guaranteed.
    // *
    // * @param random
    // * @return
    // */
    // public Task getRandomTask(Random random) {
    // int index =
    // RandomGenerator.getInstance().getRandom().nextInt(this.getTasks().size());
    // int i = 0;
    // for (Task t : this.getTasks().values()) {
    // if (i == index) {
    // return t;
    // }
    // i++;
    // }
    // return null;
    // }

    // /**
    // * returns the task whose id appears the first in the keys. order not
    // * guaranteed, but it is faster than {@link #getRandomTask(Random)}.
    // *
    // * @return
    // */
    // public Task getFirstTask() {
    // if (this.size() > 0) {
    // return tasks.get(tasks.keySet().iterator().next());
    // }
    // return null;
    // }

    // /**
    // * removes the first task in the key set (order not guaranteed)
    // *
    // * @return
    // */
    // public void removeFirstTask() {
    // int toRemove = 0;
    // for (int i : tasks.keySet()) {
    // toRemove = i;
    // break;
    // }
    // tasks.remove(toRemove);
    // }

    public static Resource buildResource(String resURL, String resPath) {

        URL resURLObj = null;
        try {
            resURLObj = new URL(resURL);
        } catch (MalformedURLException e) {
            Job.LOGGER.warn("malformed URL!", e);
        }

        return new GenericResource(resURLObj, resPath);
    }

    public String getAmtHitgroupId() {
        return amtHitgroupId;
    }

    public void setAmtHitgroupId(String amtHitgroupId) {
        this.amtHitgroupId = amtHitgroupId;
    }

    // /**
    // * remove all tasks from this job
    // *
    // * @return
    // */
    // public int clearTasks() {
    // int nbBefore = tasks.size();
    // this.tasks.clear();
    // return nbBefore;
    // }

    // /**
    // * removes a task
    // *
    // * @param toRemove
    // * @return
    // */
    // public Task remove(Task toRemove) {
    // return tasks.remove(toRemove.getId());
    // }

}
