package ata.task.jobs;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import ata.task.resource.GenericResource;
import ata.task.resource.Resource;
import ata.task.tasks.GenericTask;
import ata.task.tasks.Task;

/**
 * a general-purpose class for any kind of job
*/
public class GenericJob extends Job {


	protected GenericJob(int id, String name,String description, Set<String> keywords, int duration, int payment) {
		super(id, name, description, keywords, duration, payment);
	}

	@Override
	public Task buildTask(int id, String jsonAsString, String resURL, String resPath) {
		URL resURLObj = null;
		if (resURL.length() > 0) {
			try {
				resURLObj = new URL(resURL);
			} catch (MalformedURLException e) {
				Job.LOGGER.warn("malformed URL! " ,e);
			}
		}
		

//		JsonObject items = Json.parse(jsonAsString).asObject();

		
		// ObjectMapper mapper = new ObjectMapper(); // create once, reuse
		// Map<String, String> items = null;
		// try {
		// items = mapper.readValue(jsonAsString, Map.class);
		// } catch (IOException e) {
		// // Auto-generated catch block
		// e.printStackTrace();
		// }
		//
		// if (items.containsKey("_golden")) {
		// golden = Boolean.valueOf(items.get("_golden").toString());
		// }

		// the gson version below
		// //
		// http://stackoverflow.com/questions/2591098/how-to-parse-json-in-java
		// JsonObjectt items = new
		// JsonParser().parse(jsonAsString).getAsJsonObject();
		// if (items.get("_golden") != null) {
		// golden = items.get("_golden").getAsBoolean();
		// }

		Resource resource = new GenericResource(resURLObj, resPath);

		
		return new GenericTask(id, resource, null, this);
	}

}
