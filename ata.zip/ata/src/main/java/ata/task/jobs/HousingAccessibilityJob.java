package ata.task.jobs;

import java.util.Set;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonObject;

import ata.task.resource.Resource;
import ata.task.tasks.HousingAccessibilityTask;
import ata.task.tasks.Task;

public class HousingAccessibilityJob extends Job {



	protected HousingAccessibilityJob(int id, String name, String description, Set<String> keywords, int duration,
			int payment) {
		super(id, name, description, keywords, duration, payment);
	}

	@Override
	public Task buildTask(int id, String jsonAsString, String resURL, String resPath) {
		Resource resource = null;

		JsonObject items = Json.parse(jsonAsString).asObject();

		String url = items.get("url").toString();

		return new HousingAccessibilityTask(id, resource, this, url);
	}

}
