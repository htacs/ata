package ata.task.jobs;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import ata.task.resource.ImageResource;
import ata.task.resource.Resource;
import ata.task.tasks.PeopleAndFoodTask;
import ata.task.tasks.Task;


public class PeopleAndFoodJob extends Job {



	protected PeopleAndFoodJob(int id, String name, String description, Set<String> keywords, int duration,
			int payment) {
		super(id, name, description, keywords, duration, payment);
	}

	@Override
	public Task buildTask(int id, String jsonAsString, String resURL, String resPath) {

		URL url = null;
		try {
			url = new URL(resURL);
		} catch (MalformedURLException e) {
			LOGGER.warn("malformed url",e);
		}

		Resource resource = new ImageResource(url, resPath);

		return new PeopleAndFoodTask(id, resource, this);
	}

}
