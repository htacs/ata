package ata.motivation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ArrayTable;
import com.google.common.collect.Table;

import ata.assignments.Assignment;
import ata.misc.MultithreadTool;
import ata.task.jobs.Job;
import ata.task.jobs.comparator.JobIdComparator;
import ata.task.tasks.Task;

public class CalcSkillVariety {
    private static Logger LOGGER = LoggerFactory
            .getLogger(CalcSkillVariety.class);

    private static CalcSkillVariety instance;

    /**
     * all jobs' pairwise distances
     */
    private static Table<Job, Job, Double> distancesTable;

    /**
     * defeat instanciation
     */
    private CalcSkillVariety() {
    }

    /**
     * entry point to compute skill variety</br>
     * all distances between jobs are computed
     * 
     * @param jobs
     * @return
     */
    public static CalcSkillVariety getInstance(Collection<Job> jobs) {
        if (instance == null) {
            instance = new CalcSkillVariety();
            /* initialize the distances */
            distancesTable = computeDistanceTable(jobs);
            // writeAllDistances(jobDistancesMap);
            int count = 0;
            for (Double d : distancesTable.values()) {
                if (d != null) {
                    count++;
                }
            }
            LOGGER.info("CalcSkillVariety was instanciated with " + count
                    + " distances loaded");
        }
        return instance;
    }

    /**
     * entry point to compute skill variety</br>
     * we load distances from disk
     * 
     * @return
     * @throws IllegalStateException
     *             if not loaded before
     */
    public static CalcSkillVariety getInstance() {
        if (instance == null) {
            throw new IllegalStateException(
                    "calc skill variery was not loaded before!");
        }
        return instance;

    }

    public void resetInstance() {
        CalcSkillVariety.instance = null;
        CalcSkillVariety.distancesTable = null;
    }

    /**
     * computes all job pairwise distances</br>
     * 
     * @param jobs
     */
    private static Table<Job, Job, Double> computeDistanceTable(
            Collection<Job> jobs) {
        LOGGER.info("computing distances between jobs");
        List<Job> jobsList = new ArrayList<>(jobs);
        int nbJobs = jobs.size();
        int cpus = Runtime.getRuntime().availableProcessors();
        Map<String, int[]> partitions = MultithreadTool
                .getIndexForMultithread(cpus, nbJobs);

        Table<Job, Job, Double> distanceMap = ArrayTable.create(jobsList,
                jobsList);

        IntStream is = IntStream.range(0, cpus).parallel();
        // run everything in parallel
        is.forEach(new IntConsumer() {
            @Override
            public void accept(int core) {
                int nbDistances = computeDistances(jobsList,
                        partitions.get("min")[core],
                        partitions.get("max")[core], distanceMap);
                LOGGER.debug("cpu {}  has finished ({} distances computed)",
                        core, String.format("%,d", nbDistances));
            }
        });

        return distanceMap;

    }

    private static int computeDistances(List<Job> jobs, int minIndexFirstJob,
            int maxIndexFirstJob, Table<Job, Job, Double> distanceMap) {
        int out = 0;
        for (int i = minIndexFirstJob; i <= maxIndexFirstJob; i++) {
            Job j1 = jobs.get(i);
            for (int j = i; j < jobs.size(); j++) {
                Job j2 = jobs.get(j);
                double distance = instance.computeSkillVariety(j1, j2);
                Job[] pair = arrangeJobPair(new Job[] { j1, j2 });
                distanceMap.put(pair[0], pair[1], distance);
                out++;
            }

        }
        return out;
    }

    /**
     * sort a pair of jobs in arbitrary, deterministic order
     * 
     * @param pair
     * @return
     */
    private static Job[] arrangeJobPair(Job[] pair) {
        assert pair.length == 2;
        Arrays.sort(pair, JobIdComparator.getInstance());
        return pair;
    }

    /**
     * returns the distance between a pair of jobs
     * 
     * @param j1
     * @param j2
     * @return
     */
    public double getDistance(Job j1, Job j2) {
        Job[] pair = arrangeJobPair(new Job[] { j1, j2 });
        return distancesTable.get(pair[0], pair[1]);
    }

    // ------------------- TASK-BASED ------------

    /**
     * get skill variety using the job distance map
     * 
     * @param tasks
     *            the set of tasks on which we want to compute skill variety
     * @return
     */
    public double getSkillVariety(Collection<Task> tasks) {
        double out = 0;
        List<Task> taskList = new ArrayList<>(tasks);

        for (int i = 0; i < taskList.size() - 1; i++) {
            for (int j = i; j < taskList.size(); j++) {
                Job j1 = taskList.get(i).getJob();
                Job j2 = taskList.get(j).getJob();
                out += getDistance(j1, j2);
            }
        }
        return out;
    }

    public double getSkillVariety(Task t1, Task t2) {
        return getDistance(t1.getJob(), t2.getJob());
    }

    /**
     * the amount of skill variety added if we add this task to the current set
     * 
     * @param pickedAssignment
     * @param assignmentsAlreadyIn
     * @return
     */
    public double getAddedSkillVarietyAssignments(Assignment pickedAssignment,
            Set<Assignment> assignmentsAlreadyIn) {
        double res = 0;
        for (Assignment a : assignmentsAlreadyIn) {
            res += getSkillVariety(pickedAssignment.getTask(), a.getTask());
        }
        return res;
    }

    // ------------------- JOB-BASED ------------

    /**
     * computes distance between two jobs
     * 
     * @param j1
     * @param j2
     * 
     * @return
     */
    private double computeSkillVariety(Job j1, Job j2) {

        return jaccardDistance(j1, j2);
    }

    /**
     * uses the distance stored in the map if present
     * 
     * @param j1
     * @param j2
     * @return
     */
    public double getSkillVariety(Job j1, Job j2) {
        return getDistance(j1, j2);
    }

    /**
     * jaccard distance
     * 
     * @param t1
     * @param t2
     * @return
     */
    private double jaccardDistance(Job j1, Job j2) {
        // SLOW!
        // Set<String> intersection = new THashSet<String>(j1.getKeywords());
        // intersection.retainAll(j2.getKeywords());
        //
        // Set<String> union = new THashSet<String>(j1.getKeywords());
        // union.addAll(j2.getKeywords());
        //
        // if (union.size() == 0) {
        // LOGGER.error(String.format("no keywords for jobs %s and %s, returning
        // 1 for distance", j1, j2));
        // return 1;
        // }
        // return 1 - ((double) intersection.size() / union.size());
        // FAST!
        int inter = 0;
        for (String s : j1.getKeywords()) {
            if (j2.getKeywords().contains(s)) {
                inter++;
            }
        }
        int union = j1.getKeywords().size() + j2.getKeywords().size() - inter;
        return 1 - ((double) inter / union);
    }

    public double getMaxPairwiseSkillVarietyFromJobs(Collection<Job> jobs) {
        double res = 0;
        List<Job> jobList = new ArrayList<>(jobs);
        for (int i = 0; i < jobs.size(); i++) {
            for (int j = i + 1; j < jobs.size() - 1; j++) {
                double current = getSkillVariety(jobList.get(i),
                        jobList.get(j));
                res = Math.max(res, current);
            }
        }
        return res;
    }
    
  

    

}
