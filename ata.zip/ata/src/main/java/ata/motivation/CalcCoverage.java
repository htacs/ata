package ata.motivation;

import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

public class CalcCoverage {

    /**
     * true if workers' skills/keywords match task's keywords
     * 
     * @param t
     * @param threshold
     *            in [0,1]
     * @return
     */
    public static boolean matches(Worker w, Task t, double threshold) {
        return (getCoverage(w, t.getJob()) >= threshold);

    }

    /**
     * true if workers' skills/keywords match task's keywords
     * 
     * @param t
     * @param threshold
     *            in [0,1]
     * @return
     */
    public static boolean matches(Worker w, Job j, double threshold) {
        return (getCoverage(w, j) >= threshold);
    }

    /**
     * expected quality of worker w on job j</br>
     * computed using coverage of j's keywords by the worker
     * 
     * @param t
     * @return
     */
    private static double getCoverage(Worker w, Job j) {
        int keywordsMatched = 0;
        for (String keyword : j.getKeywords()) {
            if (w.getKeywords().contains(keyword)) {
                keywordsMatched++;
            }
        }

        return (double) keywordsMatched / j.getKeywords().size();
    }
}
