package ata.motivation;

import java.util.Collection;

import ata.task.jobs.Job;
import ata.task.tasks.Task;
import ata.worker.Worker;

public class CalcRelevance {

    private static CalcRelevance instance = null;

   
    private CalcRelevance() {

    }

    /**
     * entry point to compute relevance
     * 
     * @param jobs
     * @return
     */
    public static CalcRelevance getInstance() {
        if (instance == null) {
            instance = new CalcRelevance();
        }
        return instance;
    }

    public static void resetInstance() {
        CalcRelevance.instance = null;
    }

    // ------------------- TASK-BASED ------------

    /**
     * load skill variety using the job distance map
     * 
     * @param tasks
     *            the set of tasks on which we want to compute skill variety
     * @param worker
     * @return
     */
    public double computeRelevance(Collection<Task> tasks, Worker worker) {
        double out = 0;
        for (Task t : tasks) {
            out += computeRelevance(t, worker);
        }
        return out;
    }

    /**
     * computes relevance of a task wrt a worker
     * 
     * @param t
     *            task
     * @param w
     *            worker
     * @return
     */
    public double computeRelevance(Task t, Worker w) {
        return computeRelevance(t.getJob(), w);
    }

    // ------------------- JOB-BASED ------------

    /**
     * computes relevance using a job
     * 
     * @param j
     *            job
     * @param w
     *            worker
     * 
     * @return
     */
    public double computeRelevance(Job j, Worker w) {
        return 1 - jaccardDistance(j, w);

    }

    public double getMaxPossibleRelevance() {
        return 1.0;
    }

    /**
     * jaccard distance
     * 
     * @param j
     *            job
     * @param w
     *            worker
     * @return
     */
    private double jaccardDistance(Job j, Worker w) {
        int inter = 0;
        for (String s : j.getKeywords()) {
            if (w.getKeywords().contains(s)) {
                inter++;
            }
        }
        int union = j.getKeywords().size() + w.getKeywords().size() - inter;
        return 1.0 - ((double) inter / union);

    }

}
