package ata.motivation;

import java.util.Collection;

import ata.task.jobs.Job;
import ata.task.tasks.Task;

public class CalcPayment {

    private static CalcPayment instance = null;

    private static Long maxPayment = Long.MAX_VALUE;

    private CalcPayment() {

    }

    /**
     * loads instance using tasks
     * 
     * @param jobs
     * @return
     */
    public static CalcPayment getInstance(Collection<Job> jobs) {
        if (instance == null) {
            instance = new CalcPayment();
            CalcPayment.maxPayment = getMaxPaymentFromJobs(jobs);
        }

        return instance;
    }

    /**
     * 
     * @return
     * @throws IllegalStateException
     *             if not loaded before
     */
    public static CalcPayment getInstance() {
        if (instance != null) {
            return instance;
        }
        throw new IllegalStateException("calc payment not loaded before");
    }

    /**
     * resets instance
     */
    public static void resetInstance() {
        CalcPayment.instance = null;
        CalcPayment.maxPayment = null;
    }

    public static long getMaxPayment() {
        return maxPayment;
    }

    /**
     * computes the total sum of payments
     * 
     * @param jobs
     * @return
     */
    private static long getMaxPaymentFromJobs(Collection<Job> jobs) {
        return jobs.stream().map(j -> j.getPayment())
                .max((p1, p2) -> Integer.compare(p1, p2)).get();
    }

    /**
     * the motivation factor in the motivation function
     * 
     * @param tasks
     * @param totalPayments
     * @return
     */
    public double getTPFactor(Collection<Task> tasks) {
        return (double) tasks.stream().map(t -> t.getJob().getPayment())
                .reduce(0, (a, b) -> a + b) / maxPayment;
    }

    /**
     * TP for a single task
     * 
     * @param task
     * @return
     */
    public double getTPFactor(Task task) {
        return getTPFactor(task.getJob());
    }

    /**
     * the TP factor for ANY task from a job
     * 
     * @param job
     * @return
     */
    public double getTPFactor(Job job) {
        return (double) job.getPayment() / maxPayment;
    }

}
