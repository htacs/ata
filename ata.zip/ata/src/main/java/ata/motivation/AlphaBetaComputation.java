package ata.motivation;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

import com.google.common.collect.ImmutableSet;

import ata.assignments.Assignment;
import ata.assignments.comparator.AssignmentCompletionDateComparator;
import ata.misc.CompOps;
import ata.worker.Worker;
import gnu.trove.list.TDoubleList;
import gnu.trove.list.array.TDoubleArrayList;

public class AlphaBetaComputation {

    private enum AlphaBeta {
        ALPHA, BETA
    };

    /**
     * computes the alpha
     * 
     * @param assignmentsOfWorker
     * @return
     * @throws IllegalArgumentException
     *             if less than 2 assignments are completed
     */
    public static double computeAlpha(Collection<Assignment> assignments) {
        Set<Assignment> completedSortedAssignments = getAssignmentsSortedByCompletionDate(
                assignments);
        Set<Assignment> allAssignments = new LinkedHashSet<>(assignments);

        if (completedSortedAssignments.size() < 2) {
            throw new IllegalArgumentException(
                    "should compute alpha only if at least 2 completed assignments");
        }

        if (AlphaBetaComputation.class.desiredAssertionStatus()) {
            // check that all assignments are for the same worker
            Worker w = assignments.iterator().next().getWorker();
            for (Assignment a : assignments) {
                assert a.getWorker().equals(w);
            }
        }
        return computeAlphaOrBeta(completedSortedAssignments, allAssignments,
                AlphaBeta.ALPHA);
    }

    /**
     * computes the beta
     * 
     * @param assignmentsOfWorker
     * @return
     * @throws IllegalArgumentException
     *             if less than 2 assignments are completed
     */
    public static double computeBeta(Collection<Assignment> assignments) {
        Set<Assignment> completedSortedAssignments = getAssignmentsSortedByCompletionDate(
                assignments);
        Set<Assignment> allAssignments = new LinkedHashSet<>(assignments);

        if (completedSortedAssignments.size() < 2) {
            throw new IllegalArgumentException(
                    "should compute alpha only if at least 2 completed assignments");
        }
        if (AlphaBetaComputation.class.desiredAssertionStatus()) {
            // check that all assignments are for the same worker
            Worker w = assignments.iterator().next().getWorker();
            for (Assignment a : assignments) {
                assert a.getWorker().equals(w);
            }
        }
        return computeAlphaOrBeta(completedSortedAssignments, allAssignments,
                AlphaBeta.BETA);
    }

    /**
     * finds the task that best correspond to the worker's alpha
     * 
     * @param currentWorker
     * @param completedTasks
     * @param remainingTasks
     * @return
     */
    public static Assignment getPreferredAssignment(Worker currentWorker,
            Set<Assignment> completedAssignments,
            Set<Assignment> remainingAssignments) {
        // we try every task
        double bestDistance = Double.MAX_VALUE;
        Assignment bestAssignment = null;

        for (Assignment a : remainingAssignments) {
            double currentAlpha = AlphaBetaComputation.computeAlphaChoice(a,
                    remainingAssignments, completedAssignments);
            double currentBeta = AlphaBetaComputation.computeBetaChoice(a,
                    remainingAssignments, completedAssignments);

            // euclidean distance
            double sqAlpha = Math.pow(currentAlpha - a.getWorker().getAlpha(),
                    2);
            double sqBeta = Math.pow(currentBeta - a.getWorker().getBeta(), 2);
            double distance = Math.sqrt(sqAlpha + sqBeta);

            if (CompOps.l(distance, bestDistance)) {
                bestAssignment = a;
                bestDistance = distance;
            }
        }
        return bestAssignment;
    }

    /**
     * computes alpha or beta (same process)
     * 
     * @param assignmentsOfWorker
     * @param alphabeta
     * @return
     */
    private static double computeAlphaOrBeta(
            Set<Assignment> completedAssignmentsSorted,
            Set<Assignment> allAssignments, AlphaBeta alphabeta) {
        assert completedAssignmentsSorted.size() >= 2;

        Set<Assignment> completedAssignmentsSimulation = new LinkedHashSet<>();
        Set<Assignment> remainingAssignmentsSimulation = new LinkedHashSet<>(
                allAssignments);

        TDoubleList alphasOrBetas = new TDoubleArrayList();

        Iterator<Assignment> iterAssignments = completedAssignmentsSorted
                .iterator();
        boolean first = true;
        while (iterAssignments.hasNext()) {
            Assignment current = iterAssignments.next();
            if (!first && alphabeta.equals(AlphaBeta.ALPHA)) {
                alphasOrBetas.add(computeAlphaChoice(current,
                        remainingAssignmentsSimulation,
                        completedAssignmentsSimulation));
                first = false;
            } else if (alphabeta.equals(AlphaBeta.BETA)) {
                alphasOrBetas.add(computeBetaChoice(current,
                        remainingAssignmentsSimulation,
                        completedAssignmentsSimulation));
            }
            first = false;

            completedAssignmentsSimulation.add(current);
            remainingAssignmentsSimulation.remove(current);
            // System.out.println("added task" + current.getTask().getId());
            // System.out.println("completed:"
            // + getStringTasks(completedAssignmentsSimulation));
            // System.out.println("remaining:"
            // + getStringTasks(remainingAssignmentsSimulation));

        }
        return

        aggregateAlphasOrBetas(alphasOrBetas);
    }


    private static double aggregateAlphasOrBetas(TDoubleList alphas) {
        return (double) alphas.sum() / alphas.size();
    }

    /**
     * computes alpha_ij
     * 
     * @param pickedTask
     *            is picked in remaining tasks
     * @param remainingTasks
     *            contains pickedTask
     * @param completedTasks
     * @return
     */
    private static double computeAlphaChoice(Assignment pickedAssignment,
            Set<Assignment> remainingAssignments,
            Set<Assignment> completedAssignments) {
        assert completedAssignments.size() >= 1;

        switch (CalcMotivation.versionUsed) {
        default:
        case DIV_REL:
            return computeSkillVarietyRatio(pickedAssignment,
                    remainingAssignments, completedAssignments);
        }
    }

    /**
     * computes alpha_ij
     * 
     * @param pickedTask
     *            is picked in remaining tasks
     * @param remainingTasks
     *            contains pickedTask
     * @param completedTasks
     * @return
     */
    private static double computeBetaChoice(Assignment pickedAssignment,
            Set<Assignment> remainingAssignments,
            Set<Assignment> completedAssignments) {
        return computeRelevanceRatio(pickedAssignment, remainingAssignments,
                completedAssignments);
    }

    /**
     * captures the willingness to pick a task that highly increases skill
     * variety
     * 
     * @param pickedTask
     *            is still in remainingTasks
     * @param remainingTasks
     * @param completedTasks
     * @return
     */
    private static double computeSkillVarietyRatio(Assignment pickedAssignment,
            Set<Assignment> remainingAssignments,
            Set<Assignment> completedAssignments) {

        // compute numerator
        double addedVariety = CalcSkillVariety.getInstance()
                .getAddedSkillVarietyAssignments(pickedAssignment,
                        completedAssignments);
        // denominator
        double maxPossibleAddition = 0;

        for (Assignment a : remainingAssignments) {
            double currentAddedVariety = CalcSkillVariety.getInstance()
                    .getAddedSkillVarietyAssignments(a, completedAssignments);
            maxPossibleAddition = Math.max(maxPossibleAddition,
                    currentAddedVariety);
        }

        if (CompOps.eq(maxPossibleAddition, 0)) {
            //previously 0
            return 1.0;
        }

        return (double) addedVariety / maxPossibleAddition;
    }

    /**
     * captures the willingness to pick a task that highly increases task
     * relevance
     * 
     * @param pickedTask
     *            is still in remainingTasks
     * @param remainingTasks
     * @param completedTasks
     * @return
     */
    private static double computeRelevanceRatio(Assignment pickedAssignment,
            Set<Assignment> remainingAssignments,
            Set<Assignment> completedAssignments) {
        // compute numerator
        double addedRelevance = CalcRelevance.getInstance().computeRelevance(
                pickedAssignment.getTask(), pickedAssignment.getWorker());

        // denominator
        double maxPossibleAddition = 0;
        for (Assignment a : remainingAssignments) {
            double currentAddedRelevance = CalcRelevance.getInstance()
                    .computeRelevance(a.getTask(), a.getWorker());
            maxPossibleAddition = Math.max(maxPossibleAddition,
                    currentAddedRelevance);
        }

        if (CompOps.eq(maxPossibleAddition, 0.0)) {
            //previously 0
            return 1.0;
        }

        return (double) addedRelevance / maxPossibleAddition;
    }

    /**
     * 
     * @param assignments
     * @return assignments as a set in ascending order of completion date
     */
    public static Set<Assignment> getAssignmentsSortedByCompletionDate(
            Collection<Assignment> assignments) {
        Set<Assignment> out = new TreeSet<>(
                AssignmentCompletionDateComparator.getInstance());
        for (Assignment a : assignments) {
            if (a.getTaskAnswer() != null) {
                out.add(a);
            }
        }
        return ImmutableSet.copyOf(out);

    }

}
