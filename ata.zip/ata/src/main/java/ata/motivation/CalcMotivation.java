package ata.motivation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.google.common.collect.Multimap;

import ata.assigner.Assigner;
import ata.assignments.Assignment;
import ata.task.tasks.Task;
import ata.worker.Worker;

public class CalcMotivation {

    public static enum version {
        DIV_REL
    };

    /**
     * CURRENTLY HARDCODED : DIV REL
     */
    public static CalcMotivation.version versionUsed = CalcMotivation.version.DIV_REL;

    // private static Logger LOGGER = LoggerFactory
    // .getLogger(CalcMotivation.class);

    /**
     * embeds methods and distance tables to compute skill variety factor
     */
    private CalcSkillVariety csv;

    /**
     * embeds methods and total payment to compute task payment factor
     */
    private CalcPayment cp;

    private CalcRelevance cr;

    private static CalcMotivation instance = null;

    private CalcMotivation() {
    }

    /**
     * load the components, returns an instance
     * 
     * @param csv
     * @param cp
     * @return
     */
    public static CalcMotivation getInstance(CalcSkillVariety csv,
            CalcPayment cp, CalcRelevance cr) {
        if (instance == null) {
            instance = new CalcMotivation();
            instance.csv = csv;
            instance.cp = cp;
            instance.cr = cr;
        }
        return instance;
    }

    /**
     * may return a null instance if not loaded before
     * 
     * @return
     */
    public static CalcMotivation getInstance() {
        if (instance != null) {
            return instance;
        }
        throw new IllegalStateException(
                "calc motivation was not loaded before");

    }

    /**
     * compute a (very loose) upper bound on motivation value for several
     * workers
     * 
     * @param maxNbTasksPerWorker
     * @param worker
     * @return
     */
    public double computeMaximumTheoreticalMotivation(int maxNbTasksPerWorker,
            Collection<Worker> workers) {
        return workers.stream()
                .map(w -> computeMaximumTheoreticalMotivation(
                        maxNbTasksPerWorker, w))
                .reduce(Double.valueOf(0), Double::sum);
    }

    /**
     * compute a (very loose) upper bound on motivation value for a worker
     * 
     * @param maxNbTasksPerWorker
     * @param worker
     * @return
     */
    private double computeMaximumTheoreticalMotivation(int maxNbTasksPerWorker,
            Worker worker) {
        return (worker.getAlpha() + worker.getBeta()) * maxNbTasksPerWorker
                * (maxNbTasksPerWorker - 1);
    }

    /**
     * compute motivation value
     * 
     * @param assignments
     *            map<Worker, AssignmentCollection>, which is used in
     *            {@link Assigner}
     * @return
     */
    public double computeMotivation(Multimap<Worker, Assignment> assignments) {

        double sum = 0;
        for (Worker w : assignments.keySet()) {
            sum += computeMotivation(w, assignments.get(w));
        }
        return sum;

    }

    /**
     * compute motivation value
     * 
     * @param worker
     * @param tasks
     *            collection of tasks
     * @return
     */
    private double computeMotivation(Worker worker,
            Collection<Assignment> assignments) {
        if (assignments == null) {
            return 0.0;
        }
        if (assignments.isEmpty()) {
            return 0.0;
        }
        // this may happen in an empty multimap
        if (assignments.size() == 1) {
            Assignment a = assignments.iterator().next();
            if (a == null) {
                return 0.0;
            }
        }
        List<Task> tasks = new ArrayList<>();
        for (Assignment a : assignments) {
            tasks.add(a.getTask());
        }
        double skillVariety = csv.getSkillVariety(tasks);
        switch (versionUsed) {
        default:
        case DIV_REL:
            double taskRelevance = cr.computeRelevance(tasks, worker);
           
            return 2 * worker.getAlpha() * skillVariety
                    + (tasks.size() - 1) * (worker.getBeta()) * taskRelevance;
        }

    }

    public CalcSkillVariety getCsv() {
        return csv;
    }

    public CalcPayment getCp() {
        return cp;
    }

    public CalcRelevance getCr() {
        return cr;
    }

}
