package ata.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ata.configuration.ConfigurationLoader;

/**
 * singleton class to access the DB
 *
 */
public final class ConnectionManager {
    private final static Logger LOGGER = LoggerFactory
            .getLogger(ConnectionManager.class);

    private String username;
    private String password;
    /**
     * jdbc address
     */
    private String dbJDBCAddress;
    /**
     * connection with DB
     */
    private Connection connection = null;

    public ConnectionManager(String dbName) {
        try {
            setupParams(dbName);
        } catch (Exception e1) {
            LOGGER.error("error when setting params", e1);
        }
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            LOGGER.error("error with postgres jdbc driver", e);
        }
        Properties props = new Properties();
        props.setProperty("user", this.username);
        props.setProperty("password", this.password);

        LOGGER.debug("connection information is set up");
        LOGGER.debug("user: {}", this.username);
        LOGGER.debug("dbAddress: {}", this.dbJDBCAddress);

        try {
            connection = DriverManager.getConnection(dbJDBCAddress, props);
        } catch (SQLException e) {
            LOGGER.error("error with postgres db", e);
            return;
        }
        LOGGER.info("connection successful with db {}", dbJDBCAddress);
    }

    /**
     * setup params for connection
     * 
     * @param dbName
     * @throws Exception
     */
    private final void setupParams(String dbName) throws Exception {
        try {
            this.dbJDBCAddress = ConfigurationLoader.getConfiguration()
                    .getString(dbName + ".address");
            this.username = ConfigurationLoader.getConfiguration()
                    .getString(dbName + ".username");
            this.password = ConfigurationLoader.getConfiguration()
                    .getString(dbName + ".password");
        } catch (Exception e) {
            LOGGER.error("connection manager could not load parameters", e);
        }

        if (this.username == null || this.password == null
                || this.dbJDBCAddress == null) {
            throw new Exception("missing login values for connection Manager");
        }
    }

    public Connection getConnection() {
        return this.connection;
    }

    /**
     * stops connection
     */
    public void stopConnection() {
        try {
            this.connection.close();
        } catch (SQLException e) {
            LOGGER.warn("could not close connection cleanly", e);
        }
    }

    @Override
    protected void finalize() throws Throwable {
        this.stopConnection();
        super.finalize();
    }

}
