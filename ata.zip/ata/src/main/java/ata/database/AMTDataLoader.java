package ata.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.MultimapBuilder;
import com.google.common.collect.SetMultimap;

import ata.misc.RandomGeneratorCustom;
import ata.task.jobs.Job;
import ata.task.tasks.Task;

public class AMTDataLoader {
    private static Logger LOGGER = LoggerFactory.getLogger(AMTDataLoader.class);

    // /**
    // * nb tasks created = hitFactor*hits_available
    // */
    // private final static double hitFactor = 1;s

    /**
     * id at which generated tasks begin
     */
    private static AtomicInteger taskIndex = new AtomicInteger(1);

    /**
     * to ensure that all AMT jobs are different from CF jobs (less than 100 CF
     * jobs)
     */
    private final static int startIndexJobsAMT = 100;

    /**
     * duration is not used, but we keep it as it may the case later. We use a
     * default value for all jobs.
     */
    private final static int defaultDuration = 0;

    // /**
    // * we modify the maximum duration and set it using a random value between
    // 1
    // * and 300
    // */
    // private final static int maximumDuration = 300;

    // for postgres >=9.5
    // private final static String QUERY_HITGROUPS = "SELECT * FROM hitgroup
    // TABLESAMPLE SYSTEM (?) REPEATABLE (1) WHERE hitgroup.id IN (SELECT
    // hitgroup_id FROM hitgroup_keyword)";

    // for postgres <9.5, we use the materialized view
    // private final static String QUERY_HITGROUPS = "SELECT * FROM
    // hitgroup_random_order WHERE id IN (SELECT hitgroup_id FROM
    // hitgroup_keyword) ORDER BY row_number() OVER() LIMIT (?)";

    private final static String RE_SEED = "SELECT SETSEED(0.5)";
    private final static String QUERY_HITGROUPS_BIS = "SELECT * FROM(SELECT DISTINCT ON(title, reward, description, requester_id, requester_name, expiration_date) hitgroup_random_order.* FROM hitgroup_random_order WHERE id IN (SELECT hitgroup_id FROM hitgroup_keyword)) as q ORDER BY random() LIMIT (?)";
    private final static String QUERY_KEYWORDS = "SELECT keyword.keyword FROM hitgroup_keyword INNER JOIN keyword ON hitgroup_keyword.keyword_id=keyword.id WHERE hitgroup_keyword.hitgroup_id=?";

    public static Set<Job> getAllJobs(Connection connection,
            int nbJobsToFetch) {
        // reseed random
        RandomGeneratorCustom.getInstance().reseedRandom();

        long startTime = System.nanoTime();
        int nbTasks = 0;
        // // limit: 100% if incorrect value
        // double percentToUse = (percent > 0 && percent <= 100) ? percent :
        // 100;
        // first fetch jobs
        Set<Job> out = new HashSet<>();
        // TIntObjectMap<Job> out = new TIntObjectHashMap<Job>();
        // TObjectIntMap<Job> hitsPerJob = new TObjectIntHashMap<Job>();
        try {

            PreparedStatement reseedStatement = connection
                    .prepareStatement(RE_SEED);
            reseedStatement.execute();

            PreparedStatement selectAllJobs = connection
                    .prepareStatement(QUERY_HITGROUPS_BIS);
            selectAllJobs.setInt(1, nbJobsToFetch);
            ResultSet jobResults = selectAllJobs.executeQuery();
            String currentHitGroupID, name, description = null;
            int duration = 0, payment = 0;
            // int hitsAvailable;
            Set<String> keywords = null;
            int i = 0;
            // we visit all hitgroups/jobs
            while (jobResults.next()) {
                currentHitGroupID = jobResults.getString("id");
                name = jobResults.getString("title");
                // duration = jobResults.getInt("time_allotted");
                // duration =
                // RandomGenerator.getInstance().getReseededRandom().nextInt(maximumDuration)
                // + 1;
                duration = defaultDuration;
                payment = jobResults.getInt("reward");
                // hit available is not necessary available!!
                // hitsAvailable = jobResults.getInt("hits_available");
                description = jobResults.getString("description");
                // keywords.add(jobResults.getString("keyword"));
                keywords = new HashSet<>();
                Job job = Job.buildJob(i + startIndexJobsAMT, name, description,
                        keywords, duration, payment);
                job.setAmtHitgroupId(currentHitGroupID);
                // add job
                out.add(job);
                // hitsPerJob.put(job, hitsAvailable);
                i++;
                if (out.size() % 500 == 0) {
                    LOGGER.info(
                            String.format("%d jobs created (%d rows fetched)",
                                    out.size(), i));
                }
            }

            // logger.debug(String.format("hash: %d",
            // TasksJobsTools.genJobsHashCodeOrderIndependent(out.valueCollection())));

            jobResults.close();
            LOGGER.debug(i + " rows visited");
            LOGGER.debug(out.size() + " jobs (aka hitgroups) loaded");

            // then fetch keywords
            for (Job j : out) {
                // fetch keywords
                PreparedStatement selectKeywords = connection
                        .prepareStatement(QUERY_KEYWORDS);
                selectKeywords.setString(1, j.getAmtHitgroupId());
                ResultSet keywordResults = selectKeywords.executeQuery();
                while (keywordResults.next()) {
                    j.addKeyword(keywordResults.getString("keyword"));
                }
                if (j.getKeywords().size() == 0) {
                    LOGGER.error("Job {} has no keywords!", j);
                }
                // generate tasks
                // j.addTasks(AMTDataLoader.generateTasks(j,
                // hitsPerJob.get(j)));
                // nbTasks += j.getTasks().size();
            }

        } catch (

        SQLException e)

        {
            LOGGER.error("error when querying db", e);
        }

        long totalTime = System.nanoTime() - startTime;
        LOGGER.debug(nbTasks + " tasks loaded (" + totalTime / 1000000 + "ms)");
        return out;
    }

    /**
     * generate a number of tasks for a collection of jobs
     * 
     * @param jobs
     * @param nbTasksPerJob
     * @param resetIndex
     * @return
     */
    public static SetMultimap<Job, Task> generateNbTasks(Set<Job> jobs,
            int nbTasksPerJob, boolean resetIndex) {
        if (resetIndex) {
            resetIndex();
        }
        SetMultimap<Job, Task> out = MultimapBuilder.hashKeys()
                .hashSetValues(nbTasksPerJob * jobs.size()).build();
        for (Job job : jobs) {
            for (int i = 0; i < nbTasksPerJob; i++) {
                Task generatedTask = job.buildTask(getTaskIndex(), "{}", "",
                        "");
                out.put(job, generatedTask);
            }
            LOGGER.trace("{} tasks created for job {} ", out.get(job).size(),
                    job);
        }
        return out;
    }

    private static void resetIndex() {
        taskIndex.set(1);
    }

    private static int getTaskIndex() {
        if (taskIndex.get() <= 0) {
            LOGGER.error(
                    "int overflow for task index, value reset to 1. May cause duplicates!");
            taskIndex.set(1);
        }
        return taskIndex.getAndIncrement();
    }

}
