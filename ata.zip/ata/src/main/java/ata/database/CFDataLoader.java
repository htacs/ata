package ata.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Multimap;
import com.google.common.collect.MultimapBuilder;

import ata.task.jobs.Job;
import ata.task.tasks.Task;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.set.hash.THashSet;

/**
 * tools to load crowdflower tasks
 *
 */
public final class CFDataLoader {
    private final static Logger LOGGER = LoggerFactory
            .getLogger(CFDataLoader.class);

    private final static String QUERY_TASK = "SELECT serial_id, content, res_path, res_url, job_id FROM task_random_order LIMIT (?)";

    private final static String QUERY_JOBS = "SELECT id, name, description, duration, payment, keywords FROM job";

    public static Multimap<Job, Task> getAllJobs(Connection connection) {
        return CFDataLoader.getAllJobs(connection, 100);
    }

    /**
     * get all tasks
     * 
     * @param connection
     * @param limit
     *            % of rows to fetch
     * @return
     */
    public static Multimap<Job, Task> getAllJobs(Connection connection,
            int nbTasksToFetch) {
        long startTime = System.nanoTime();
        int nbTasks = 0;
        Multimap<Job, Task> out = MultimapBuilder.hashKeys().hashSetValues()
                .build();
        TIntObjectMap<Job> tempJobs = new TIntObjectHashMap<>();
        // first get all jobs
        try {
            PreparedStatement selectAllJobs = connection
                    .prepareStatement(QUERY_JOBS);
            ResultSet jobResults = selectAllJobs.executeQuery();
            while (jobResults.next()) {
                int jobId = jobResults.getInt("id");
                String name = jobResults.getString("name");
                int duration = jobResults.getInt("duration");
                int payment = jobResults.getInt("payment");
                ResultSet kwResultSet = jobResults.getArray("keywords")
                        .getResultSet();
                Set<String> keywords = new THashSet<>();
                String description = jobResults.getString("description");
                while (kwResultSet.next()) {
                    keywords.add(kwResultSet.getString(2));
                }
                Job currentJob = Job.buildJob(jobId, name, description,
                        keywords, duration, payment);
                tempJobs.put(currentJob.getId(), currentJob);
            }
            jobResults.close();
            LOGGER.info(String.format("%d jobs loaded", out.size()));
            LOGGER.info(String.format("fetching %d tasks", nbTasksToFetch));

            // now get tasks from all jobs
            //
            // String query = "SELECT serial_id, content, res_path, res_url,
            // job_id FROM task";
            // if (limit > 0) {
            // query += " TABLESAMPLE SYSTEM (" + limit + ") REPEATABLE (1)";
            // }
            PreparedStatement selectTasks = connection
                    .prepareStatement(QUERY_TASK);
            selectTasks.setInt(1, nbTasksToFetch);
            ResultSet taskResults = selectTasks.executeQuery();
            long start = System.nanoTime();
            while (taskResults.next()) {
                int id = taskResults.getInt("serial_id");
                String jsonAsString = taskResults.getString("content");
                String resPath = taskResults.getString("res_path");
                String resURL = taskResults.getString("res_url");
                int jobId = taskResults.getInt("job_id");
                // get job
                Job currentJob = tempJobs.get(jobId);
                long startTask = System.nanoTime();
                Task task = currentJob.buildTask(id, jsonAsString, resURL,
                        resPath);
                long taskTime = System.nanoTime() - startTask;
                LOGGER.trace("task creation time: " + taskTime);
                LOGGER.trace("----");
                out.put(currentJob, task);
                nbTasks++;
            }
            taskResults.close();
            long tasksTime = System.nanoTime() - start;
            LOGGER.trace(String.format("loading time tasks: %.2f ms",
                    (double) tasksTime / 1E6));

        } catch (SQLException e) {
            LOGGER.error("error when querying db", e);
        }
        long totalTime = System.nanoTime() - startTime;
        LOGGER.info(String.format("%d tasks loaded (%.2f ms", nbTasks,
                (double) totalTime / 1E6));
        LOGGER.info(String.format("%d jobs with tasks", out.size()));

        return out;

    }

    /**
     * get all keywords
     * 
     * @param connection
     * @return
     */
    public static Set<String> getAllKeywords(Connection connection) {
        long startTime = System.nanoTime();
        Set<String> out = new THashSet<String>();
        try {
            PreparedStatement selectAllKeywords = connection.prepareStatement(
                    "SELECT DISTINCT(unnest(keywords)) FROM job");
            ResultSet kwResults = selectAllKeywords.executeQuery();
            while (kwResults.next()) {
                out.add(kwResults.getString("1"));
            }
            kwResults.close();

        } catch (SQLException e) {
            LOGGER.error("error when querying db", e);

        }
        long totalTime = System.nanoTime() - startTime;
        LOGGER.info(out.size() + " keywords fetched (" + totalTime / 1000000
                + "ms)");
        return out;
    }

}
